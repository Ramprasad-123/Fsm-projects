package com.hgc.apihub.hsbc.directdebit.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.QueueRequestMetaData;
import lombok.Getter;

@Getter
public class BasicQueueListenerRequest<T extends QueueListenerBody> extends QueueListenerRequest<T> {

    private final DirectDebitType type;
    @JsonProperty("profile_id")
    private final String profileId;

    public BasicQueueListenerRequest(@JsonProperty("transaction_id") final String transactionId, @JsonProperty("event_id") final String eventId, @JsonProperty("correlation_id") final String correlationId,
                                     @JsonProperty("queue_state") final String queueState, @JsonProperty("queue_name") final String queueName, @JsonProperty("dlq_count") final int dlqCount,
                                     @JsonProperty("meta_data") final QueueRequestMetaData metaData, @JsonProperty("body") final T body, @JsonProperty("type") final DirectDebitType typeEnum, @JsonProperty("profile_id") final String profileIdValue) {
        super(transactionId, eventId, correlationId, queueState, queueName, dlqCount, metaData, body);
        this.type = typeEnum;
        this.profileId = profileIdValue;
    }

    public BasicQueueListenerRequest(final String transactionId, final String eventId, final String correlationId, final String queueState, final String queueName, final QueueRequestMetaData metaData, final String profileIdValue) {
        this(transactionId, eventId, correlationId, queueState, queueName, 0, metaData, null, null, profileIdValue);
    }

    public BasicQueueListenerRequest(final BasicQueueListenerRequest<? extends QueueListenerBody> request, final T body) {
        super(request.getTransactionId(), request.getEventId(), null, null, null, 0, null, body);
        this.type = request.getType();
        this.profileId = request.getProfileId();
    }

    public BasicQueueListenerRequest(final String transactionId, final String eventId, final T body, final DirectDebitType typeEnum, final String profileIdValue) {
        super(transactionId, eventId, null, null, null, 0, null, body);
        this.type = typeEnum;
        this.profileId = profileIdValue;
    }

    public BasicQueueListenerRequest(final String transactionId, final T body, final DirectDebitType typeEnum, final String profileIdValue) {
        this(transactionId, null, body, typeEnum, profileIdValue);
    }
}
