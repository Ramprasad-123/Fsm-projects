package com.hgc.apihub.fsmadapter;

public final class AdapterHelper {

    private AdapterHelper() {
    }

    public static final int RETRY_AFTER = 5;
    public static final long RECORD_EXPIRATION_DAY = 180;
    public static final String RETRY_AFTER_SWAGGER_EXAMPLE = "5";
}
