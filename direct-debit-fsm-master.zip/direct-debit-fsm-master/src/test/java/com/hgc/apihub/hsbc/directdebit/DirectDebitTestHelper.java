package com.hgc.apihub.hsbc.directdebit;

import com.hgc.apihub.hsbc.directdebit.model.DirectDebitType;
import com.hgc.apihub.hsbc.directdebit.model.dynamodb.DirectDebitEntity;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;

public class DirectDebitTestHelper {

    private DirectDebitTestHelper() {
    }

    public static DirectDebitEntity getDirectDebitEntity(DirectDebitType type, State state) {
        var item = new DirectDebitEntity("ID0000023", type, "ID0000021", "ID0000022", state.name(), SubState.ENTERED, null, "http://test.com");
        item.setCorrelationId("ID0000024");
        return item;
    }
}
