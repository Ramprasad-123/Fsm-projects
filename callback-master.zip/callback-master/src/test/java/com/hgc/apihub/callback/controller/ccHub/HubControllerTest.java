package com.hgc.apihub.callback.controller.ccHub;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hgc.apihub.callback.HubTestHelper;
import com.hgc.apihub.callback.model.ccHub.HubRequest;
import com.hgc.apihub.callback.service.ccHub.HubService;
import com.hgc.lib.microservices.aws.fsm.model.AWSQueueMessagingTemplate;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.configuration.APIMConfig;
import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import com.hgc.lib.microservices.statemachine.configuration.StateNodeConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static com.hgc.apihub.callback.HubTestHelper.getHubListResponse;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

/**
 * @author Wai Yan Oo on 5/12/20
 */

@WebMvcTest(HubController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@Import(SanitizedExceptionHandler.class)
class HubControllerTest {

    private ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private HubService hubService;

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BuildProperties buildProperties;

    @MockBean
    private StateNodeConfig stateNodeConfig;

    @MockBean
    private DynamoDBDao dynamoDBDao;

    @MockBean
    private AWSStateGraph awsStateGraph;

    @MockBean
    private APIMConfig apimConfig;

    @MockBean
    private AWSQueueMessagingTemplate awsQueueMessagingTemplate;

    @Test
    void createHub() throws Exception {
        //arrange
        Mockito.when(hubService.createHub(Mockito.any(String.class),Mockito.any(HubRequest.class))).thenReturn(HubTestHelper.getCreatedHubResponse());
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.post("/v1/hubs")
                .header("X-USER-ID","testUserId")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content(objectMapper.writeValueAsString(new HubRequest("test", "test@test.com", "testUser"))))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.id").value(1))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.apim_x_user_id").value("testUser"))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.query").value("test"))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.callback").value("test@test.com"))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.create_date").value("1993-01-01 12:14:12"))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.create_by").value("testUser"))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.update_date").value(""))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body.update_by").value(""))
                .andExpect(MockMvcResultMatchers.jsonPath("@.statusCodeValue").value(201))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andDo(print());
    }

    @Test
    void getHubs() throws Exception {
        //arrange
        Mockito.when(hubService.getHubList(0, 5)).thenReturn(getHubListResponse());
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.get("/v1/hubs")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .param("page", "0")
                .param("size", "5")
                .content(objectMapper.writeValueAsString("")))
                .andExpect(MockMvcResultMatchers.jsonPath("$.body.data[0].id").value(1))
                .andExpect(MockMvcResultMatchers.jsonPath("$.body.data[1].id").value(2))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print());
    }

    @Test
    void deleteHub() throws Exception {
        //arrange
        Mockito.when(hubService.deleteHub("1")).thenReturn(HubTestHelper.getDeleteHubResponse());
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.delete("/v1/hubs/1")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content(objectMapper.writeValueAsString("")))
                .andExpect(MockMvcResultMatchers.jsonPath("$.body").value(true))
                .andExpect(MockMvcResultMatchers.status().isNoContent())
                .andDo(print());
    }

}