# HGC Test FSM

Microservice build on spring boot to test FSM

## Getting Started

For understanding the project source code, the following knowledge will be helpful in no particular order:
* Java
* Maven
* Spring Framework
* AWS SQS
* AWS DynamoDB
* Git
* Log4j2

The list above is not an exhaustive list.

### Prerequisites

* [Git](https://git-scm.com/) is installed. Required for checking out the source code.
* [JDK 18](https://jdk.java.net/18/) is installed. Required for development and running the project.

### Installing

To obtain a local copy of the master branch of the repository, you can run the following command.
```
git clone git@jihulab.com:hgc-groups/hgc-global-communications/api-hub/test-fsm.git
```

### Development


### Build


## Built With

* [JDK 18](https://jdk.java.net/18/) - The core project built on JVM
* [Maven](https://maven.apache.org/) - Dependency Management
* [Spring Boot 2.7.6](https://spring.io/projects/spring-boot) - Spring framework

## Versioning


## Authors

* **Sooraj Mohanan** - [\<Sooraj.Mohanan@hgc.com.hk\>](mailto:Sooraj.Mohanan@hgc.com.hk)

## Copyright

Copyright &copy; 2022, [HGC Global Communications Limited](http://www.hgc.com.hk/Home/Index-en.html).
All rights reserved.