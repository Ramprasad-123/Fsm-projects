package com.hgc.apihub.callback.model.asfe.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.springframework.util.StringUtils;

import java.util.Arrays;

@Getter
public enum AsFeAction {
    SCHEDULED_MAINTENANCE,
    OUTAGE_START,
    OUTAGE_END;

    @JsonCreator
    public static AsFeAction fromValue(final String value) {
        if (!StringUtils.hasLength(value)) {
            return null;
        }
        return Arrays.stream(AsFeAction.values())
                .filter(e -> value.equalsIgnoreCase(e.name()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(String.format("does not support value %s!", value)));
    }

    @JsonValue
    public String toValue() {
        return this.toString();
    }
}
