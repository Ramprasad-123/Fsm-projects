package com.hgc.apihub.dummyfsm.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;

@Getter
@ApiModel(description = "Current time display to see if request takes too long")
@JsonPropertyOrder({"message"})
public class CurrentTime implements QueueListenerBody {

    @JsonProperty("current_date_time")
    @ApiModelProperty(example = "2021-01-15 12:34:56", notes = "sysdate")
    private String currentTime;

    public CurrentTime(@JsonProperty("current_date_time") final String currentTimeValue) {
        this.currentTime = currentTimeValue;
    }
}
