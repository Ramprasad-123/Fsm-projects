package com.hgc.apihub.fsmadapter;

import com.hgc.apihub.fsmadapter.model.AdapterResponse;
import com.hgc.apihub.fsmadapter.model.DynamoDBRequest;
import com.hgc.apihub.fsmadapter.model.InitiateMessageRequest;
import com.hgc.apihub.fsmadapter.model.MessageRequest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.model.AuthType;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.deliver.model.DeliverType;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;

import java.util.List;
import java.util.Map;

public class AdapterTestHelper {

    private AdapterTestHelper() {
    }

    public static MessageRequest getNullMessageRequest() {
        return new MessageRequest(null, "test queue");
    }

    public static MessageRequest getBlackMessageRequest() {
        return new MessageRequest("test", "");
    }

    public static MessageRequest getMessageRequest() {
        return new MessageRequest("test message", "test queue");
    }

    public static InitiateMessageRequest getNullInitiateMessageRequest() {
        return new InitiateMessageRequest(null, "test queue", "test_fsm", null, null, null, null, null);
    }

    public static InitiateMessageRequest getBlackInitiateMessageRequest() {
        return new InitiateMessageRequest("test", "", "", null, null, null, null, null);
    }

    public static InitiateMessageRequest getInitiateMessageRequest() {
        return new InitiateMessageRequest("test message", "test queue", "test_fsm", "http://test.com/notification", AuthType.BASIC, "test", 10, "http://test.com");
    }

    public static AsyncStateResponse getAsyncStateResponse() {
        return AsyncStateResponse.buildAcceptedResponse("ID0000021", "ID0000022", List.of(Link.withSelfRelation("https://apihub.hgc.com/test/abc123")));
    }

    public static AdapterResponse getAdapterResponse() {
        return new AdapterResponse(200, "test");
    }

    public static DynamoDBRequest getNullDynamoDBRequest() {
        return new DynamoDBRequest("ID0000021", "ID0000022", "test_fsm", null);
    }

    public static DynamoDBRequest getBlankDynamoDBRequest() {
        return new DynamoDBRequest("", "", "", Map.of("test", "test"));
    }

    public static DynamoDBRequest getDynamoDBRequest() {
        return new DynamoDBRequest("ID0000021", "ID0000022", "test_fsm", Map.of("test", "test"));
    }

    public static DynamoDBEntity getDynamoDBEntity(String data) {
        return getDynamoDBEntity(State.ACCEPTED, data, null);
    }

    public static DynamoDBEntity getDynamoDBEntity(State state, String data, String callbackUrl) {
        return new DynamoDBEntity("ID0000021", "ID0000022", state.name(), SubState.EXITED, data, DeliverType.CALLBACK, callbackUrl);
    }
}
