package com.hgc.apihub.callback.controller.ccHub;

import com.hgc.apihub.callback.exception.ccHub.CcHubDeleteOperationFailException;
import com.hgc.apihub.callback.exception.ccHub.CcHubNotFoundException;
import com.hgc.apihub.callback.exception.ccHub.GraphQLMutationException;
import com.hgc.apihub.callback.model.ccHub.HubRequest;
import com.hgc.apihub.callback.model.ccHub.HubResponse;
import com.hgc.apihub.callback.service.ccHub.HubService;
import com.hgc.lib.microservices.swagger.Error400Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/v1")
@Validated
@AllArgsConstructor
@Tag(name = "Hub Controller", description = "Operations pertaining to Hub")
class HubController {

    private static final int REPORT_SIZE_MAX = 100;

    private static final String API_RESPONSE_CODE_200 = "200";
    private static final String API_RESPONSE_CODE_201 = "201";
    private static final String API_RESPONSE_CODE_400 = "400";
    private static final String API_RESPONSE_CODE_404 = "404";
    private static final String API_RESPONSE_CODE_500 = "500";

    private static final String API_RESPONSE_CODE_200_SWAGGER_VALUE = "Hub successfully retrieved";
    private static final String API_RESPONSE_CODE_201_SWAGGER_VALUE = "Hub successfully created";
    private static final String API_RESPONSE_CODE_400_SWAGGER_VALUE = "Request/Parameter is invalid";
    private static final String API_RESPONSE_CODE_500_SWAGGER_VALUE = "Server/Unknown/Querying error occurred";
    private static final String API_RESPONSE_CODE_404_SWAGGER_VALUE = "Hub not found";

    private static final String PAGE_PARAM_SWAGGER_VALUE = "The number of pages to be displayed";
    private static final String SIZE_PARAM_SWAGGER_VALUE = "The size of the results to be displayed, Max and default value is " + REPORT_SIZE_MAX;

    private static final String PAGE_PARAM_SWAGGER_EXAMPLE = "5";
    private static final String SIZE_PARAM_SWAGGER_EXAMPLE = "10";

    private final HubService hubService;

    @Operation(
            summary = "Create Hub",
            description = "Create Cc Hub."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = API_RESPONSE_CODE_201, description = API_RESPONSE_CODE_201_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = HubResponse.class))),
                    @ApiResponse(responseCode = API_RESPONSE_CODE_200, description = API_RESPONSE_CODE_200_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = HubResponse.class))),
                    @ApiResponse(responseCode = API_RESPONSE_CODE_400, description = API_RESPONSE_CODE_400_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))),
                    @ApiResponse(responseCode = API_RESPONSE_CODE_500, description = API_RESPONSE_CODE_500_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class)))
            }
    )
    @PostMapping(path = "/hubs", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity createHub(
            @RequestHeader(name = "X-USER-ID", required = false) final String userId,
            @Valid @RequestBody final HubRequest request
    ) throws GraphQLMutationException {
        var hubResponse = hubService.createHub(userId, request);
        return new ResponseEntity<>(hubResponse, hubResponse.getStatusCode());
    }

    @Operation(
            summary = "Get Hub list",
            description = "Get Cc Hub list."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = API_RESPONSE_CODE_200, description = API_RESPONSE_CODE_200_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = HubResponse.class))),
                    @ApiResponse(responseCode = API_RESPONSE_CODE_400, description = API_RESPONSE_CODE_400_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))),
                    @ApiResponse(responseCode = API_RESPONSE_CODE_500, description = API_RESPONSE_CODE_500_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class)))
            }
    )
    @GetMapping(path = "/hubs", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity getHubs(
            @Parameter(description = PAGE_PARAM_SWAGGER_VALUE, example = PAGE_PARAM_SWAGGER_EXAMPLE) @RequestParam(required = false) final Integer page,
            @Parameter(description = SIZE_PARAM_SWAGGER_VALUE, example = SIZE_PARAM_SWAGGER_EXAMPLE) @RequestParam(required = false) @Max(REPORT_SIZE_MAX) final Integer size
    ) throws GraphQLMutationException {
        var hubResponse = hubService.getHubList(page, size);
        return new ResponseEntity<>(hubResponse, hubResponse.getStatusCode());
    }

    @Operation(
            summary = "Delete Hub",
            description = "Delete Cc Hub by id."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = API_RESPONSE_CODE_200, description = API_RESPONSE_CODE_200_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = HubResponse.class))),
                    @ApiResponse(responseCode = API_RESPONSE_CODE_400, description = API_RESPONSE_CODE_400_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))),
                    @ApiResponse(responseCode = API_RESPONSE_CODE_500, description = API_RESPONSE_CODE_500_SWAGGER_VALUE, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class)))
            }
    )
    @DeleteMapping(path = "/hubs/{hub_id}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity deleteHub(
            @Parameter(description = "Hub id.", required = true)
            @PathVariable(name = "hub_id") @Valid @NotNull String hubId
    ) throws GraphQLMutationException, CcHubNotFoundException, CcHubDeleteOperationFailException {
        var hubResponse = hubService.deleteHub(hubId);
        return new ResponseEntity<>(hubResponse, hubResponse.getStatusCode());
    }
}
