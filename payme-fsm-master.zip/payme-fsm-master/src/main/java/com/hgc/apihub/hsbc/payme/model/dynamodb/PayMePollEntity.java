package com.hgc.apihub.hsbc.payme.model.dynamodb;

import com.hgc.apihub.hsbc.payme.model.PayMeType;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBPollEntity;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;

@Setter
@DynamoDbBean
@NoArgsConstructor
public class PayMePollEntity extends HGCDynamoDBPollEntity {

    private PayMeType type;
    private Integer startDuration;
    private Integer endDuration;
    private String data;
    private boolean polling;

    public PayMePollEntity(final String transactionId, final String eventId, final String correlationId, final PayMeType typeEnum, final Integer startDurationValue, final Integer endDurationValue, final String dataValue) {
        super(transactionId, eventId, correlationId, null, null, null);
        this.type = typeEnum;
        this.startDuration = startDurationValue;
        this.endDuration = endDurationValue;
        this.data = dataValue;
    }

    /**
     * Get type
     *
     * @return type
     */
    @DynamoDbConvertedBy(value = PayMeTypeConverter.class)
    public PayMeType getType() {
        return type;
    }

    /**
     * Get start duration
     *
     * @return start duration
     */
    @DynamoDbAttribute(value = "start_duration")
    public Integer getStartDuration() {
        return startDuration;
    }

    /**
     * Get end duration
     *
     * @return end duration
     */
    @DynamoDbAttribute(value = "end_duration")
    public Integer getEndDuration() {
        return endDuration;
    }

    /**
     * Get data
     *
     * @return data
     */
    public String getData() {
        return data;
    }

    /**
     * Check is polling
     *
     * @return polling
     */
    public boolean isPolling() {
        return polling;
    }
}
