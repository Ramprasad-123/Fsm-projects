package com.hgc.apihub.callback.model.asfe.enums;

public enum CallbackType {
    PLANNED_MAINTENANCE_START,
    PLANNED_MAINTENANCE_END,
    OUTAGE_START,
    OUTAGE_RESUME
}
