package com.hgc.apihub.testfsm.service;

import com.hgc.lib.microservices.aws.fsm.deliver.service.BasicAWSDeliveredListener;
import org.springframework.stereotype.Service;

@Service
public class DeliverListener extends BasicAWSDeliveredListener {
}
