package com.hgc.apihub.testfsm.service;

//TODO sample code, to be removed/updated

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.hgc.lib.microservices.aws.fsm.common.AWSQueueListenerTest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.deliver.model.DeliverType;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.FSMEntityDaoRequest;
import com.hgc.lib.microservices.statemachine.model.FSMLockClient;
import com.hgc.lib.microservices.statemachine.model.FSMLockWrapper;;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.StateResponse;
import com.hgc.lib.microservices.statemachine.model.SubState;
import com.hgc.apihub.testfsm.TestFsmTestHelper;
import com.hgc.apihub.testfsm.model.TestFsmRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;
import static com.hgc.lib.microservices.statemachine.StateMachineHelper.convertLocalDateTime;
import static com.hgc.lib.microservices.statemachine.common.StateMachineMock.removeLastUpdateDate;
import static org.mockito.Mockito.never;

@ExtendWith(SpringExtension.class)
class ProcessedListenerTest extends AWSQueueListenerTest {

    private ProcessedListener listener;

    @BeforeEach
    void setup() throws Exception {
        this.init();
        listener = new ProcessedListener();
        this.setDependencies(listener, State.PROCESSED.name());
    }

    @Override
    protected AWSStateGraph constructStateGraph() {
        return TestFsmTestHelper.constructStateGraph();
    }

    @Test
    void listener() throws Exception {
        // arrange
        var requestBody = new TestFsmRequest();
        var urlArgument = ArgumentCaptor.forClass(String.class);
        var messageArgument = ArgumentCaptor.forClass(QueueListenerRequest.class);
        var response = AsyncStateResponse.asyncStateBuilder().transactionId("ID0000021").eventId("ID0000022").state("CUSTOM").links(List.of(Link.withSelfRelation("https://apihub.hgc.com/test/abc123"))).build();
        var item = new HGCDynamoDBEntity("TEST", "CREATE", null, "ID0000021", "ID0000022", "CUSTOM", SubState.ENTERED, OBJECT_MAPPER.writeValueAsString(response), DeliverType.CALLBACK, "http://test.com", null, null);
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return item;
            }
        };
        BDDMockito.given(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).willAnswer(answer);
        var updateArgument = ArgumentCaptor.forClass(FSMEntityDaoRequest.Update.class);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(QueueListenerRequest.builder().transactionId("ID0000021").eventId("ID0000022").body(requestBody).build()), acknowledgment, messageHeaders);
        // assert
        Mockito.verify(dynamoDBDao, Mockito.atLeastOnce()).update(updateArgument.capture());
        Assertions.assertEquals("ID0000021", updateArgument.getValue().getItem().getTransactionId());
        Assertions.assertEquals("ID0000022", updateArgument.getValue().getItem().getEventId());
        Assertions.assertEquals(State.PROCESSED.name(), updateArgument.getValue().getItem().getState());
        Assertions.assertEquals(SubState.EXITED, updateArgument.getValue().getItem().getSubState());
        var expected = StateResponse.stateBuilder().transactionId("ID0000021").eventId("ID0000022").state(State.PROCESSED.name()).build();
        expected.setCreateDate(convertLocalDateTime(item.getCreateDate()));
        Mockito.verify(queueMessagingTemplate).convertAndSend(urlArgument.capture(), messageArgument.capture());
        Assertions.assertEquals("test-fsm-deliver", urlArgument.getValue());
        Mockito.verify(dynamoDBDao, Mockito.atLeastOnce()).releaseLock(Mockito.any(FSMLockClient.class), Mockito.any(FSMLockWrapper.class));
    }
}
