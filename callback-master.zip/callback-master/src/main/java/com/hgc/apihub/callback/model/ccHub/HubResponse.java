package com.hgc.apihub.callback.model.ccHub;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hgc.lib.microservices.model.Response;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.util.List;

/**
 * @author Wai Yan Oo on 5/11/20
 */

@Getter
@Setter
@Schema(description = "Hub response body")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HubResponse extends Response {

    private final List<Hub> data;

    public HubResponse(final List<Hub> dataValue, final HttpStatus httpStatusValue) {
        super(httpStatusValue);
        this.data = dataValue;
    }


}
