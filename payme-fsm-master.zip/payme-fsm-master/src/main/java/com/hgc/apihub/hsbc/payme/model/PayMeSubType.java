package com.hgc.apihub.hsbc.payme.model;

public enum PayMeSubType {

    REQUEST, CANCEL, STATUS_NOTIFICATION, POLL
}
