package com.hgc.apihub.callback.model.asfe.enums;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

class AsFeActionTest {

    private static Stream<Arguments> provideArguments() {
        return Stream.of(
                Arguments.of(AsFeAction.SCHEDULED_MAINTENANCE, "SCHEDULED_MAINTENANCE", "SCHEDULED_MAINTENANCE"),
                Arguments.of(AsFeAction.OUTAGE_START, "OUTAGE_START", "OUTAGE_START"),
                Arguments.of(AsFeAction.OUTAGE_END, "OUTAGE_END", "OUTAGE_END")
        );
    }

    @ParameterizedTest(name = "{0} has a property of {1}.")
    @MethodSource("provideArguments")
    void testEnumMapping(AsFeAction result, String value, String toValue) {
        // assert
        Assertions.assertEquals(result, AsFeAction.fromValue(value));
        Assertions.assertEquals(toValue, result != null ? result.toString() : null);
        if (result != null) {
            Assertions.assertEquals(result.toValue(), result.toString());
        }
    }

    @Test
    void testEnumMappingNull() {
        Assertions.assertNull(AsFeAction.fromValue(null));
    }


    @Test
    void testIllegalArgumentException() {
        Assertions.assertThrows(
                IllegalArgumentException.class, () -> AsFeAction.fromValue("NotExistValue")
        );
    }
}