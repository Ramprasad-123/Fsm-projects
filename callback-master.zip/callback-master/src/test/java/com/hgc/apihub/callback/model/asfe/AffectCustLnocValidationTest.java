package com.hgc.apihub.callback.model.asfe;

import com.hgc.lib.microservices.common.validation.BlankValidationTest;

import java.util.List;

import static com.hgc.apihub.callback.AsfeTestHelper.getAffectCustLnoc;
import static com.hgc.apihub.callback.AsfeTestHelper.getAffectCustLnocViolateBlanks;

public class AffectCustLnocValidationTest implements BlankValidationTest<BasicAsFeRequest.AffectCustLnoc> {

    @Override
    public List<BasicAsFeRequest.AffectCustLnoc> blankInstances() {
        return List.of(getAffectCustLnocViolateBlanks());
    }

    @Override
    public List<Integer> numberOfNonBlankAnnotations() {
        return List.of(2);
    }

    @Override
    public BasicAsFeRequest.AffectCustLnoc validInstance() {
        return getAffectCustLnoc();
    }
}