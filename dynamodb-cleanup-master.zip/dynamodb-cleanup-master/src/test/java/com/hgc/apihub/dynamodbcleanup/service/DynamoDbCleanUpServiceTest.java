package com.hgc.apihub.dynamodbcleanup.service;

import com.hgc.apihub.dynamodbcleanup.dao.A2pDao;
import com.hgc.apihub.dynamodbcleanup.dao.TnssFbiDao;
import com.hgc.apihub.dynamodbcleanup.dao.dynamoDb.DynamoDbA2pSmsDao;
import com.hgc.apihub.dynamodbcleanup.dao.dynamoDb.DynamoDbTnssIntegrationDao;
import com.hgc.apihub.dynamodbcleanup.model.DynamoDbOperationResponse;
import com.hgc.apihub.dynamodbcleanup.model.MessageResult;
import com.hgc.apihub.dynamodbcleanup.model.TableName;
import com.hgc.apihub.dynamodbcleanup.model.ZuoraApiLog;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;

import static com.hgc.apihub.dynamodbcleanup.DynamoDbCleanUpTestHelper.getDeleteRecordSuccessResponse;

@ExtendWith(SpringExtension.class)
class DynamoDbCleanUpServiceTest {

    @MockBean
    private A2pDao a2pDao;

    @MockBean
    private TnssFbiDao tnssFbiDao;

    @MockBean
    private DynamoDbA2pSmsDao dynamodDba2pDao;

    @MockBean
    private DynamoDbTnssIntegrationDao dynamoDbTnssIntegrationDao;

    private DynamoDbCleanUpService dynamoDbCleanUpService;

    @BeforeEach
    void setup() {
        dynamoDbCleanUpService = new DynamoDbCleanUpService(dynamodDba2pDao, dynamoDbTnssIntegrationDao, tnssFbiDao, a2pDao);
    }

    @Test
    void deleteRecordsTnss() throws Exception {
        // arrange
        var expected = getDeleteRecordSuccessResponse();
        Mockito.when(tnssFbiDao.getRecords(Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<>() {
            {
                add(new ZuoraApiLog() {{
                    setApiTransactionId("test");
                    setCreateDate("test");
                }});
                add(new ZuoraApiLog() {{
                    setApiTransactionId("test-2");
                    setCreateDate("test-2");
                }});
            }
        });
        Mockito.when(dynamoDbTnssIntegrationDao.deleteRecords(Mockito.any())).thenReturn(new DynamoDbOperationResponse(200, "OK"));
        // act
        var actual = dynamoDbCleanUpService.deleteRecords("2021-12-11 00:00:00", "2021-12-13 00:00:00", TableName.tnssintegration.name());
        // assert
        Assertions.assertEquals(expected.getStatus(), actual.getStatus());
    }

    @Test
    void deleteRecordsA2p() throws Exception {
        // arrange
        var expected = getDeleteRecordSuccessResponse();
        Mockito.when(a2pDao.getRecords(Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<>() {
            {
                add(new MessageResult() {{
                    setTransactionId("test");
                    setCreateDate("test");
                }});
                add(new MessageResult() {{
                    setTransactionId("test-2");
                    setCreateDate("test-2");
                }});
            }
        });
        Mockito.when(dynamodDba2pDao.deleteRecords(Mockito.any())).thenReturn(new DynamoDbOperationResponse(200, "OK"));
        // act
        var actual = dynamoDbCleanUpService.deleteRecords("2021-12-11 00:00:00", "2021-12-13 00:00:00", TableName.a2p.name());
        // assert
        Assertions.assertEquals(expected.getStatus(), actual.getStatus());
    }

    @Test
    void deleteRecordsNoResult() throws Exception {
        // arrange
        var expected = getDeleteRecordSuccessResponse();
        Mockito.when(tnssFbiDao.getRecords(Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<>() {
        });
        // act
        var actual = dynamoDbCleanUpService.deleteRecords("2021-12-11 00:00:00", "2021-12-13 00:00:00", TableName.tnssintegration.name());
        // assert
        Assertions.assertEquals(expected.getStatus(), actual.getStatus());
    }

}
