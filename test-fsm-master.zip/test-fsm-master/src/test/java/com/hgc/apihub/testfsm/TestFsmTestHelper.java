package com.hgc.apihub.testfsm;

//TODO sample code, to be removed/updated

import com.hgc.lib.microservices.aws.fsm.node.AWSStateEdge;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateNode;
import com.hgc.lib.microservices.aws.fsm.node.StateWeightConverter;
import com.hgc.lib.microservices.statemachine.model.State;

import java.util.List;

import static com.hgc.lib.microservices.aws.fsm.common.AWSStateMachineMock.constructAWSStateGraph;

public class TestFsmTestHelper {

    private TestFsmTestHelper() {
    }

    public static AWSStateGraph constructStateGraph() {
        var nodes = List.of(new AWSStateNode("test-fsm", State.ACCEPTED.name(), true, "test-fsm-accept", "test-fsm-dlq"),
                new AWSStateNode("test-fsm", State.VALIDATED.name(), false, "test-fsm-validate", "test-fsm-dlq"),
                new AWSStateNode("test-fsm", "CUSTOM", false, "test-fsm-custom.fifo", "test-fsm-dlq.fifo"),
                new AWSStateNode("test-fsm", State.PROCESSED.name(), false, "test-fsm-process", "test-fsm-dlq"),
                new AWSStateNode("test-fsm", State.DELIVERED.name(), false, "test-fsm-deliver", "test-fsm-dlq"));
        var converter = new StateWeightConverter();
        var edges = List.of(new AWSStateEdge("test-fsm", State.ACCEPTED.name(), List.of(State.VALIDATED.name()), null),
                new AWSStateEdge("test-fsm", State.VALIDATED.name(), List.of("CUSTOM"), converter.unconvert("[{\"expression\":\"return success\",\"bindings\":{\"success\":true}}]")),
                new AWSStateEdge("test-fsm", "CUSTOM", List.of(State.PROCESSED.name()), null),
                new AWSStateEdge("test-fsm", State.PROCESSED.name(), List.of(State.DELIVERED.name()), converter.unconvert("[{\"expression\":\"return proceed_to_delivery\",\"bindings\":{\"proceed_to_delivery\":true}}]")));
        return constructAWSStateGraph(nodes, edges);
    }
}
