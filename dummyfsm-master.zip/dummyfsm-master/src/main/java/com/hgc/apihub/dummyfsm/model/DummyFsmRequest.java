package com.hgc.apihub.dummyfsm.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;

import javax.validation.constraints.NotBlank;

@Getter
@ApiModel(description = "Create Dummy fsm request body")
@JsonPropertyOrder({"message"})
public class DummyFsmRequest implements QueueListenerBody {

    @NotBlank
    @JsonProperty("message")
    @ApiModelProperty(required = true, example = "Dummy content", notes = "Dummy content")
    private String message;


    public DummyFsmRequest(
            @JsonProperty("message") @NotBlank final String message) {
        this.message = message;
    }
}
