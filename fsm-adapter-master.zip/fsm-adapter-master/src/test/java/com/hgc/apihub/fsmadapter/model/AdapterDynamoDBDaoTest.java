package com.hgc.apihub.fsmadapter.model;

import com.hgc.apihub.fsmadapter.model.dynamodb.AdapterDynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.statemachine.model.SubState;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.hgc.apihub.fsmadapter.AdapterTestHelper.getAdapterResponse;
import static com.hgc.apihub.fsmadapter.AdapterTestHelper.getDynamoDBEntity;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

class AdapterDynamoDBDaoTest {

    private AdapterDynamoDBDao dao;
    private DynamoDbClient dynamoDbClient;

    @BeforeEach
    void setup() {
        dynamoDbClient = Mockito.mock(DynamoDbClient.class);
        dao = new AdapterDynamoDBDao(dynamoDbClient);
    }

    @Test
    void save() {
        // arrange
        var save = getDynamoDBEntity(null);
        var response= PutItemResponse.builder()
                .attributes(Map.of("transaction_id", AttributeValue.fromS("ID0000021"),"event_id", AttributeValue.fromS("ID0000022")))
                .build();
        BDDMockito.given(dynamoDbClient.putItem(Mockito.any(PutItemRequest.class))).willReturn(response);
        // act
        dao.save(save, "test");
    }

    @Test
    void getByTransactionIdAndEventId() throws Exception {
        // arrange
        var item = getDynamoDBEntity(OBJECT_MAPPER.writeValueAsString(getAdapterResponse()));
        mock(item);
        // act
        var result = dao.getByTransactionIdAndEventId(item.getTransactionId(), item.getEventId(), "test_fsm");
        // assert
        Assertions.assertNotNull(result);
        Assertions.assertEquals(item.getTransactionId(), result.getTransactionId());
        Assertions.assertEquals(item.getEventId(), result.getEventId());
        Assertions.assertEquals(item.getState(), result.getState());
        Assertions.assertEquals(item.getSubState(), result.getSubState());
        Assertions.assertEquals(item.getData(), result.getData());
    }

    @Test
    void updateAttributesByTransactionIdAndEventId() throws Exception {
        // arrange
        var item = getDynamoDBEntity(OBJECT_MAPPER.writeValueAsString(getAdapterResponse()));
        mock(item);
        var putItem = ArgumentCaptor.forClass(PutItemRequest.class);
        // act
        dao.updateAttributesByTransactionIdAndEventId(item.getTransactionId(), item.getEventId(), "test", Map.of("state", "PROCESSED", "test", "test"));
        // assert
        Mockito.verify(dynamoDbClient, Mockito.atLeastOnce()).putItem(putItem.capture());
        Assertions.assertEquals("PROCESSED", putItem.getValue().item().get("state").s());
        // act
        dao.updateAttributesByTransactionIdAndEventId(item.getTransactionId(), item.getEventId(), "test", Collections.EMPTY_MAP);
    }

    private void mock(DynamoDBEntity item) {
        var map = new HashMap<String, AttributeValue>();
        map.put("transaction_id", AttributeValue.fromS(item.getTransactionId()));
        map.put("event_id", AttributeValue.fromS(item.getEventId()));
        map.put("state", AttributeValue.fromS(item.getState()));
        map.put("sub_state", AttributeValue.fromS(SubState.EXITED.name()));
        map.put("data", AttributeValue.fromS(item.getData()));
        var response= GetItemResponse.builder()
                .item(map)
                .build();
        BDDMockito.given(dynamoDbClient.getItem(Mockito.any(GetItemRequest.class))).willReturn(response);
    }
}
