#!/bin/bash

aws sqs create-queue --queue-name pubsub-a3n-test-fsm-dlq --region ap-southeast-1
aws sqs create-queue --queue-name pubsub-a3n-test-fsm-dlq.fifo --attributes '{"FifoQueue": "true", "ContentBasedDeduplication": "true"}' --region ap-southeast-1

aws sqs create-queue --queue-name pubsub-a3n-test-fsm-accept --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:ap-southeast-1:824191032000:pubsub-a3n-test-fsm-dlq\",\"maxReceiveCount\":\"10\"}"}' --region ap-southeast-1
aws sqs create-queue --queue-name pubsub-a3n-test-fsm-validate --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:ap-southeast-1:824191032000:pubsub-a3n-test-fsm-dlq\",\"maxReceiveCount\":\"10\"}"}' --region ap-southeast-1
aws sqs create-queue --queue-name pubsub-a3n-test-fsm-custom.fifo --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:ap-southeast-1:824191032000:pubsub-a3n-test-fsm-dlq.fifo\",\"maxReceiveCount\":\"10\"}", "FifoQueue": "true", "ContentBasedDeduplication": "true"}' --region ap-southeast-1
aws sqs create-queue --queue-name pubsub-a3n-test-fsm-process --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:ap-southeast-1:824191032000:pubsub-a3n-test-fsm-dlq\",\"maxReceiveCount\":\"10\"}"}' --region ap-southeast-1
aws sqs create-queue --queue-name pubsub-a3n-test-fsm-deliver --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:ap-southeast-1:824191032000:pubsub-a3n-test-fsm-dlq\",\"maxReceiveCount\":\"10\"}"}' --region ap-southeast-1