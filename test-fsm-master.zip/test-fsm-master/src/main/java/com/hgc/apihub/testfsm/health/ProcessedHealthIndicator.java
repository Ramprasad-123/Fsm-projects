package com.hgc.apihub.testfsm.health;

//TODO sample code, to be removed/updated

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

public class ProcessedHealthIndicator implements HealthIndicator {

    @Override
    public final Health health() {
        return Health.up().build();
    }
}
