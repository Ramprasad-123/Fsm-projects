package com.hgc.apihub.testfsm.model;

//TODO sample code, to be removed/updated

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.lib.microservices.statemachine.model.StateResponse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
@Schema(description = "Test fsm response body")
public class TestFsmResponse extends StateResponse {

    public TestFsmResponse(@JsonProperty("status") final Integer status, @JsonProperty("transaction_id") final String transactionId, @JsonProperty("event_id") final String eventId, @JsonProperty("state") final String state, @JsonProperty("create_date") final String createDate, @JsonProperty("last_update_date") final String lastUpdateDate) {
        super(status, transactionId, eventId, state, createDate, lastUpdateDate);
    }
}
