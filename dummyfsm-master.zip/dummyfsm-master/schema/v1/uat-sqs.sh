#!/bin/bash

aws sqs create-queue --queue-name dummy-fsm-dlq

aws sqs create-queue --queue-name dummy-fsm-validate --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:eu-west-1:794436352571:dummy-fsm-dlq\",\"maxReceiveCount\":\"5\"}"}'
aws sqs create-queue --queue-name dummy-fsm-process --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:eu-west-1:794436352571:dummy-fsm-dlq\",\"maxReceiveCount\":\"5\"}"}'