package com.hgc.apihub.fsmadapter.exception;

import com.hgc.lib.microservices.exception.ExceptionService;
import com.hgc.lib.microservices.exception.ExceptionType;

public class AdapterExceptionService implements ExceptionService {

    @Override
    public final ExceptionType fromExceptionClass(final Class<? extends Throwable> exceptionClass) {
        return AdapterExceptionHandlerType.fromExceptionClass(exceptionClass);
    }
}
