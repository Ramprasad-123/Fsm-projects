package com.hgc.apihub.hsbc.payme.model.dynamodb;

import com.hgc.apihub.hsbc.payme.model.PayMeSubType;
import com.hgc.apihub.hsbc.payme.model.PayMeType;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBDao;
import com.hgc.lib.microservices.statemachine.configuration.FSMDBConfig;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.hgc.apihub.hsbc.payme.model.dynamodb.PayMeEntity.REQUEST_ID_INDEX;

@Primary
@Component
public class PayMeDao extends DynamoDBDao<PayMeEntity> {

    public PayMeDao(final FSMDBConfig fsmDBConfig, final DynamoDbClient dynamoDbClient) {
        super(PayMeEntity.class, fsmDBConfig, dynamoDbClient);
    }

    public final PayMeEntity getByRequestId(final String requestId, final PayMeType type, final PayMeSubType subType) {
        var results = getByRequestId(requestId);
        return Optional.ofNullable(results).stream().flatMap(Collection::stream).filter(d -> type == d.getType() && subType == d.getSubType()).findFirst().orElse(null);
    }

    public final List<PayMeEntity> getByRequestId(final String requestId) {
        var items = this.getDynamoDbTable()
                .index(REQUEST_ID_INDEX)
                .query(requestConsumer -> requestConsumer.queryConditional(QueryConditional.keyEqualTo(key -> key.partitionValue(requestId))));
        return items.stream().map(Page::items).flatMap(Collection::stream).collect(Collectors.toList());
    }
}
