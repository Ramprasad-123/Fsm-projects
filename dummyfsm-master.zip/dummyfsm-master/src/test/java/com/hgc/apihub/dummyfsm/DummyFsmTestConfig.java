package com.hgc.apihub.dummyfsm;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.cloud.aws.autoconfigure.context.ContextStackAutoConfiguration;
import org.springframework.cloud.aws.autoconfigure.messaging.MessagingAutoConfiguration;
import org.springframework.cloud.aws.messaging.config.SimpleMessageListenerContainerFactory;
import org.springframework.cloud.aws.messaging.listener.QueueMessageHandler;
import org.springframework.cloud.aws.messaging.listener.SimpleMessageListenerContainer;
import org.springframework.context.annotation.Bean;

@TestConfiguration
@EnableAutoConfiguration(exclude = {MessagingAutoConfiguration.class, ContextStackAutoConfiguration.class})
public class DummyFsmTestConfig {

    @Bean(name = "amazonSQS")
    public AmazonSQSAsync amazonSQS() {
        return Mockito.mock(AmazonSQSAsync.class);
    }

    @Bean
    public SimpleMessageListenerContainer simpleMessageListenerContainer() {
        var factory = new SimpleMessageListenerContainerFactory();
        factory.setAutoStartup(false);
        factory.setAmazonSqs(amazonSQS());
        var simpleMessageListenerContainer = factory .createSimpleMessageListenerContainer();
        simpleMessageListenerContainer.setMessageHandler(messageHandler());
        return simpleMessageListenerContainer;
    }

    @Bean(name = "messageHandler")
    public QueueMessageHandler messageHandler() {
        return Mockito.mock(QueueMessageHandler.class);
    }
}
