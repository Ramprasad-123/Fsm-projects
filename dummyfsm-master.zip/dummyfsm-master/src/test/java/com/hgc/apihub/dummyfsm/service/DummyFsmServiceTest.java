package com.hgc.apihub.dummyfsm.service;

//TODO sample code, to be removed/updated

import com.amazonaws.services.dynamodbv2.AmazonDynamoDBLockClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.lib.microservices.aws.fsm.configuration.DynamoDBConfig;
import com.hgc.lib.microservices.aws.fsm.model.AWSQueueMessagingTemplate;
import com.hgc.lib.microservices.aws.fsm.model.BasicDynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.configuration.APIMConfig;
import com.hgc.lib.microservices.exception.ResourceNotFoundException;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import com.hgc.apihub.dummyfsm.model.DummyFsmRequest;
import com.hgc.apihub.dummyfsm.model.DummyFsmResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.bind.annotation.RequestMethod;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;
import static com.hgc.apihub.dummyfsm.DummyFsmTestHelper.constructStateGraph;

@ExtendWith(SpringExtension.class)
class DummyFsmServiceTest {

    @MockBean
    private APIMConfig apimConfig;

    @MockBean
    private DynamoDBConfig dynamoDBConfig;

    @MockBean
    private DynamoDBMapper dynamoDBMapper;

    @MockBean
    private AWSQueueMessagingTemplate queueMessagingTemplate;

    @MockBean
    private AmazonDynamoDBLockClient amazonDynamoDBLockClient;

    private DummyFsmService dummyfsmService;

    @BeforeEach
    void setup() {
        var dao = new BasicDynamoDBDao(dynamoDBConfig, dynamoDBMapper, amazonDynamoDBLockClient);
        var serviceToSpy = new DummyFsmService(apimConfig, constructStateGraph(), dao, queueMessagingTemplate);
        dummyfsmService = Mockito.spy(serviceToSpy);
    }

    @Test
    void dependency() {
        Assertions.assertNotNull(dummyfsmService.getLOGGER());
        Assertions.assertNotNull(dummyfsmService.getApimConfig());
        Assertions.assertNotNull(dummyfsmService.getAwsStateGraph());
        Assertions.assertNotNull(dummyfsmService.getDynamoDBDao());
        Assertions.assertNotNull(dummyfsmService.getQueueMessagingTemplate());
    }

    @Test
    void createDummyFsm() throws Exception {
        // arrange
        var request = new DummyFsmRequest("Hello FSM");
        Mockito.when(apimConfig.getHost()).thenReturn("test-api.hgc.com.hk");
        Mockito.when(apimConfig.getScheme()).thenReturn("http");
        Mockito.when(apimConfig.getPort()).thenReturn("8080");
        // act
        var response = (AsyncStateResponse) dummyfsmService.createDummyFsm(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(202, response.getStatus());
        Assertions.assertEquals(State.ACCEPTED.toString(), response.getState());
        Assertions.assertNotNull(response.getTransactionId());
        Assertions.assertNotNull(response.getEventId());
        Assertions.assertNotNull(response.getLinks());
        Assertions.assertEquals(1, response.getLinks().size());
        Assertions.assertEquals("http://test-api.hgc.com.hk:8080/v1/transaction/" + response.getTransactionId() + "/event/" + response.getEventId(), response.getLinks().get(0).getHref());
        Assertions.assertEquals(RequestMethod.GET, response.getLinks().get(0).getMethod());
        Assertions.assertEquals("self", response.getLinks().get(0).getRelation());
    }

    @Test
    void getResponseByTransactionIdAndEventId() throws Exception {
        // arrange
        var data = new DummyFsmResponse(200, "ID0000021", "ID0000022", State.PROCESSED);
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) throws JsonProcessingException {
                return new DynamoDBEntity("ID0000021", "ID0000022", State.PROCESSED.toString(), SubState.ENTERED, OBJECT_MAPPER.writeValueAsString(data), null, null);
            }
        };
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).thenAnswer(answer);
        // act
        var response = (DummyFsmResponse) dummyfsmService.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022");
        // assert
        Assertions.assertNotNull(response);
        org.assertj.core.api.Assertions.assertThat(data).isEqualToIgnoringGivenFields(response);
    }

    @Test
    void getResponseByTransactionIdAndEventIdResourceNotFoundException() {
        // arrange
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return null;
            }
        };
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).thenAnswer(answer);
        // assert
        Assertions.assertThrows(ResourceNotFoundException.class, () -> dummyfsmService.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022"));
    }
}
