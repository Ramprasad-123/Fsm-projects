package com.hgc.apihub.hsbc.directdebit.model;

import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.hgc.apihub.hsbc.directdebit.model.dynamodb.DirectDebitPollDao;
import com.hgc.apihub.hsbc.directdebit.model.dynamodb.DirectDebitPollEntity;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.util.stream.Stream;

import static com.hgc.apihub.hsbc.directdebit.model.dynamodb.DirectDebitPollEntity.HSBC_POLL_TYPE;

class DirectDebitPollDaoTest {

    private DynamoDBMapper dynamoDBMapper;
    private DirectDebitPollDao directDebitPollDao;

    @BeforeEach
    void setup() {
        dynamoDBMapper = Mockito.mock(DynamoDBMapper.class);
        directDebitPollDao = new DirectDebitPollDao("test-poll", dynamoDBMapper);
    }

    @Test
    void getAll() throws Exception {
        // arrange
        var queryList = Mockito.mock(PaginatedQueryList.class);
        var item1 = new DirectDebitPollEntity("ID0000021", "ID0000022", "ID0000023", HSBC_POLL_TYPE, "abc123", 1, 10);
        var item2 = new DirectDebitPollEntity("ID0000021", "ID0000024", "ID0000025", HSBC_POLL_TYPE, "abc123", 1, 15);
        Mockito.when(queryList.size()).thenReturn(2);
        Mockito.when(queryList.get(0)).thenReturn(item1);
        Mockito.when(queryList.get(1)).thenReturn(item2);
        Mockito.when(queryList.stream()).thenReturn(Stream.of(item1, item2));
        Mockito.when(dynamoDBMapper.query(Mockito.eq(DirectDebitPollEntity.class), Mockito.any(DynamoDBQueryExpression.class), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(queryList);
        // act
        var items = directDebitPollDao.getAllByPollType(HSBC_POLL_TYPE);
        // assert
        Assertions.assertNotNull(items);
        org.assertj.core.api.Assertions.assertThat(item1).usingRecursiveComparison().isEqualTo(items.get(0));
        org.assertj.core.api.Assertions.assertThat(item2).usingRecursiveComparison().isEqualTo(items.get(1));
    }

    @Test
    void getByTransactionIdAndEventId() {
        // arrange
        var item = new DirectDebitPollEntity("ID0000021", "ID0000022", "ID0000023", HSBC_POLL_TYPE, "abc123", 1, 10);
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DirectDebitPollEntity.class), Mockito.anyString(), Mockito.anyString(), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(item);
        // act
        var result = directDebitPollDao.getByTransactionIdAndEventId("ID0000021", "ID0000022");
        // assert
        Assertions.assertNotNull(result);
        org.assertj.core.api.Assertions.assertThat(item).usingRecursiveComparison().isEqualTo(result);
    }

    @Test
    void save() {
        // arrange
        var item = new DirectDebitPollEntity("ID0000021", "ID0000022", "ID0000023", HSBC_POLL_TYPE, "abc123", 1, 10);
        var orderArgument = ArgumentCaptor.forClass(DirectDebitPollEntity.class);
        // act
        directDebitPollDao.save(item);
        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(1)).save(orderArgument.capture(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("ID0000021", orderArgument.getValue().getTransactionId());
        Assertions.assertEquals("ID0000022", orderArgument.getValue().getEventId());
    }

    @Test
    void delete() {
        // arrange
        var item = new DirectDebitPollEntity("ID0000021", "ID0000022", "ID0000023", HSBC_POLL_TYPE, "abc123", 1, 10);
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DirectDebitPollEntity.class), Mockito.anyString(), Mockito.anyString(), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(item);
        var orderArgument = ArgumentCaptor.forClass(DirectDebitPollEntity.class);
        // act
        directDebitPollDao.delete("ID0000021", "ID0000022");
        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(1)).delete(orderArgument.capture(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("ID0000021", orderArgument.getValue().getTransactionId());
        Assertions.assertEquals("ID0000022", orderArgument.getValue().getEventId());
    }
}
