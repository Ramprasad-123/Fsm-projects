package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Generated;
import lombok.Getter;

@Generated
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
public class CmhkTokenResponse {
    @JsonProperty("code")
    private final Integer code;
    @JsonProperty("message")
    private final String message;
    @JsonProperty("details")
    private final String details;
    @JsonProperty("expiresIn")
    private final String expiresIn;
    @JsonProperty("scope")
    private final String scope;
    @JsonProperty("accessToken")
    private final String accessToken;
    @JsonProperty("tokenType")
    private final String tokenType;
    @JsonProperty("jti")
    private final String jti;

    public CmhkTokenResponse(@JsonProperty("code") final Integer codeValue, @JsonProperty("message") final String messageValue, @JsonProperty("details") final String detailsValue, @JsonProperty("expiresIn") final String expiresInValue, @JsonProperty("scope") final String scopeValue, @JsonProperty("accessToken") final String accessTokenValue, @JsonProperty("tokenType") final String tokenTypeValue, @JsonProperty("jti") final String jtiValue) {
        code = codeValue;
        message = messageValue;
        details = detailsValue;
        expiresIn = expiresInValue;
        scope = scopeValue;
        accessToken = accessTokenValue;
        tokenType = tokenTypeValue;
        jti = jtiValue;
    }
}
