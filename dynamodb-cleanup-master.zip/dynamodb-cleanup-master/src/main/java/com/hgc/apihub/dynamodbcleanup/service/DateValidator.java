package com.hgc.apihub.dynamodbcleanup.service;

import org.springframework.util.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

import static com.hgc.apihub.dynamodbcleanup.DynamodbCleanupHelper.DATE_FORMATTER_YMDHMS;
import static com.hgc.apihub.dynamodbcleanup.DynamodbCleanupHelper.DATE_FORMAT_YMDHMS;
import static com.hgc.apihub.dynamodbcleanup.DynamodbCleanupHelper.ZONE_CODE_GMT8;


public class DateValidator implements ConstraintValidator<DateValidation, String> {

    private static final String INVALID_DATE_FORMAT_YMDHMS = "Invalid format, must be " + DATE_FORMAT_YMDHMS;
    private static final String INVALID_TIME_FRAME = "Value must be older then 1 year from now";

    @Override
    public boolean isValid(String requestParam, ConstraintValidatorContext constraintValidatorContext) {
        var isValid = true;
        LocalDateTime dateTime;

        if (!StringUtils.isEmpty(requestParam)) {
            try {
                dateTime = LocalDateTime.parse(requestParam, DATE_FORMATTER_YMDHMS);

                // Request time frame must be older than 1 year from now.
                var today = LocalDateTime.now(ZONE_CODE_GMT8).minusYears(1);
                if (dateTime.isAfter(today)) {
                    constraintValidatorContext.buildConstraintViolationWithTemplate(INVALID_TIME_FRAME)
                            .addConstraintViolation()
                            .disableDefaultConstraintViolation();
                    isValid = false;
                }
            } catch (DateTimeParseException dtpe) {
                constraintValidatorContext.buildConstraintViolationWithTemplate(INVALID_DATE_FORMAT_YMDHMS)
                        .addConstraintViolation()
                        .disableDefaultConstraintViolation();
                isValid = false;
            }
        }
        return isValid;
    }
}
