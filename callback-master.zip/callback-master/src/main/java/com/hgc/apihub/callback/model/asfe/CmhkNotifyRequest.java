package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Generated;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
@Getter
@Generated
public class CmhkNotifyRequest {

    @JsonProperty("params")
    private final Params params;

    public CmhkNotifyRequest(@JsonProperty("params") final Params paramsValue) {
        params = paramsValue;
    }

    @ToString
    @Getter
    @Generated
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Params {
        @JsonProperty("alarmId")
        private final String alarmId;
        @JsonProperty("addressCodes")
        private final String addressCodes;
        @JsonProperty("addressCodesList")
        private final List<String> addressCodesList;
        @JsonProperty("alarmType")
        private final String alarmType;
        @JsonProperty("alarmLevel")
        private final String alarmLevel;
        @JsonProperty("severity")
        private final String severity;
        @JsonProperty("action")
        private final String action;
        @JsonProperty("createTime")
        private final String createTime;
        @JsonProperty("actionTime")
        private final String actionTime;
        @JsonProperty("affectedPortType")
        private final String affectedPortType;
        @JsonProperty("targetResumeTime")
        private final String targetResumeTime;
        @JsonProperty("providerCode")
        private final String providerCode;

        public Params(@JsonProperty("alarmId") final String alarmIdValue, @JsonProperty("addressCodes") final String addressCodesValue,@JsonProperty("addressCodesList") final List<String> addressCodesList, @JsonProperty("alarmType") final String alarmTypeValue,
                      @JsonProperty("alarmLevel") final String alarmLevelValue, @JsonProperty("severity") final String severityValue, @JsonProperty("action") final String actionValue,
                      @JsonProperty("createTime") final String createTimeValue, @JsonProperty("actionTime") final String actionTimeValue, @JsonProperty("affectedPortType") final String affectedPortTypeValue,
                      @JsonProperty("targetResumeTime") final String targetResumeTimeValue, @JsonProperty("providerCode") final String providerCodeValue) {
            alarmId = alarmIdValue;
            addressCodes = addressCodesValue;
            this.addressCodesList = addressCodesList;
            alarmType = alarmTypeValue;
            alarmLevel = alarmLevelValue;
            severity = severityValue;
            action = actionValue;
            createTime = createTimeValue;
            actionTime = actionTimeValue;
            affectedPortType = affectedPortTypeValue;
            targetResumeTime = targetResumeTimeValue;
            providerCode = providerCodeValue;
        }
    }
}
