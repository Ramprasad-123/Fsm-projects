package com.hgc.apihub.dummyfsm.controller;

//TODO sample code, to be removed/updated

import com.hgc.apihub.dummyfsm.model.CurrentTime;
import com.hgc.apihub.dummyfsm.service.CommonUtils;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.apihub.dummyfsm.model.DummyFsmRequest;
import com.hgc.apihub.dummyfsm.model.DummyFsmResponse;
import com.hgc.apihub.dummyfsm.service.DummyFsmService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@WebMvcTest
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
class DummyFsmControllerTest {

    @MockBean
    private DummyFsmService dummyfsmService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void createDummyFsm() throws Exception {
        // arrange
        var response = new AsyncStateResponse(202, "ID0000021", "ID0000022", State.ACCEPTED.toString(), List.of(Link.withSelfRelation("https://apihub.hgc.com/test/ID0000021")));       // 2.1.0 update: Enum to String
        Mockito.when(dummyfsmService.createDummyFsm(Mockito.any(DummyFsmRequest.class))).thenReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.post("/v1")
        .contentType(MediaType.APPLICATION_JSON_VALUE)
        .content(OBJECT_MAPPER.writeValueAsString(new DummyFsmRequest(
                "Hello FSM"
        ))))
        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
        .andExpect(MockMvcResultMatchers.jsonPath("@.state").value(response.getState()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.transaction_id").value(response.getTransactionId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.event_id").value(response.getEventId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].relation").value(response.getLinks().get(0).getRelation()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].method").value(response.getLinks().get(0).getMethod().name()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].href").value(response.getLinks().get(0).getHref()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(202))
        .andExpect(MockMvcResultMatchers.status().isAccepted());
    }

    @Test
    void getDummyFsmByTransactionIdAndEventId() throws Exception {
        // arrange
        var response = new DummyFsmResponse(200, "ID0000021", "ID0000022", State.PROCESSED);
        Mockito.when(dummyfsmService.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022")).thenReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.get("/v1/transaction/ID0000021/event/ID0000022"))
        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
        .andExpect(MockMvcResultMatchers.jsonPath("@.transaction_id").value(response.getTransactionId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.event_id").value(response.getEventId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.state").value(response.getState()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
        .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void testSyncApi() throws Exception{
        // arrange
        var response = new ResponseEntity<>(new CurrentTime("2021-01-13 12:34:00"), HttpStatus.OK);
        Mockito.when(dummyfsmService.getCurrentTimeResponse()).thenReturn(response);

        //act
        this.mockMvc.perform(MockMvcRequestBuilders.get("/v1/syncApi").contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.current_date_time").value(response.getBody().getCurrentTime()))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
