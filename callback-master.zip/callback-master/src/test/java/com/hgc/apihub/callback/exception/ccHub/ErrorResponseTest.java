package com.hgc.apihub.callback.exception.ccHub;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

public class ErrorResponseTest {

    @Test
    void errorResponseTest() {

        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.OK, ExceptionHandlerType.CcHubDeleteOperationFailException);
        ErrorResponse errorResponse2 = new ErrorResponse("exception occurred", HttpStatus.OK, ExceptionHandlerType.CcHubDeleteOperationFailException);
        Assertions.assertNotNull(errorResponse);
        Assertions.assertEquals(10002, errorResponse.getCode());
        Assertions.assertNotNull(errorResponse.getReason());
        Assertions.assertNotNull(errorResponse.getMessage());
        Assertions.assertEquals(200, errorResponse.getStatus());
    }

}

