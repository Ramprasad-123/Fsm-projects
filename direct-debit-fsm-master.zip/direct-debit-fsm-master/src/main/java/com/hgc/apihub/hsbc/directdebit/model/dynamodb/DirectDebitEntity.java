package com.hgc.apihub.hsbc.directdebit.model.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.hgc.apihub.hsbc.directdebit.model.DirectDebitType;
import com.hgc.lib.core.HGCHelper;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBEntity;
import com.hgc.lib.microservices.statemachine.deliver.model.DeliverType;
import com.hgc.lib.microservices.statemachine.model.SubState;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DirectDebitEntity extends HGCDynamoDBEntity {

    @DynamoDBAttribute(attributeName = "request_base64")
    private String requestBase64;

    @DynamoDBAttribute(attributeName = "response_base64")
    private String responseBase64;

    public DirectDebitEntity(final String referenceId, final DirectDebitType type, final String transactionId, final String eventId, final String state, final SubState subState, final String data, final String callbackUrlValue) {
        super(type.name(), null, referenceId, null, transactionId, eventId, state, subState, data, DeliverType.CALLBACK, callbackUrlValue, null, null);
    }

    public DirectDebitEntity(final String referenceId, final DirectDebitType type, final String state, final SubState subState) {
        this(referenceId, type, HGCHelper.randomUUID(), HGCHelper.randomUUID(), state, subState, null, null);
    }

    public DirectDebitEntity(final DirectDebitType type, final String transactionId) {
        this(null, type, transactionId);
    }

    public DirectDebitEntity(final String referenceId, final DirectDebitType type, final String transactionId) {
        this(referenceId, type, transactionId, null, null, null, null, null);
    }
}
