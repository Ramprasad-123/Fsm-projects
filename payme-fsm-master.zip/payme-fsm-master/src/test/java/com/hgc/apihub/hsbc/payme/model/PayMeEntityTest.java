package com.hgc.apihub.hsbc.payme.model;

import com.hgc.apihub.hsbc.payme.model.dynamodb.PayMeEntity;
import com.hgc.lib.microservices.statemachine.deliver.model.DeliverType;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class PayMeEntityTest {

    @Test
    void buildClone() {
        // arrange
        var payme = new PayMeEntity(PayMeType.PAYMENT, PayMeSubType.REQUEST, "test-123");
        payme.setTransactionId("1234");
        payme.setEventId("1235");
        payme.setCorrelationId("1236");
        payme.setState(State.ACCEPTED.name());
        payme.setSubState(SubState.EXITED);
        payme.setDeliverType(DeliverType.CALLBACK);
        payme.setCallbackUrl("test.com");
        // act
        var clone = PayMeEntity.buildClone(payme, "1237", State.PROCESSED.name(), SubState.EXITED, PayMeType.PAYMENT, PayMeSubType.POLL, "test-124");
        // assert
        Assertions.assertNotNull(clone);
        Assertions.assertEquals(payme.getTransactionId(), clone.getTransactionId());
        Assertions.assertEquals("1237", clone.getEventId());
        Assertions.assertEquals(payme.getCorrelationId(), clone.getCorrelationId());
        Assertions.assertEquals(State.PROCESSED.name(), clone.getState());
        Assertions.assertEquals(SubState.EXITED, clone.getSubState());
        Assertions.assertEquals(payme.getDeliverType(), clone.getDeliverType());
        Assertions.assertEquals(payme.getCallbackUrl(), clone.getCallbackUrl());
        Assertions.assertNull(clone.getCallbackAuthType());
        Assertions.assertNull(clone.getCallbackAuthSecret());
        Assertions.assertEquals(PayMeType.PAYMENT, clone.getType());
        Assertions.assertEquals(PayMeSubType.POLL, clone.getSubType());
        Assertions.assertEquals("test-124", clone.getRequestId());
    }
}
