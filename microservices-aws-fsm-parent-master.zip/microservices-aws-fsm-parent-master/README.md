# HGC Microservices AWS FSM parent POM

HGC parent POM for Microservices AWS FSM build on Spring boot

## Getting Started

For understanding the project source code, the following knowledge will be helpful in no particular order:
* Maven
* Spring Framework
* Git

The list above is not an exhaustive list

### Prerequisites

* [Git](https://git-scm.com/) is installed. Required for checking out the source code

### Installing

To obtain a local copy of the master branch of the repository, you can run the following command
```
git clone git@gitlab.hk:hgc/hgc-groups/hgc-global-communications/templates/microservices-aws-fsm-parent.git
```

## Usage

```
<parent>
    <groupId>com.hgc</groupId>
    <artifactId>microservices-aws-fsm-parent</artifactId>
    <version>4.1.0</version>
</parent>
```

Mandatory property you need to set:
```
<properties>
    <base-package>com/hgc</base-package>
</properties>
```

### HGC Dependencies

Make sure these HGC dependencies are build locally or available at any maven repositories before building you GraphQL application:
* **artifactId; microservices-state-machine** - groupId; com.hgc.lib, version; 4.1.0
* **artifactId; microservices-aws-fsm** - groupId; com.hgc.lib, version; 3.1.0

To override the version at project pom you just need to add it as a property:
```
<properties>
    <microservices-state-machine.version>2.0.0</microservices-core.version>
</properties>
```

### Plugin Management

The parent pom manages all the needed plugins including site related build and report plugins. You can update/remove them from application pom.xml

#### Properties

* **jacoco.skip** - skip jacoco report creation, default false
* **checkstyle.skip** - skip checkstyle report creation, default false
* **spotbugs.skip** - skip spotbugs report creation, default false
* **pmd.skip** - skip pmd report creation, default false
* **cpd.skip** - skip cpd report creation, default false

* **base-package** - your application base package, default value is invalid and hence is a mandatory field
* **spotbugs.failOnError** - fail build if spotbugs report has bugs found, default true
* **spotbugs.maxHeap** - max heap assigned for spotbugs report, default 512
* **spotbugs.timeout** - max timeout assigned for spotbugs report, default 600000 ms
* **jacoco.percentage.instruction** - fail build if jacoco report does not cover to the given percentage, i.e test coverage, default 0.90 (90%) 

### Migration

To migrate existing project to use the parent pom is simple:
* select the correct version of the parent pom
* add to parent tag
* remove all dependencies moved to parent pom
* remove version tag for all the dependencies under parent's dependency management
* remove all build and report plugins, ideally only need the below build plugin
```
<build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-dependency-plugin</artifactId>
        </plugin>
    </plugins>
</build>
```

Your final pom.xml can be as short as below (only need to include the DB dependency):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>com.hgc</groupId>
        <artifactId>microservices-aws-fsm-parent</artifactId>
        <version>4.1.0</version>
    </parent>
    <groupId>com.hgc.apihub</groupId>
    <artifactId>test-fsm</artifactId>
    <version>1.0.0</version>
    <name>HGC Test FSM</name>
    <description>Microservice build on spring boot to initiate and process test FSM</description>
    <url>https://jihulab.com/hgc-groups/hgc-global-communications/api-hub/test-fsm</url>

    <organization>
        <name>HGC Global Communications Limited</name>
        <url>https://www.hgc.com.hk/en/</url>
    </organization>

    <properties>
        <base-package>com/hgc/apihub/testfsm</base-package>
    </properties>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-dependency-plugin</artifactId>
            </plugin>
        </plugins>
    </build>

    <repositories>
        <repository>
            <id>central</id>
            <url>https://repo1.maven.org/maven2</url>
        </repository>
        <repository>
            <id>central-apache</id>
            <url>https://repo.maven.apache.org/maven2</url>
        </repository>
        <repository>
            <id>templates-maven</id>
            <url>https://jihulab.com/api/v4/groups/121985/-/packages/maven</url>
        </repository>
        <repository>
            <id>libraries-maven</id>
            <url>https://jihulab.com/api/v4/groups/121982/-/packages/maven</url>
        </repository>
    </repositories>
</project>
```
## Built With

* [Maven](https://maven.apache.org/) - Dependency Management
    * [Maven Wrapper](https://maven.apache.org/wrapper/) is also included in the project
* [Spring Boot 3.2.0](https://spring.io/projects/spring-boot) - Spring framework

## Authors

* **Sooraj Mohanan** - [\<Sooraj.Mohanan@hgc.com.hk\>](mailto:Sooraj.Mohanan@hgc.com.hk)

## Copyright

Copyright &copy; 2023, [HGC Global Communications Limited](http://www.hgc.com.hk/Home/Index-en.html)
All rights reserved
