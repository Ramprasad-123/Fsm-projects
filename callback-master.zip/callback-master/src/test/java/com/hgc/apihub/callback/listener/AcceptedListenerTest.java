package com.hgc.apihub.callback.listener;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.apihub.callback.AsfeTestHelper;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.lib.core.exception.ResourceNotFoundException;
import com.hgc.lib.microservices.aws.fsm.common.AWSQueueEntryNodeListenerTest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

import static com.hgc.apihub.callback.AsfeTestHelper.getAsfeAsyncResponse;
import static com.hgc.apihub.callback.AsfeTestHelper.getOutageEndRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getOutageStartRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getScheduledMaintenanceStartRequest;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@ExtendWith(SpringExtension.class)
class AcceptedListenerTest extends AWSQueueEntryNodeListenerTest {

    private AcceptedListener service;

    @BeforeEach
    void setup() {
        this.init();
        service = new AcceptedListener();
        this.setDependencies(service);
    }

    @Override
    protected AWSStateGraph constructStateGraph() {
        return AsfeTestHelper.constructStateGraph();
    }

    @Test
    void dependency() {
        Assertions.assertNotNull(service.getLOGGER());
    }

    @Test
    void createScheduledMaintenance() throws Exception {
        // arrange
        var request = getScheduledMaintenanceStartRequest();
        // act
        var response = (AsfeAsyncStateResponse) service.createScheduledMaintenance(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(202, response.getStatus());
        Assertions.assertEquals(State.ACCEPTED.name(), response.getState());
        Assertions.assertNotNull(response.getTransactionId());
        Assertions.assertNotNull(response.getEventId());
        Assertions.assertNotNull(response.getLinks());
        Assertions.assertEquals(1, response.getLinks().size());
        Assertions.assertEquals("http://test-api.hgc.com.hk:8080/v1/asfe/scheduledMaintenance/transaction/" + response.getTransactionId() + "/event/" + response.getEventId(), response.getLinks().get(0).getHref());
        Assertions.assertEquals(RequestMethod.GET, response.getLinks().get(0).getMethod());
        Assertions.assertEquals("self", response.getLinks().get(0).getRelation());
        Assertions.assertEquals(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE), response.getRemainingSubTypes());
    }

    @Test
    void getResponseByTransactionIdAndEventId() throws Exception {
        // arrange
        var data = getAsfeAsyncResponse();
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) throws JsonProcessingException {
                return new DynamoDBEntity("ID0000021", "ID0000022", State.PROCESSED.name(), SubState.ENTERED, OBJECT_MAPPER.writeValueAsString(data), null, null);
            }
        };
        BDDMockito.given(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).willAnswer(answer);
        // act
        var response = (AsfeAsyncStateResponse) service.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022");
        // assert
        Assertions.assertNotNull(response);
        org.assertj.core.api.Assertions.assertThat(response).usingRecursiveComparison().isEqualTo(data);
    }

    @Test
    void getResponseByTransactionIdAndEventIdResourceNotFoundException() {
        // arrange
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return null;
            }
        };
        BDDMockito.given(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).willAnswer(answer);
        // assert
        Assertions.assertThrows(ResourceNotFoundException.class, () -> service.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022"));
    }

    @Test
    void startOutage() throws Exception {
        // arrange
        var request = getOutageStartRequest();
        // act
        var response = (AsfeAsyncStateResponse) service.startOutage(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(202, response.getStatus());
        Assertions.assertEquals(State.ACCEPTED.name(), response.getState());
        Assertions.assertNotNull(response.getTransactionId());
        Assertions.assertNotNull(response.getEventId());
        Assertions.assertNotNull(response.getLinks());
        Assertions.assertEquals(1, response.getLinks().size());
        Assertions.assertEquals("http://test-api.hgc.com.hk:8080/v1/asfe/outage/transaction/" + response.getTransactionId() + "/event/" + response.getEventId(), response.getLinks().get(0).getHref());
        Assertions.assertEquals(RequestMethod.GET, response.getLinks().get(0).getMethod());
        Assertions.assertEquals("self", response.getLinks().get(0).getRelation());
        Assertions.assertEquals(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE), response.getRemainingSubTypes());
    }

    @Test
    void endOutage() throws Exception {
        // arrange
        var request = getOutageEndRequest();
        // act
        var response = (AsfeAsyncStateResponse) service.endOutage(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(202, response.getStatus());
        Assertions.assertEquals(State.ACCEPTED.name(), response.getState());
        Assertions.assertNotNull(response.getTransactionId());
        Assertions.assertNotNull(response.getEventId());
        Assertions.assertNotNull(response.getLinks());
        Assertions.assertEquals(1, response.getLinks().size());
        Assertions.assertEquals("http://test-api.hgc.com.hk:8080/v1/asfe/outage/transaction/" + response.getTransactionId() + "/event/" + response.getEventId(), response.getLinks().get(0).getHref());
        Assertions.assertEquals(RequestMethod.GET, response.getLinks().get(0).getMethod());
        Assertions.assertEquals("self", response.getLinks().get(0).getRelation());
        Assertions.assertEquals(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE), response.getRemainingSubTypes());
    }
}