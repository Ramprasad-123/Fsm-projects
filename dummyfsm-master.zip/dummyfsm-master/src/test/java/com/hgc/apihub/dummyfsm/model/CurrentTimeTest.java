package com.hgc.apihub.dummyfsm.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class CurrentTimeTest {
    @Test
    public void testCurrentTime() {
        // arrange
        var model = new CurrentTime("2020-01-13 12:34:56");

        // assert
        Assertions.assertEquals("2020-01-13 12:34:56", model.getCurrentTime());
    }
}
