# DynamoDb Cleanup

Microservice build on spring boot for HGC

## Getting Started

For understanding the project source code, the following knowledge will be helpful in no particular order:
* Java
* Maven
* Spring Framework
* Git
* Log4j2

The list above is not an exhaustive list.

### Prerequisites

* [Git](https://git-scm.com/) is installed. Required for checking out the source code.
* [JDK 13](https://jdk.java.net/13/) is installed. Required for development and running the project.

### Installing

To obtain a local copy of the master branch of the repository, you can run the following command.
```
git clone git@gitlab.com:hgc-global-communications/api-hub/dynamodb-cleanup.git
```

### Development


### Build


## Built With

* [JDK 13](https://jdk.java.net/13/) - The core project built on JVM
* [Maven](https://maven.apache.org/) - Dependency Management
* [Spring Boot 2.3.3](https://spring.io/projects/spring-boot) - Spring framework

## Versioning


## Authors

* **Wai Yan Oo** - [\<waiyan@thrymr.net\>](mailto:waiyan@thrymr.net)

## Copyright

Copyright &copy; 2018, [HGC Global Communications Limited](http://www.hgc.com.hk/Home/Index-en.html).
All rights reserved.