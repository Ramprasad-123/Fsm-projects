package com.hgc.apihub.dynamodbcleanup.dao;

import com.hgc.apihub.dynamodbcleanup.model.ZuoraApiLog;
import com.hgc.apihub.graphqltnssfbi.client.queries.ReadZuoraApiLogsQuery;
import com.hgc.apihub.graphqltnssfbi.client.type.Criteria;
import com.hgc.apihub.graphqltnssfbi.client.type.FilterParameter;
import com.hgc.apihub.graphqltnssfbi.client.type.Operator;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.exception.GraphQLQueryException;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor
public class TnssFbiDao {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(TnssFbiDao.class);

    private final GraphQLTemplate graphQLTnssFbiTemplate;

    private static final String CREATE_DATE = "createDate";

    public ArrayList<ZuoraApiLog> getRecords(final String startDate, final String endDate) throws GraphQLQueryException {
        ArrayList<ZuoraApiLog> resultList = new ArrayList<>();
        ArrayList<FilterParameter> filterParamList = new ArrayList<>();

        filterParamList.add(FilterParameter.builder()
                .field(CREATE_DATE)
                .criteria(Criteria.GREATER_THAN_OR_EQUAL_TO)
                .values(List.of(startDate))
                .operator(Operator.AND)
                .build());
        filterParamList.add(FilterParameter.builder()
                .field(CREATE_DATE)
                .criteria(Criteria.LESS_THAN_OR_EQUAL_TO)
                .values(List.of(endDate))
                .operator(Operator.AND)
                .build());
        var query = ReadZuoraApiLogsQuery.builder()
                .filters(filterParamList)
                .withApiTransactionId(true)
                .withCreateDate(true)
                .build();
        var queryResponse = graphQLTnssFbiTemplate.query(query);
        if (queryResponse.hasErrors()) {
            LOGGER.unify(Level.ERROR, "ReadZuoraApiLogsQuery GraphQL receives error response: " + queryResponse.getErrors());
            throw new GraphQLQueryException("An error occurred while querying to GraphQL Server. Please try again after some time.");
        }
        var queryResult = Optional.ofNullable(queryResponse.getData()).stream()
                .flatMap(Optional::stream)
                .map(ReadZuoraApiLogsQuery.Data::getReadZuoraApiLogs)
                .flatMap(Optional::stream)
                .map(ReadZuoraApiLogsQuery.ReadZuoraApiLogs::getFragments)
                .findFirst()
                .stream()
                .map(ReadZuoraApiLogsQuery.ReadZuoraApiLogs.Fragments::getZuoraApiLogsFields)
                .findAny();
        if (queryResult.isPresent() && queryResult.get().getZuoraApiLogs().isPresent() && !CollectionUtils.isEmpty(queryResult.get().getZuoraApiLogs().get())) {
            for (var a : queryResult.get().getZuoraApiLogs().get()) {
                var zuoraApiLog = new ZuoraApiLog();
                var fragments = a.getFragments().getZuoraApiLogFields();
                zuoraApiLog.setApiTransactionId(fragments.getApiTransactionId().orElse(null));
                zuoraApiLog.setCreateDate(fragments.getCreateDate().orElse(null));
                resultList.add(zuoraApiLog);
            }
        }
        return resultList;
    }
}
