package com.hgc.apihub.fsmadapter.controller;

import com.hgc.apihub.fsmadapter.exception.AdapterExceptionHandlerType;
import com.hgc.apihub.fsmadapter.model.AdapterResponse;
import com.hgc.apihub.fsmadapter.model.InitiateMessageRequest;
import com.hgc.apihub.fsmadapter.model.MessageRequest;
import com.hgc.apihub.fsmadapter.service.MessageService;
import com.hgc.lib.core.exception.ResourceNotFoundException;
import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import com.hgc.lib.microservices.model.Response;
import io.awspring.cloud.sqs.operations.MessagingOperationFailedException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import software.amazon.awssdk.services.sqs.model.QueueDoesNotExistException;

import static com.hgc.apihub.fsmadapter.AdapterTestHelper.*;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@WebMvcTest(MessageController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@Import(SanitizedExceptionHandler.class)
public class MessageControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MessageService messageService;

    @Test
    void sendMessage() throws Throwable {
        // arrange
        BDDMockito.given(messageService.sendMessage(Mockito.any(MessageRequest.class))).willReturn(new Response(HttpStatus.OK));
        // act
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/message")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getMessageRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void sendMessageQueueDoesNotExist() throws Throwable {
        // arrange
        BDDMockito.given(messageService.sendMessage(Mockito.any(MessageRequest.class))).willThrow(QueueDoesNotExistException.builder().message("test").build());
        // act
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/message")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getMessageRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    @Test
    void sendMessageOperationFailed() throws Throwable {
        // arrange
        BDDMockito.given(messageService.sendMessage(Mockito.any(MessageRequest.class))).willThrow(new MessagingOperationFailedException("test", "test-queue"));
        // act
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/message")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getMessageRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.MessagingOperationFailedException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.MessagingOperationFailedException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.MessagingOperationFailedException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.MessagingOperationFailedException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isInternalServerError());
        // arrange
        BDDMockito.given(messageService.sendMessage(Mockito.any(MessageRequest.class))).willThrow(new MessagingOperationFailedException("test", "test-queue", QueueDoesNotExistException.builder().message("test").build()));
        // act
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/message")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getMessageRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.QueueDoesNotExistException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    @Test
    void initiateMessage() throws Throwable {
        // arrange
        var response = new AdapterResponse(HttpStatus.ACCEPTED.value(), "test");
        response.setHref("https://apihub.hgc.com/test/abc123");
        BDDMockito.given(messageService.initiateMessage(Mockito.any(InitiateMessageRequest.class))).willReturn(response);
        // act
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/message/initiate")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getInitiateMessageRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.header().string(HttpHeaders.LOCATION, "https://apihub.hgc.com/test/abc123"))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body").value(response.getBody()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(202))
                .andExpect(MockMvcResultMatchers.status().isAccepted());
    }

    @Test
    void initiateMessageResourceNotFound() throws Throwable {
        // arrange
        BDDMockito.given(messageService.initiateMessage(Mockito.any(InitiateMessageRequest.class))).willThrow(new ResourceNotFoundException("test"));
        // act
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/message/initiate")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getInitiateMessageRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.ResourceNotFoundException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.ResourceNotFoundException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.ResourceNotFoundException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.ResourceNotFoundException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    @Test
    void getByTransactionIdAndEventId() throws Exception {
        var response = new AdapterResponse(HttpStatus.OK.value(), "test");
        BDDMockito.given(messageService.getByTransactionIdAndEventId(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt())).willReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.get("/v1/message/transaction/ID0000021/event/ID0000022?table_name=test_fsm&retry_after=5"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body").value(response.getBody()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void getByTransactionIdAndEventIdAsync() throws Exception {
        var response = new AdapterResponse(HttpStatus.ACCEPTED.value(), "test");
        response.setHref("https://apihub.hgc.com/test/abc123");
        BDDMockito.given(messageService.getByTransactionIdAndEventId(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt())).willReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.get("/v1/message/transaction/ID0000021/event/ID0000022?table_name=test_fsm&retry_after=5"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.header().string(HttpHeaders.LOCATION, "https://apihub.hgc.com/test/abc123"))
                .andExpect(MockMvcResultMatchers.jsonPath("@.body").value(response.getBody()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(202))
                .andExpect(MockMvcResultMatchers.status().isAccepted());
    }
}
