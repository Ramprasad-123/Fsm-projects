package com.hgc.apihub.hsbc.directdebit.model;

import java.time.LocalDateTime;

public interface PollEntity {

    String getTransactionId();

    String getEventId();

    String getCorrelationId();

    String getProfileId();

    Integer getStartingDay();

    Integer getExpirationDay();

    LocalDateTime getCreateDate();
}
