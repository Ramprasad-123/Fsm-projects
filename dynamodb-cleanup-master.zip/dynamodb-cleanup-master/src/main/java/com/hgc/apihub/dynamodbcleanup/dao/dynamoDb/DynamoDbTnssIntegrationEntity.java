package com.hgc.apihub.dynamodbcleanup.dao.dynamoDb;

import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import lombok.Getter;

@Getter
public class DynamoDbTnssIntegrationEntity  extends DynamoDBEntity {

    //Needed empty constructorm otherwise com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMappingException: could not instantiate class
    public DynamoDbTnssIntegrationEntity() {
    }

}
