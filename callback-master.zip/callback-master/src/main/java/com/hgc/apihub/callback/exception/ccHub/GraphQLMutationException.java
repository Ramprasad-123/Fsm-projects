package com.hgc.apihub.callback.exception.ccHub;

public class GraphQLMutationException extends Exception {

    public GraphQLMutationException(final String message) {
        super(message);
    }
}
