package com.hgc.apihub.hsbc.directdebit.model;

import org.springframework.util.StringUtils;

import java.util.Arrays;

public enum DirectDebitType {

    AUTHORIZATION_INITIATE("authorization initiate"),
    AUTHORIZATION_UPDATE("authorization update"),
    AUTHORIZATION_SETUP("authorization setup"),
    AUTHORIZATION_OTP_CONFIRMATION("authorization OTP confirmation"),
    AUTHORIZATION_OTP_REGENERATION("authorization OTP regeneration"),
    AUTHORIZATION_STATUS("authorization status"),
    REPORTS("reports");

    private final String description;

    DirectDebitType(final String descriptionValue) {
        this.description = descriptionValue;
    }

    public static DirectDebitType fromValue(final String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return Arrays.stream(DirectDebitType.values())
                .filter(e -> value.equalsIgnoreCase(e.name()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(String.format("does not support value %s!", value)));
    }

    public static boolean authorizationFSMType(final DirectDebitType type) {
        return AUTHORIZATION_INITIATE == type || AUTHORIZATION_UPDATE == type ||  AUTHORIZATION_OTP_CONFIRMATION == type ||  AUTHORIZATION_OTP_REGENERATION == type;
    }

    @Override
    public String toString() {
        return this.description;
    }
}
