package com.hgc.apihub.callback.model.asfe;

import com.hgc.lib.microservices.common.validation.BlankValidationTest;

import java.util.List;

import static com.hgc.apihub.callback.AsfeTestHelper.getSchMaint;
import static com.hgc.apihub.callback.AsfeTestHelper.getSchMaintViolateBlanks;

public class SchMaintTest implements BlankValidationTest<ScheduledMaintenanceRequest.SchMaint> {
    @Override
    public List<ScheduledMaintenanceRequest.SchMaint> blankInstances() {
        return List.of(getSchMaintViolateBlanks());
    }

    @Override
    public List<Integer> numberOfNonBlankAnnotations() {
        return List.of(2);
    }

    @Override
    public ScheduledMaintenanceRequest.SchMaint validInstance() {
        return getSchMaint();
    }
}
