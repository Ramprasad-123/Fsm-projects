package com.hgc.apihub.hsbc.directdebit.model.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBPollEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DirectDebitPollEntity extends HGCDynamoDBPollEntity {

    public static final String HSBC_POLL_TYPE = "DDA_HSBC";
    public static final String NON_HSBC_POLL_TYPE = "DDA_NON_HSBC";

    @DynamoDBAttribute(attributeName = "profile_id")
    private String profileId;

    public DirectDebitPollEntity(final String transactionId, final String eventId, final String correlationId, final String pollType, final String profileIdValue, final Integer startingDay, final Integer expirationDay) {
        super(transactionId, eventId, correlationId, pollType, startingDay, expirationDay);
        this.profileId = profileIdValue;
    }
}
