package com.hgc.apihub.fsmadapter;

import com.hgc.apihub.fsmadapter.configuration.RedisAsyncConfiguration;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestOperations;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class ApplicationTest {

    @MockBean
    private AWSStateGraph awsStateGraph;

    @MockBean
    private BuildProperties buildProperties;

    @Autowired
    private RestOperations basicRestOperations;

    @Autowired
    private RedisAsyncConfiguration redisAsyncConfiguration;

    @Test
    void configuration() {
        // assert
        Assertions.assertNotNull(basicRestOperations);
        Assertions.assertNotNull(redisAsyncConfiguration);
    }
}
