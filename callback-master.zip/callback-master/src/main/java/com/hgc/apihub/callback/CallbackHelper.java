package com.hgc.apihub.callback;

import com.apollographql.apollo.api.Error;
import com.hgc.lib.core.HGCHelper;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class CallbackHelper {

    public static final String ERROR_LIST_IS_EMPTY = "Error list is empty";

    public static String getError(final List<Error> errors) {
        if (errors != null) {
            return errors.stream()
                    .map(Error::getMessage)
                    .filter(message -> !StringUtils.hasLength(message))
                    .collect(Collectors.joining(", "));
        }
        return ERROR_LIST_IS_EMPTY;
    }

    public static String parseRemarksAndAddTime(final String remarks) {
        return LocalDateTime.parse(remarks, DateTimeFormatter.ofPattern(HGCHelper.DATE_TIME_FORMAT)).plusHours(6).format(DateTimeFormatter.ofPattern(HGCHelper.DATE_TIME_FORMAT));
    }
}
