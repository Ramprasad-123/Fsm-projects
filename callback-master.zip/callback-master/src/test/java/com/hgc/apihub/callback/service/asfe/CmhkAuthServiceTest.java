package com.hgc.apihub.callback.service.asfe;

import com.hgc.apihub.callback.configuration.CmhkConfig;
import com.hgc.apihub.callback.exception.asfe.CmhkTokenException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestOperations;

import static com.hgc.apihub.callback.AsfeTestHelper.getCmhkTokenResponse;
import static com.hgc.apihub.callback.AsfeTestHelper.getCmhkTokenResponseNoExpiresIn;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@ExtendWith(SpringExtension.class)
class CmhkAuthServiceTest {

    private CmhkAuthService service;

    @MockBean
    private RestOperations restOperations;

    @MockBean
    private CmhkConfig config;

    @BeforeEach
    public void setup() {
        Mockito.when(config.getHost()).thenReturn("test");
        Mockito.when(config.getTokenUrl()).thenReturn("test");
        Mockito.when(config.getAppId()).thenReturn("test");
        Mockito.when(config.getAppSecret()).thenReturn("test");
        restOperations = Mockito.mock(RestOperations.class);
        var serviceToSpy = new CmhkAuthService(restOperations, config);
        service = Mockito.spy(serviceToSpy);
    }

    @Test
    void getNewTokenTestExpiresInNotPresent() throws Exception {
        // arrange
        var token = getCmhkTokenResponseNoExpiresIn();
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.OK);
        Mockito.when(expected.getBody()).thenReturn(OBJECT_MAPPER.writeValueAsString(token));
        mockGetTokenCall(expected);
        // act
        var actual = service.getToken();
        // assert
        Assertions.assertNotNull(actual);
        Assertions.assertEquals("access_token_value", actual);
    }

    @Test
    void getNewTokenTest() throws Exception {
        // arrange
        var token = getCmhkTokenResponse();
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.OK);
        Mockito.when(expected.getBody()).thenReturn(OBJECT_MAPPER.writeValueAsString(token));
        mockGetTokenCall(expected);
        // act
        var actual = service.getToken();
        // assert
        Assertions.assertNotNull(actual);
        Assertions.assertEquals("access_token_value", actual);
    }

    @Test
    void getTokenSuccessWithGeneratedToken() throws Exception {
        // arrange
        var token = getCmhkTokenResponse();
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.OK);
        Mockito.when(expected.getBody()).thenReturn(OBJECT_MAPPER.writeValueAsString(token));
        mockGetTokenCall(expected);
        // act
        var actual = service.getToken();
        // assert
        Assertions.assertNotNull(actual);
        Assertions.assertEquals("access_token_value", actual);

        // arrange
        // act
        actual = service.getToken(); // calling again so it would return the previously generated token.
        // assert
        Assertions.assertNotNull(actual);
        Assertions.assertEquals("access_token_value", actual);
    }

    @Test
    void getTokenInternalServerErrorTest() throws Exception {
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.OK);
        Mockito.when(expected.getBody()).thenReturn(OBJECT_MAPPER.writeValueAsString(null));
        mockGetTokenCall(expected);
        // act
        var thrown = Assertions.assertThrows(CmhkTokenException.class, () -> service.getToken());
        // assert
        Assertions.assertEquals("Response body not present.", thrown.getMessage());

        // arrange
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.TOO_MANY_REQUESTS);
        // act
        thrown = Assertions.assertThrows(CmhkTokenException.class, () -> service.getToken());
        // assert
        Assertions.assertEquals("CMHK get token failed.", thrown.getMessage());
    }

    private void mockGetTokenCall(ResponseEntity expected) {
        Mockito.when(restOperations.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                (Class<Object>) ArgumentMatchers.any()
        )).thenReturn(expected);
    }
}