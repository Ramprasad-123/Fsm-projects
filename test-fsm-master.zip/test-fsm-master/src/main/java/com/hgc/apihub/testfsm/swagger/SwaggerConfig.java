package com.hgc.apihub.testfsm.swagger;

import com.hgc.lib.microservices.swagger.AbstractSwaggerConfig;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig extends AbstractSwaggerConfig  {

    @Bean
    public GroupedOpenApi publicApi() {
        // optional if needed to group and filter by paths or package or both or none
        return GroupedOpenApi.builder()
                .group("test-fsm")
                .packagesToScan("com.hgc.apihub.testfsm.controller")
                .addOpenApiCustomiser(this.openApiCustomiser())
                .build();
    }

    @Override
    public final String apiInfoDescription() {
        return "Microservice build on spring boot to test FSM";
    }
}
