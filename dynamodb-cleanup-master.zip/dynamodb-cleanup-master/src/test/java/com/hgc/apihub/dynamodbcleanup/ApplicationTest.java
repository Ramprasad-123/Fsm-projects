package com.hgc.apihub.dynamodbcleanup;

import com.hgc.apihub.dynamodbcleanup.configuration.A2pGraphQLConfig;
import com.hgc.apihub.dynamodbcleanup.configuration.GraphQLTnssFbiConfig;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestOperations;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class ApplicationTest {

    @Autowired
    private A2pGraphQLConfig graphQLA2pSmsConfig;

    @Autowired
    private GraphQLTemplate a2pGraphQLTemplate;

    @Autowired
    private GraphQLTnssFbiConfig graphQLFbiConfig;

    @Autowired
    private GraphQLTemplate graphQLTnssFbiTemplate;

    @MockBean
    private BuildProperties buildProperties;

    @Autowired
    private RestOperations restOperations;

    @MockBean
    private AWSStateGraph awsStateGraph;

    @Test
    void configuration() {
        // assert
        Assertions.assertNotNull(graphQLA2pSmsConfig);
        Assertions.assertEquals("http://test/graphql-a2p/graphql", graphQLA2pSmsConfig.getUrl());
        Assertions.assertEquals(10, graphQLA2pSmsConfig.getConnectTimeout());
        Assertions.assertEquals(30, graphQLA2pSmsConfig.getReadTimeout());
        Assertions.assertEquals(30, graphQLA2pSmsConfig.getWriteTimeout());
        Assertions.assertNotNull(a2pGraphQLTemplate);
        Assertions.assertNotNull(restOperations);

        // assert
        Assertions.assertNotNull(graphQLFbiConfig);
        Assertions.assertEquals("http://test/graphql-tnss-fbi/graphql", graphQLFbiConfig.getUrl());
        Assertions.assertEquals(10, graphQLFbiConfig.getConnectTimeout());
        Assertions.assertEquals(30, graphQLFbiConfig.getReadTimeout());
        Assertions.assertEquals(30, graphQLFbiConfig.getWriteTimeout());
        Assertions.assertNotNull(graphQLTnssFbiTemplate);
    }
}
