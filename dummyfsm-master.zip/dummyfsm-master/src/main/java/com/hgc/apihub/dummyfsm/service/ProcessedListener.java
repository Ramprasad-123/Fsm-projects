package com.hgc.apihub.dummyfsm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.apihub.dummyfsm.model.DummyFsmRequest;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.service.BasicAWSProcessedListener;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.StateResponse;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
public class ProcessedListener extends BasicAWSProcessedListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(ProcessedListener.class);

    /*public ProcessedListener(final AWSStateGraph stateGraph, final LogConsolidation logConsolidation, final DynamoDBDao<? extends DynamoDBEntity> dynamoDBDao,
                             final AWSQueueMessagingTemplate queueMessagingTemplate) {
        super(stateGraph, logConsolidation, dynamoDBDao, queueMessagingTemplate);
    }*/

    @Override
    public final QueueListenerRequest<? extends QueueListenerBody> deserializeBody(final String body) throws Exception {
        return OBJECT_MAPPER.readValue(body, new TypeReference<QueueListenerRequest<DummyFsmRequest>>() {
        });
    }

    @Override
    public final void executeClean(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) throws Exception {
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Execute Processed ENTERED");
        Thread.sleep(10000);
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Execute Processed EXITED after sleep for 10s");
        //builder.stateData(new StateResponse(200, request.getTransactionId(), request.getEventId(), builder.getState()));
        builder.stateData(new StateResponse(200, request.getTransactionId(), request.getEventId(), builder.getState()));
    }

    @Override
    public final void executeDirty(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) throws Exception {

    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }
}
