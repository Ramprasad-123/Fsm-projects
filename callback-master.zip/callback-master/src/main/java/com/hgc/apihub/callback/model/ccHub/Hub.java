package com.hgc.apihub.callback.model.ccHub;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Wai Yan Oo on 5/11/20
 */

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
public class Hub implements Serializable {

    @JsonProperty(value = "id")
    @Schema(description = "Hub id", example = "")
    private Integer id;

    @JsonProperty(value = "apim_x_user_id")
    @Schema(description = "Apim X User Id", example = "")
    private String apimXUserId;

    @JsonProperty(value = "query")
    @Schema(description = "Notification type", example = "")
    private String query;

    @JsonProperty(value = "callback")
    @Schema(description = "Callback URL", example = "")
    private String callback;

    @JsonProperty(value = "create_date")
    @Schema(description = "Creation Date", example = "")
    private String createDate;

    @JsonProperty(value = "create_by")
    @Schema(description = "User who created this entity", example = "")
    private String createBy;

    @JsonProperty(value = "update_date")
    @Schema(description = "Updated date", example = "")
    private String updateDate;

    @JsonProperty(value = "update_by")
    @Schema(description = "User who last updated this entity", example = "")
    private String updateBy;

}
