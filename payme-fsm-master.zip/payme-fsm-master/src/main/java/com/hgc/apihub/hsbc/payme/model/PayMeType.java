package com.hgc.apihub.hsbc.payme.model;

public enum PayMeType {

    PAYMENT, REFUND
}
