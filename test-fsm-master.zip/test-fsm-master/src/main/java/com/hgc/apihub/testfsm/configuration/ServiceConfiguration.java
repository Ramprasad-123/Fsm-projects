package com.hgc.apihub.testfsm.configuration;

//TODO sample code, to be removed

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceConfiguration {

    /**
     * Construct A2P GraphQL config
     *
     * @return A2P GraphQL config
     */
    @Bean
    @ConfigurationProperties(prefix = "a2p-graphql")
    public A2PGraphQLConfig a2pGraphQLConfig() {
        return new A2PGraphQLConfig();
    }
}
