package com.hgc.apihub.testfsm.service;

//TODO sample code, to be removed/updated

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.lib.core.exception.ResourceNotFoundException;
import com.hgc.lib.microservices.aws.fsm.common.AWSQueueEntryNodeListenerTest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import com.hgc.apihub.testfsm.TestFsmTestHelper;
import com.hgc.apihub.testfsm.model.TestFsmRequest;
import com.hgc.apihub.testfsm.model.TestFsmResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@ExtendWith(SpringExtension.class)
class TestFsmServiceTest extends AWSQueueEntryNodeListenerTest {

    private TestFsmService testfsmService;

    @BeforeEach
    void setup() {
        this.init();
        testfsmService = new TestFsmService();
        this.setDependencies(testfsmService);
    }

    @Override
    protected AWSStateGraph constructStateGraph() {
        return TestFsmTestHelper.constructStateGraph();
    }

    @Test
    void dependency() {
        Assertions.assertNotNull(testfsmService.getLOGGER());
    }

    @Test
    void createTestFsm() throws Exception {
        // arrange
        var request = new TestFsmRequest();
        // act
        var response = (AsyncStateResponse) testfsmService.createTestFsm(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(202, response.getStatus());
        Assertions.assertEquals(State.ACCEPTED.name(), response.getState());
        Assertions.assertNotNull(response.getTransactionId());
        Assertions.assertNotNull(response.getEventId());
        Assertions.assertNotNull(response.getLinks());
        Assertions.assertEquals(1, response.getLinks().size());
        Assertions.assertEquals("http://test-api.hgc.com.hk:8080/v1/transaction/" + response.getTransactionId() + "/event/" + response.getEventId(), response.getLinks().get(0).getHref());
        Assertions.assertEquals(RequestMethod.GET, response.getLinks().get(0).getMethod());
        Assertions.assertEquals("self", response.getLinks().get(0).getRelation());
    }

    @Test
    void getResponseByTransactionIdAndEventId() throws Exception {
        // arrange
        var data = new TestFsmResponse(200, "ID0000021", "ID0000022", State.PROCESSED.name(), null, null);
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) throws JsonProcessingException {
                return new HGCDynamoDBEntity("TEST", "CREATE", null, "ID0000021", "ID0000022", State.PROCESSED.name(), SubState.ENTERED, OBJECT_MAPPER.writeValueAsString(data), null, null, null, null);
            }
        };
        BDDMockito.given(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).willAnswer(answer);
        // act
        var response = (TestFsmResponse) testfsmService.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022");
        // assert
        Assertions.assertNotNull(response);
        org.assertj.core.api.Assertions.assertThat(data).usingRecursiveComparison().isEqualTo(response);
    }

    @Test
    void getResponseByTransactionIdAndEventIdResourceNotFoundException() {
        // arrange
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return null;
            }
        };
        BDDMockito.given(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).willAnswer(answer);
        // assert
        Assertions.assertThrows(ResourceNotFoundException.class, () -> testfsmService.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022"));
    }

    @Test
    public void logFiles() throws Exception {
        // arrange
        var multipartFile = new MockMultipartFile("file", "test.txt", "text/plain", "Spring Framework".getBytes());
        // act
        var response = testfsmService.logFiles("test", List.of(multipartFile));
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(200, response.getStatus());
    }
}
