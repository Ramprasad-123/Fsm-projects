#!/bin/bash

~/.local/bin/aws sqs create-queue --queue-name dummy-fsm-dlq --endpoint-url http://localhost:9324

~/.local/bin/aws sqs create-queue --queue-name dummy-fsm-validate --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"dummy-fsm-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324
~/.local/bin/aws sqs create-queue --queue-name dummy-fsm-process --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"dummy-fsm-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324