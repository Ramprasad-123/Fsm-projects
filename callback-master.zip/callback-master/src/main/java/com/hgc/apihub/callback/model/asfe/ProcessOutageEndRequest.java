package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import lombok.Getter;
import lombok.Setter;

@Getter
public class ProcessOutageEndRequest implements QueueListenerBody {
    @JsonProperty("api_request")
    private final OutageEndRequest request;
    @JsonProperty("action")
    private final AsFeAction action;

    @Setter
    @JsonProperty("success")
    private boolean success;

    @Setter
    @JsonProperty("retry_count")
    private Integer retryCount;

    @Setter
    @JsonProperty("error_message")
    private String errorMessage;

    public ProcessOutageEndRequest(@JsonProperty("api_request") final OutageEndRequest requestValue,
                                   @JsonProperty("action") final AsFeAction actionValue) {
        request = requestValue;
        action = actionValue;
        success = true;
        retryCount =  0;
    }
}
