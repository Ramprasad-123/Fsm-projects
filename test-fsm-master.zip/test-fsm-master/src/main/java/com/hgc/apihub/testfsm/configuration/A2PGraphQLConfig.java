package com.hgc.apihub.testfsm.configuration;

//TODO sample code, to be removed

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class A2PGraphQLConfig {

    private String healthUrl;
}
