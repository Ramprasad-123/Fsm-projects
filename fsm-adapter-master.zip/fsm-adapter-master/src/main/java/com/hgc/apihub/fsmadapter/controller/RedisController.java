package com.hgc.apihub.fsmadapter.controller;

import com.hgc.lib.core.exception.ResourceNotFoundException;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.swagger.Error404Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static com.hgc.lib.microservices.MicroservicesHelper.*;

@Validated
@RestController
@RequestMapping("/v1/redis")
@RequiredArgsConstructor
@Tag(name = "Redis Controller", description = "Operations pertaining to Redis")
public class RedisController {

    private final StringRedisTemplate redisTemplate;

    /**
     * Check cache exists
     *
     * @param cacheKey cache key
     * @return response
     */
    @Operation(
            summary = "Check cache exists"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> checkCache(@Parameter(description = "Redis cache key", example = "test") @RequestParam(name = "cache_key") @NotBlank final String cacheKey) {
        var response = redisTemplate.hasKey(cacheKey);
        if (response == null || !response) {
            throw new ResourceNotFoundException();
        }
        return new ResponseEntity<>(new Response(HttpStatus.OK), HttpStatus.OK);
    }

    /**
     * Delete cache
     *
     * @param cacheKey cache key
     * @return response
     */
    @Operation(
            summary = "Delete cache"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @DeleteMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> deleteCache(@Parameter(description = "Redis cache key", example = "test") @RequestParam(name = "cache_key") @NotBlank final String cacheKey) {
        var response = redisTemplate.delete(cacheKey);
        if (response == null || !response) {
            throw new ResourceNotFoundException();
        }
        return new ResponseEntity<>(new Response(HttpStatus.OK), HttpStatus.OK);
    }
}
