# HSBC direct debit FSM library

Library which contains common functions for HSBC direct debit FSM to consume.

## Getting Started

For understanding the project source code, the following knowledge will be helpful in no particular order:
* Java
* Maven
* Spring Framework
* AWS SQS
* AWS DynamoDB
* Git

The list above is not an exhaustive list.

### Prerequisites

* [Git](https://git-scm.com/) is installed. Required for checking out the source code.
* [JDK 18](https://jdk.java.net/18/) is installed. Required for development and running the project.

### Installing

To obtain a local copy of the master branch of the repository, you can run the following command.
```
git clone git@jihulab.com:hgc-groups/hgc-global-communications/api-hub/hsbc/direct-debit-fsm.git
```

## Usage

## Built With

* [JDK 18](https://jdk.java.net/18/) - The core project built on JVM
* [Maven](https://maven.apache.org/) - Dependency Management
    * [Maven Wrapper](https://maven.apache.org/wrapper/) is also included in the project

## Authors

* **Sooraj Mohanan** - [\<Sooraj.Mohanan@hgc.com.hk\>](mailto:Sooraj.Mohanan@hgc.com.hk)

## Copyright

Copyright &copy; 2022, [HGC Global Communications Limited](http://www.hgc.com.hk/Home/Index-en.html).
All rights reserved.