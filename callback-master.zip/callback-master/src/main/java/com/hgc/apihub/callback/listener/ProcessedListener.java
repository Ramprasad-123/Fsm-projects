package com.hgc.apihub.callback.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.BasicQueueListenerRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageEndRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageStartRequest;
import com.hgc.apihub.callback.model.asfe.ProcessScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.service.BasicAWSProcessedListener;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.StateData;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import com.jayway.jsonpath.JsonPath;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
public class ProcessedListener extends BasicAWSProcessedListener implements AsfeListener {
    private static final LoggerWrapper LOGGER = LoggerWrapper.create(ProcessedListener.class);

    private AsFeAction action;

    @Override
    public final StateData deserializeData(final FSMEntity item) throws Exception {
        return OBJECT_MAPPER.readValue(item.getData(), AsfeAsyncStateResponse.class);
    }

    @Override
    public final QueueListenerRequest<? extends QueueListenerBody> deserializeBody(final String body) throws Exception {
        action = AsFeAction.fromValue(JsonPath.parse(body).read("@.body.action"));
        this.messageSupportedCheck(action, List.of(AsFeAction.SCHEDULED_MAINTENANCE, AsFeAction.OUTAGE_START, AsFeAction.OUTAGE_END));
        if (AsFeAction.SCHEDULED_MAINTENANCE == action) {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessScheduledMaintenanceRequest>>() {
            });
        } else if (AsFeAction.OUTAGE_START == action) {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessOutageStartRequest>>() {
            });
        } else {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessOutageEndRequest>>() {
            });
        }
    }

    @Override
    public void executeClean(final QueueListenerRequest<? extends QueueListenerBody> queueListenerRequest, final FSMEntity fsmEntity, final QueueListenerResponse.Builder builder) {
        LOGGER.unify(builder.getLogBuilderId(), Level.INFO, "inside created execute clean...all process executed successfully for action : {}", action);
    }

    @Override
    public void executeDirty(final QueueListenerRequest<? extends QueueListenerBody> queueListenerRequest, final FSMEntity fsmEntity, final QueueListenerResponse.Builder builder) {

    }
}
