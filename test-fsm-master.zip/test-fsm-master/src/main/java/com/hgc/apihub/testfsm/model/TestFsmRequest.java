package com.hgc.apihub.testfsm.model;

//TODO sample code, to be removed/updated

import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Create Test fsm request body")
public class TestFsmRequest implements QueueListenerBody {

}
