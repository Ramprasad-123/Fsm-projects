package com.hgc.apihub.fsmadapter.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Map;

@Schema(description = "DynamoDB request body")
public record DynamoDBRequest(
        @NotBlank @JsonProperty("transaction_id") @Schema(description = "Transaction ID", requiredMode = Schema.RequiredMode.REQUIRED, example = "ID0000021") String transactionId,
        @NotBlank @JsonProperty("event_id") @Schema(description = "Event ID", requiredMode = Schema.RequiredMode.REQUIRED, example = "ID0000022") String eventId,
        @NotBlank @JsonProperty("table_name") @Schema(description = "Table name", requiredMode = Schema.RequiredMode.REQUIRED, example = "test_fsm") String tableName,
        @NotNull @Schema(description = "Table attributes", requiredMode = Schema.RequiredMode.REQUIRED, type = "Map") Map<String, String> attributes) {
}
