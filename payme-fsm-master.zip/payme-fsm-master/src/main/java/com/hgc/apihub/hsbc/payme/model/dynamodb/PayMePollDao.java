package com.hgc.apihub.hsbc.payme.model.dynamodb;

import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBPollDao;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Primary
@Component
public class PayMePollDao extends HGCDynamoDBPollDao<PayMePollEntity> {

    /**
     * Constructor.
     *
     * @param entityName        the entity name
     * @param dynamoDbClient    the amazon DynamoDB
     */
    public PayMePollDao(@Value("${fsm.poll.table-name:}") final String entityName, final DynamoDbClient dynamoDbClient) {
        super(PayMePollEntity.class, entityName, dynamoDbClient);
    }

    public final List<PayMePollEntity> getAll() {
        var items = this.getDynamoDbTable().scan();
        return items.stream().map(Page::items).flatMap(Collection::stream).collect(Collectors.toList());
    }

    public final void startPolling(final PayMePollEntity item) {
        item.setPolling(true);
        this.save(item);
    }

    public final void endPolling(final PayMePollEntity item) {
        item.setPolling(false);
        this.save(item);
    }
}
