package com.hgc.apihub.testfsm.health;

import com.hgc.apihub.testfsm.configuration.A2PGraphQLConfig;
import com.hgc.lib.microservices.health.HealthOperations;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Status;

@RequiredArgsConstructor
public class A2PHealthIndicator {

    private final A2PGraphQLConfig a2pGraphQLConfig;
    private final HealthOperations healthOperations;

    private Status graph;

    protected final void updateHealthCheck() {
        if (graph == null) {
            graph = healthOperations.healthCheck(a2pGraphQLConfig.getHealthUrl());
        }
    }

    protected final Status graphHealth() {
        return graph;
    }
}
