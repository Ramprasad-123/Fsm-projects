package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.apihub.callback.model.asfe.enums.CallbackType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Generated;
import lombok.Getter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Generated
@Getter
public class BasicAsFeRequest implements Serializable {

    @NotBlank
    @JsonProperty(value = "unique_id")
    @Schema(description = "Unique id", requiredMode = Schema.RequiredMode.REQUIRED, example = "1")
    private final String uniqueId;

    @NotNull
    @JsonProperty(value = "callback_type")
    @Schema(description = "Callback type", requiredMode = Schema.RequiredMode.REQUIRED, example = "PLANNED_MAINTENANCE", allowableValues = {"PLANNED_MAINTENANCE_START, PLANNED_MAINTENANCE_END, OUTAGE_START, OUTAGE_END"})
    private final CallbackType callbackType;

    @NotBlank
    @JsonProperty(value = "channel")
    @Schema(description = "Channel", requiredMode = Schema.RequiredMode.REQUIRED, example = "CMHK")
    private final String channel;

    @NotNull
    @JsonProperty(value = "store")
    @Schema(description = "Store", requiredMode = Schema.RequiredMode.REQUIRED)
    private final Store store;

    @NotNull
    @JsonProperty(value = "affect_cust_lnoc")
    private final List<AffectCustLnoc> affectCustLnoc;

    public BasicAsFeRequest(@JsonProperty(value = "unique_id") final String uniqueIdValue, @JsonProperty(value = "callback_type") final CallbackType callbackTypeValue,
                            @JsonProperty(value = "channel") final String channelValue,
                            @JsonProperty(value = "store") final Store storeValue,
                            @JsonProperty(value = "affect_cust_lnoc") final List<AffectCustLnoc> affectCustLnocValue) {
        uniqueId = uniqueIdValue;
        callbackType = callbackTypeValue;
        channel = channelValue;
        store = storeValue;
        affectCustLnoc = affectCustLnocValue;
    }

    @JsonIgnore
    public String getAbbreviateCallbackType() {
        return switch (callbackType) {
            case PLANNED_MAINTENANCE_START, PLANNED_MAINTENANCE_END -> "M";
            case OUTAGE_START, OUTAGE_RESUME -> "A";
        };
    }

    @JsonIgnore
    public String getCategorizedSeverity() {
        return switch (store.getSeverity()) {
            case "Minor", "MTCE" -> "L";
            default -> "H";
        };
    }

    @JsonIgnore
    public String getAbbreviatedAction() {
        return switch (callbackType) {
            case OUTAGE_RESUME, PLANNED_MAINTENANCE_END -> "E";
            default -> "S";
        };
    }

    @Generated
    @Getter
    public static class AffectCustLnoc implements Serializable {

        @NotBlank
        @JsonProperty(value = "circ_no")
        @Schema(description = "Circuit number", requiredMode = Schema.RequiredMode.REQUIRED, example = "700000000BB")
        private final String circNo;

        @NotBlank
        @JsonProperty(value = "building_id")
        @Schema(description = "Building id", requiredMode = Schema.RequiredMode.REQUIRED, example = "29801004")
        private final String buildingId;

        public AffectCustLnoc(@JsonProperty(value = "circ_no") final String circNoValue, @JsonProperty(value = "building_id") final String buildingIdValue) {
            circNo = circNoValue;
            buildingId = buildingIdValue;
        }
    }

    @Generated
    @Getter
    public static class Store implements Serializable {

        @NotBlank
        @JsonProperty(value = "id")
        @Schema(description = "Store id", requiredMode = Schema.RequiredMode.REQUIRED, example = "iyrMIN")
        private final String id;

        @NotBlank
        @JsonProperty(value = "unique_id")
        @Schema(description = "Unique id", requiredMode = Schema.RequiredMode.REQUIRED, example = "159920")
        private final String uniqueId;

        @NotBlank
        @JsonProperty(value = "add_date")
        @Schema(description = "Add date", requiredMode = Schema.RequiredMode.REQUIRED, example = "2022-12-13 12:34:56")
        private final String addDate;

        @NotBlank
        @JsonProperty(value = "severity")
        @Schema(description = "Severity", requiredMode = Schema.RequiredMode.REQUIRED, example = "Major")
        private final String severity;

        @JsonProperty(value = "remarks2")
        @Schema(description = "Remarks 2", requiredMode = Schema.RequiredMode.NOT_REQUIRED, example = "2023-03-23 16:01:01")
        private final String remarks2;

        @JsonProperty(value = "remarks5")
        @Schema(description = "Remarks 5", requiredMode = Schema.RequiredMode.NOT_REQUIRED, example = "Gas")
        private final String remarks5;

        @JsonProperty(value = "remarks7")
        @Schema(description = "Remarks 7", requiredMode = Schema.RequiredMode.NOT_REQUIRED, example = "2023-03-23 16:02:01")
        private final String remarks7;

        public Store(@JsonProperty(value = "id") final String idValue, @JsonProperty(value = "unique_id") final String uniqueIdValue, @JsonProperty(value = "add_date") final String addDateValue,
                     @JsonProperty(value = "severity") final String severityValue, @JsonProperty(value = "remarks2") final String remarks2Value, @JsonProperty(value = "remarks5") final String remarks5Value,
                     @JsonProperty(value = "remarks7") final String remarks7Value) {
            id = idValue;
            uniqueId = uniqueIdValue;
            addDate = addDateValue;
            severity = severityValue;
            remarks2 = remarks2Value;
            remarks5 = remarks5Value;
            remarks7 = remarks7Value;
        }
    }

}
