package com.hgc.apihub.testfsm.service;

//TODO sample code, to be removed/updated

import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.service.AWSQueueEntryNodeListener;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.statemachine.model.QueueListenerEntryRequest;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.QueueResponseRequest;
import com.hgc.apihub.testfsm.controller.TestFsmController;
import com.hgc.apihub.testfsm.model.TestFsmRequest;
import com.hgc.apihub.testfsm.model.TestFsmResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TestFsmService extends AWSQueueEntryNodeListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(TestFsmService.class);

    public final Response createTestFsm(final TestFsmRequest request) throws Exception {
        return acceptAndProceedNextState(QueueListenerEntryRequest.ProceedNextStateWithResponse.builder()
                .nextListenerRequest(QueueListenerRequest.builder().body(request).build())
                .controllerClazz(TestFsmController.class)
                .item(new HGCDynamoDBEntity("TEST", "CREATE", null))
                .build()
        );
    }

    public final Response getResponseByTransactionIdAndEventId(final String transactionId, final String eventId) throws Exception {
        return getResponseByTransactionIdAndEventId(QueueResponseRequest.GetByTransactionIdAndEventId.builder()
                .transactionId(transactionId)
                .eventId(eventId)
                .exitStateResponse(TestFsmResponse.class)
                .build()
        );
    }

    public final Response logFiles(final String subject, final List<MultipartFile> files) throws Exception {
        LOGGER.info("message subject: {}", subject);
        for (var file : files) {
            LOGGER.info("file name: {}, content: {}", file.getOriginalFilename(), new String(file.getBytes(), StandardCharsets.UTF_8));
        }
        return new Response(HttpStatus.OK);
    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }
}
