package com.hgc.apihub.callback.dao.ccHub;

import com.amazonaws.util.CollectionUtils;
import com.hgc.apihub.callback.CallbackHelper;
import com.hgc.apihub.callback.exception.ccHub.CcHubDeleteOperationFailException;
import com.hgc.apihub.callback.exception.ccHub.CcHubNotFoundException;
import com.hgc.apihub.callback.exception.ccHub.GraphQLMutationException;
import com.hgc.apihub.callback.model.ccHub.Hub;
import com.hgc.apihub.callback.model.ccHub.HubRequest;
import com.hgc.apihub.callback.model.ccHub.HubResponse;
import com.hgc.apihub.graphqlcc.fragment.CcHubFields;
import com.hgc.apihub.graphqlcc.queries.CreateCcHubMutation;
import com.hgc.apihub.graphqlcc.queries.DeleteCcHubMutation;
import com.hgc.apihub.graphqlcc.queries.ReadCcHubsQuery;
import com.hgc.apihub.graphqlcc.type.CcHubInput;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;


/**
 * @author Wai Yan Oo on 5/11/20
 */

@Component
@AllArgsConstructor
public class CchubDao implements Serializable {

    private static final Logger LOGGER = LoggerFactory.getLogger(CchubDao.class);

    private final GraphQLTemplate graphQlCcTemplate;

    private void printTimeElapsed(String message) {
        String sessionId = RequestContextHolder.currentRequestAttributes().getSessionId();
        String dateFormatMillisec = "yyyy-MM-dd HH:mm:ss.SSS";
        Date now = new Date();
        SimpleDateFormat sdfMS = new SimpleDateFormat(dateFormatMillisec);
        LOGGER.info(sdfMS.format(now) + ", Session: " + sessionId + ", Event: " + message);
    }

    public CcHubFields createHub(String userId, HubRequest hubRequest) throws GraphQLMutationException {
        printTimeElapsed("CchubDao().createHub() STARTS --- ");


        CcHubInput ccHubInput = CcHubInput.builder()
                .apimXUserId(userId)
                .callback(hubRequest.getCallback())
                .query(hubRequest.getQuery())
                .createBy(hubRequest.getCreateBy())
                .build();

        var mutation = CreateCcHubMutation.builder()
                .ccHubInput(ccHubInput)
                .withId(true)
                .withApimXUserId(true)
                .withCallback(true)
                .withQuery(true)
                .withCreateBy(true)
                .withCreateDate(true)
                .withUpdateBy(true)
                .withCreateDate(true)
                .build();

        var mutationResponse = graphQlCcTemplate.mutation(mutation);
        if (mutationResponse.hasErrors()) {
            LOGGER.error("createHub GraphQL receives error response: " + mutationResponse.errors());
            throw new GraphQLMutationException("An error occurred while mutating to GraphQL Server. Please try again after some time.");
        }
        var mutationResult = Optional.ofNullable(mutationResponse.data()).stream()
                .flatMap(Optional::stream)
                .map(CreateCcHubMutation.Data::getCreateCcHub)
                .flatMap(Optional::stream)
                .findAny()
                .get()
                .getFragments()
                .getCcHubFields();

        printTimeElapsed("CchubDao().createHub() ENDS --- ");
        return mutationResult;
    }

    public Boolean deleteHub(String hubId) throws CcHubNotFoundException, CcHubDeleteOperationFailException {
        printTimeElapsed("CchubDao().deleteHub() STARTS --- ");

        var mutation = DeleteCcHubMutation.builder()
                .ccHubId(hubId)
                .build();

        var mutationResponse = graphQlCcTemplate.mutation(mutation);
        if (mutationResponse.hasErrors()) {
            LOGGER.error("deleteHub GraphQL receives error response: " + CallbackHelper.getError(mutationResponse.getErrors()));
            if (!CollectionUtils.isNullOrEmpty(mutationResponse.getErrors())) {
                if (("No hub with id " + hubId + " exists!").equals(mutationResponse.getErrors().get(0).getMessage())) {
                    throw new CcHubNotFoundException("No hub with id " + hubId + " exists!");
                }
            }
            throw new CcHubDeleteOperationFailException("An error occurred while mutating to GraphQL Server. Please try again after some time.");
        }
        var mutationResult = Optional.ofNullable(mutationResponse.data()).stream()
                .flatMap(Optional::stream)
                .map(DeleteCcHubMutation.Data::getDeleteCcHub)
                .flatMap(Optional::stream)
                .findAny()
                .get();

        printTimeElapsed("CchubDao().deleteHub() ENDS --- ");
        return mutationResult;
    }


    public HubResponse getHubList(Integer page, Integer size) throws GraphQLMutationException {
        printTimeElapsed("CchubDao().getHubList() STARTS --- ");

        List<Hub> hubList = new ArrayList<>();

        var query = ReadCcHubsQuery.builder()
                .page(page)
                .size(size)
                .withId(true)
                .withApimXUserId(true)
                .withCallback(true)
                .withQuery(true)
                .withCreateBy(true)
                .withCreateDate(true)
                .withUpdateBy(true)
                .withCreateDate(true)
                .build();

        var queryResponse = graphQlCcTemplate.query(query);
        if (queryResponse.hasErrors()) {
            LOGGER.error("getHubList GraphQL receives error response: " + queryResponse.errors());
            throw new GraphQLMutationException("An error occurred while mutating to GraphQL Server. Please try again after some time.");
        }

        var queryResult = Optional.ofNullable(queryResponse.getData()).stream()
                .flatMap(Optional::stream)
                .map(ReadCcHubsQuery.Data::getReadCcHubs)
                .flatMap(Optional::stream)
                .findAny()
                .map(ReadCcHubsQuery.ReadCcHubs::getFragments)
                .stream()
                .map(ReadCcHubsQuery.ReadCcHubs.Fragments::getCcHubsFields)
                .findAny();

        if (queryResult.isPresent() && queryResult.get().getCcHubs().isPresent() && queryResult.get().getCcHubs().get().size() > 0) {

            for (var a : queryResult.get().getCcHubs().get()) {

                Hub hub = new Hub();
                hub.setId(a.getFragments().getCcHubFields().getId().orElse(null));
                hub.setApimXUserId(a.getFragments().getCcHubFields().getApimXUserId().orElse(null));
                hub.setQuery(a.getFragments().getCcHubFields().getQuery().orElse(null));
                hub.setCallback(a.getFragments().getCcHubFields().getCallback().orElse(null));
                hub.setCreateDate(a.getFragments().getCcHubFields().getCreateDate().orElse(null));
                hub.setCreateBy(a.getFragments().getCcHubFields().getCreateBy().orElse(null));
                hub.setUpdateDate(a.getFragments().getCcHubFields().getUpdateDate().orElse(null));
                hub.setUpdateBy(a.getFragments().getCcHubFields().getUpdateBy().orElse(null));
                hubList.add(hub);

            }
        }
        printTimeElapsed("CchubDao().getHubList() ENDS --- ");
        return new HubResponse(hubList, HttpStatus.OK);
    }
}
