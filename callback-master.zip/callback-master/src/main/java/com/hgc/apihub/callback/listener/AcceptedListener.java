package com.hgc.apihub.callback.listener;

import com.hgc.apihub.callback.controller.asfe.OutageController;
import com.hgc.apihub.callback.controller.asfe.ScheduledMaintenanceController;
import com.hgc.apihub.callback.dynamodb.AsfeDynamoDbEntity;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.BasicQueueListenerRequest;
import com.hgc.apihub.callback.model.asfe.OutageEndRequest;
import com.hgc.apihub.callback.model.asfe.OutageStartRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageEndRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageStartRequest;
import com.hgc.apihub.callback.model.asfe.ProcessScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.ScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.service.AWSQueueEntryNodeListener;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.statemachine.model.QueueListenerEntryRequest;
import com.hgc.lib.microservices.statemachine.model.QueueResponseRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayDeque;
import java.util.List;

import static com.hgc.apihub.callback.helper.asfe.AsfeHelper.getSubTypeAsList;

@Service
@RequiredArgsConstructor
public class AcceptedListener extends AWSQueueEntryNodeListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(AcceptedListener.class);

    public final Response createScheduledMaintenance(final ScheduledMaintenanceRequest request) throws Exception {
        var subTypes = new ArrayDeque<>(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE));
        return acceptAndProceedNextState(QueueListenerEntryRequest.ProceedNextStateWithResponse.builder()
                .nextListenerRequest(BasicQueueListenerRequest.childBuilder()
                        .body(new ProcessScheduledMaintenanceRequest(request, AsFeAction.SCHEDULED_MAINTENANCE))
                        .subTypeList(subTypes)
                        .build())
                .asyncStateResponse(AsfeAsyncStateResponse.childBuilder().remainingSubTypesValue(getSubTypeAsList(subTypes)).build())
                .controllerClazz(ScheduledMaintenanceController.class)
                .item(new AsfeDynamoDbEntity(AsFeAction.SCHEDULED_MAINTENANCE, new DynamoDBEntity()))
                .build()
        );
    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }

    public Response startOutage(final OutageStartRequest request) throws Exception {
        var subTypes = new ArrayDeque<>(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE));
        return acceptAndProceedNextState(QueueListenerEntryRequest.ProceedNextStateWithResponse.builder()
                .nextListenerRequest(BasicQueueListenerRequest.childBuilder()
                        .body(new ProcessOutageStartRequest(request, AsFeAction.OUTAGE_START))
                        .subTypeList(subTypes)
                        .build())
                .asyncStateResponse(AsfeAsyncStateResponse.childBuilder().remainingSubTypesValue(getSubTypeAsList(subTypes)).build())
                .controllerClazz(OutageController.class)
                .item(new AsfeDynamoDbEntity(AsFeAction.OUTAGE_START, new DynamoDBEntity()))
                .build()
        );
    }

    public Response endOutage(final OutageEndRequest request) throws Exception {
        var subTypes = new ArrayDeque<>(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE));
        return acceptAndProceedNextState(QueueListenerEntryRequest.ProceedNextStateWithResponse.builder()
                .nextListenerRequest(BasicQueueListenerRequest.childBuilder()
                        .body(new ProcessOutageEndRequest(request, AsFeAction.OUTAGE_END))
                        .subTypeList(subTypes)
                        .build())
                .asyncStateResponse(AsfeAsyncStateResponse.childBuilder().remainingSubTypesValue(getSubTypeAsList(subTypes)).build())
                .controllerClazz(OutageController.class)
                .item(new AsfeDynamoDbEntity(AsFeAction.OUTAGE_END, new DynamoDBEntity()))
                .build()
        );
    }

    public final Response getResponseByTransactionIdAndEventId(final String transactionId, final String eventId) throws Exception {
        return getResponseByTransactionIdAndEventId(QueueResponseRequest.GetByTransactionIdAndEventId.builder()
                .transactionId(transactionId)
                .eventId(eventId)
                .asyncStateResponse(AsfeAsyncStateResponse.class)
                .exitStateResponse(AsfeAsyncStateResponse.class)
                .build()
        );
    }
}
