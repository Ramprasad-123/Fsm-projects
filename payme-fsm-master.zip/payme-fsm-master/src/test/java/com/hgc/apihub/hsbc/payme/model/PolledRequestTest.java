package com.hgc.apihub.hsbc.payme.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

class PolledRequestTest {

    @Test
    void mapping() throws IOException {
        // arrange
        var request = "{\"transaction_id\":\"0a50f70f82284edd83008fb13e13d048\",\"event_id\":\"fe5d19a6f72741b3ada1c59d37ebb7db\",\"poll_event_id\":\"a059d3e5fe5149899e189caf619ba7c0\"}";
        // act
        var response = OBJECT_MAPPER.readValue(request, PolledRequest.class);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals("0a50f70f82284edd83008fb13e13d048", response.getTransactionId());
        Assertions.assertEquals("fe5d19a6f72741b3ada1c59d37ebb7db", response.getEventId());
        Assertions.assertEquals("a059d3e5fe5149899e189caf619ba7c0", response.getPollEventId());
    }
}
