# HGC FSM Adapter

Microservice build on spring boot to act as an FSM adapter

## Getting Started

For understanding the project source code, the following knowledge will be helpful in no particular order:
* Java
* Maven
* Spring Framework
* Git
* Log4j2

The list above is not an exhaustive list

### Prerequisites

* [Git](https://git-scm.com/) is installed. Required for checking out the source code.
* [JDK 21](https://jdk.java.net/21/) is installed. Required for development and running the project.

### Installing

To obtain a local copy of the master branch of the repository, you can run the following command
```
git clone git@gitlab.hk:hgc/hgc-groups/hgc-global-communications/api-hub/fsm-adapter.git
```

## Built With

* [JDK 21](https://jdk.java.net/21/) - The core project built on JVM
* [Maven](https://maven.apache.org/) - Dependency Management
  * [Maven Wrapper](https://maven.apache.org/wrapper/) is also included in the project
* [Spring Boot 3.2.0](https://spring.io/projects/spring-boot) - Spring framework

## Authors

* **Sooraj Mohanan** - [\<Sooraj.Mohanan@hgc.com.hk\>](mailto:Sooraj.Mohanan@hgc.com.hk)

## Copyright

Copyright &copy; 2022, [HGC Global Communications Limited](http://www.hgc.com.hk/Home/Index-en.html)
All rights reserved