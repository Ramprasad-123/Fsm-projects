package com.hgc.apihub.fsmadapter.exception;

import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import io.awspring.cloud.sqs.operations.MessagingOperationFailedException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import software.amazon.awssdk.services.dynamodb.model.ResourceNotFoundException;
import software.amazon.awssdk.services.sqs.model.QueueDoesNotExistException;

import java.util.stream.Stream;

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class AdapterSanitizedExceptionHandler extends SanitizedExceptionHandler {

    @ExceptionHandler(QueueDoesNotExistException.class)
    protected final ResponseEntity<Object> handleQueueDoesNotExistException(final QueueDoesNotExistException exception, final WebRequest request) {
        return handleExceptionInternal(exception, null, null, request);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    protected final ResponseEntity<Object> handleDynamodbResourceNotFoundException(final ResourceNotFoundException exception, final WebRequest request) {
        return handleExceptionInternal(exception, null, null, request);
    }

    @ExceptionHandler(MessagingOperationFailedException.class)
    protected final ResponseEntity<Object> handleMessagingOperationFailedException(final MessagingOperationFailedException exception, final WebRequest request) {
        var rootCause = Stream.iterate(exception, Throwable::getCause)
                .filter(element -> element.getCause() == null)
                .findFirst();
        if (rootCause.isPresent() && rootCause.get() instanceof QueueDoesNotExistException) {
            return handleQueueDoesNotExistException((QueueDoesNotExistException) rootCause.get(), request);
        } else {
            return handleExceptionInternal(exception, null, null, request);
        }
    }
}
