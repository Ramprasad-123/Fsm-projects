package com.hgc.apihub.callback.exception.ccHub;

public class CcHubDeleteOperationFailException extends Exception {
    public CcHubDeleteOperationFailException(final String message){
        super(message);
    }
}
