package com.hgc.apihub.dynamodbcleanup.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
public class ServiceConfiguration {

    @Bean
    @ConfigurationProperties(prefix = "graphql-a2p")
    public A2pGraphQLConfig a2pGraphQLConfig() {
        return new A2pGraphQLConfig();
    }

    @Bean
    @ConfigurationProperties(prefix = "graphql-tnss-fbi")
    public GraphQLTnssFbiConfig graphQLTnssFbiConfig() {
        return new GraphQLTnssFbiConfig();
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}
