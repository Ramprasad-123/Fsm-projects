package com.hgc.apihub.fsmadapter.controller;

import com.hgc.apihub.fsmadapter.model.InitiateMessageRequest;
import com.hgc.apihub.fsmadapter.model.MessageRequest;
import com.hgc.apihub.fsmadapter.model.AdapterResponse;
import com.hgc.apihub.fsmadapter.service.MessageService;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.swagger.Error400Response;
import com.hgc.lib.microservices.swagger.Error404Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static com.hgc.apihub.fsmadapter.AdapterHelper.RETRY_AFTER;
import static com.hgc.apihub.fsmadapter.AdapterHelper.RETRY_AFTER_SWAGGER_EXAMPLE;
import static com.hgc.lib.microservices.MicroservicesHelper.*;

@Validated
@RestController
@RequestMapping("/v1/message")
@RequiredArgsConstructor
@Tag(name = "Message Controller", description = "Operations pertaining to messages")
public class MessageController {

    private final MessageService messageService;

    /**
     * Send FSM message
     *
     * @param request message request
     * @return response
     */
    @Operation(
            summary = "Send FSM message"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> sendMessage(@Validated @RequestBody final MessageRequest request) throws Throwable {
        var response = messageService.sendMessage(request);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }

    /**
     * Initiate FSM message
     *
     * @param request message request
     * @return async response
     */
    @Operation(
            summary = "Initiate FSM message"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AdapterResponse.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_202,
                            description = API_RESPONSE_CODE_202_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AdapterResponse.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @PostMapping(value = "/initiate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> initiateMessage(@Valid @RequestBody final InitiateMessageRequest request) throws Exception {
        var headers = new HttpHeaders();
        var response = messageService.initiateMessage(request);
        headers.add(HttpHeaders.RETRY_AFTER, String.valueOf(request.getRetryAfter()));
        headers.add(HttpHeaders.LOCATION, ((AdapterResponse) response).getHref());
        return ResponseEntity.status(response.getHttpStatus()).headers(headers).body(response);
    }

    /**
     * Get message by transaction ID and event ID
     *
     * @param transactionId transaction id
     * @param eventId       event id
     * @return message
     */
    @Operation(
            summary = "Get message by transaction ID and event ID"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AdapterResponse.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_202,
                            description = API_RESPONSE_CODE_202_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AdapterResponse.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @GetMapping(value = "/transaction/{transaction_id}/event/{event_id}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> getByTransactionIdAndEventId(@Parameter(description = TRANSACTION_ID_SWAGGER_VALUE, required = true, example = TRANSACTION_ID_SWAGGER_EXAMPLE) @PathVariable("transaction_id") @NotBlank final String transactionId,
                                                          @Parameter(description = EVENT_ID_SWAGGER_VALUE, required = true, example = EVENT_ID_SWAGGER_EXAMPLE) @PathVariable("event_id") @NotBlank final String eventId,
                                                          @Parameter(description = "Table name", required = true, example = "test_fsm") @RequestParam(name = "table_name") @NotBlank final String tableName,
                                                          @Parameter(description = "Retry polling after stated duration. Defaults to " + RETRY_AFTER + " seconds", example = RETRY_AFTER_SWAGGER_EXAMPLE) @RequestParam(name = "retry_after", defaultValue = RETRY_AFTER_SWAGGER_EXAMPLE) final Integer retryAfter) throws Exception {
        var response = messageService.getByTransactionIdAndEventId(transactionId, eventId, tableName, retryAfter);
        if (HttpStatus.ACCEPTED.value() == response.getStatus()) {
            var headers = new HttpHeaders();
            headers.add(HttpHeaders.RETRY_AFTER, String.valueOf(retryAfter));
            headers.add(HttpHeaders.LOCATION, ((AdapterResponse) response).getHref());
            return ResponseEntity.status(response.getHttpStatus()).headers(headers).body(response);
        } else {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }
}
