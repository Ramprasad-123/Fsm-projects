package com.hgc.apihub.fsmadapter.controller;

import com.hgc.apihub.fsmadapter.model.DynamoDBRequest;
import com.hgc.apihub.fsmadapter.service.DynamoDBService;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.swagger.Error400Response;
import com.hgc.lib.microservices.swagger.Error404Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static com.hgc.lib.microservices.MicroservicesHelper.*;

@Validated
@RestController
@RequestMapping("/v1/dynamodb")
@RequiredArgsConstructor
@Tag(name = "DynamoDB Controller", description = "Operations pertaining to DynamoDB")
public class DynamoDBController {

    private final DynamoDBService dynamoDBService;

    /**
     * Patch DynamoDB item
     *
     * @param request patch item request
     * @return response
     */
    @Operation(
            summary = "Patch DynamoDB item"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @PatchMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> patchDynamoDB(@Validated @RequestBody final DynamoDBRequest request) {
        var response = dynamoDBService.patchDynamoDB(request);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }
}
