package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Generated;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

@Generated
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@ToString
public class CmhkNotifyResponse {
    @JsonProperty("code")
    private final String code;

    @JsonProperty("message")
    private final String message;

    @JsonProperty("details")
    private final String details;

    @JsonProperty("outData")
    private final OutData outData;


    public CmhkNotifyResponse(@JsonProperty("code") final String codeValue, @JsonProperty("message") final String messageValue, @JsonProperty("details") final String detailsValue, @JsonProperty("outData") final OutData outDataValue) {
        code = codeValue;
        message = messageValue;
        details = detailsValue;
        outData = outDataValue;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Getter
    @ToString
    public static class OutData {
        @JsonProperty("beans")
        public List<Beans> beans;
        @JsonProperty("rtnMsg")
        public String rtnMsg;
        @JsonProperty("bean")
        public Bean bean;
        @JsonProperty("rtnCode")
        public String rtnCode;
        @JsonProperty("object")
        public Object object;

        public OutData(@JsonProperty("beans") final List<Beans> beansValue,
                       @JsonProperty("rtnMsg") final String rtnMsgValue,
                       @JsonProperty("bean") final Bean beanValue,
                       @JsonProperty("rtnCode") final String rtnCodeValue,
                       @JsonProperty("object") final Object objectValue) {
            beans = beansValue;
            rtnMsg = rtnMsgValue;
            bean = beanValue;
            rtnCode = rtnCodeValue;
            object = objectValue;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @Getter
        @ToString
        public static class Beans {
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @Getter
        @ToString
        public static class Bean {
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @Getter
        @ToString
        public static class Object {
            @JsonProperty("returnCode")
            public String returnCode;
            @JsonProperty("returnMessage")
            public String returnMessage;

            public Object(@JsonProperty("returnCode") final String returnCodeValue, @JsonProperty("returnMessage") final String returnMessageValue) {
                returnCode = returnCodeValue;
                returnMessage = returnMessageValue;
            }
        }
    }
}
