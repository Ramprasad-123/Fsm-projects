/*package com.hgc.apihub.dummyfsm.service;

//TODO sample code, to be removed/updated

import com.amazonaws.services.dynamodbv2.AcquireLockOptions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBLockClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.hgc.lib.logging.LogConsolidation;
import com.hgc.lib.microservices.aws.fsm.configuration.DynamoDBConfig;
import com.hgc.lib.microservices.aws.fsm.model.AWSQueueMessagingTemplate;
import com.hgc.lib.microservices.aws.fsm.model.BasicDynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.StateResponse;
import com.hgc.lib.microservices.statemachine.model.SubState;
import com.hgc.apihub.dummyfsm.model.DummyFsmRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.aws.messaging.listener.Acknowledgment;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;
import static com.hgc.lib.microservices.statemachine.StateMachineHelper.convertLocalDateTime;
import static com.hgc.lib.microservices.statemachine.common.StateMachineMock.mockListenerLogBuilder;
import static com.hgc.lib.microservices.statemachine.common.StateMachineMock.removeLastUpdateDate;
import static com.hgc.apihub.dummyfsm.DummyFsmTestHelper.constructStateGraph;
import static org.mockito.Mockito.never;

@ExtendWith(SpringExtension.class)
class ProcessedListenerTest {

    @MockBean
    private DynamoDBConfig dynamoDBConfig;

    @MockBean
    private DynamoDBMapper dynamoDBMapper;

    @MockBean
    private LogConsolidation logConsolidation;

    @MockBean
    private AWSQueueMessagingTemplate queueMessagingTemplate;

    @MockBean
    private AmazonDynamoDBLockClient amazonDynamoDBLockClient;

    @MockBean
    private Acknowledgment acknowledgment;

    private ProcessedListener listener;

    @BeforeEach
    void setup() {
        var dao = new BasicDynamoDBDao(dynamoDBConfig, dynamoDBMapper, amazonDynamoDBLockClient);
        //listener = new ProcessedListener(constructStateGraph(), logConsolidation, dao, queueMessagingTemplate);
        var builder = mockListenerLogBuilder(State.PROCESSED.toString());
        Mockito.when(logConsolidation.getLogBuilder(Mockito.any(String.class))).thenReturn(builder);
    }

    @Test
    void listener() throws Exception {
        // arrange
        var requestBody = new DummyFsmRequest(
                "Hello FSM"
        );
        var response = new AsyncStateResponse(202, "ID0000021", "ID0000022", State.VALIDATED.toString(), List.of(Link.withSelfRelation("https://apihub.hgc.com/test/abc123")));
        var item = new DynamoDBEntity("ID0000021", "ID0000022", State.VALIDATED.toString(), SubState.ENTERED, OBJECT_MAPPER.writeValueAsString(response), null, null);
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return item;
            }
        };
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).thenAnswer(answer);
        var lockItem = Mockito.mock(com.amazonaws.services.dynamodbv2.LockItem.class);
        Mockito.when(amazonDynamoDBLockClient.tryAcquireLock(Mockito.any(AcquireLockOptions.class))).thenReturn(Optional.of(lockItem));
        var itemArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        // act
        //listener.listener(OBJECT_MAPPER.writeValueAsString(new QueueListenerRequest<>("ID0000021", "ID0000022", requestBody)), acknowledgment);
        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(itemArgument.capture(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("ID0000021", itemArgument.getValue().getTransactionId());
        Assertions.assertEquals("ID0000022", itemArgument.getValue().getEventId());
        Assertions.assertEquals(State.PROCESSED, itemArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, itemArgument.getValue().getSubState());
        var expected = new StateResponse(200, "ID0000021", "ID0000022", State.PROCESSED.toString());
        expected.setCreateDate(convertLocalDateTime(item.getCreateDate()));
        Assertions.assertEquals(removeLastUpdateDate(OBJECT_MAPPER.writeValueAsString(expected)), removeLastUpdateDate(itemArgument.getValue().getData()));
        Mockito.verify(queueMessagingTemplate, never()).convertAndSend(Mockito.any(String.class), Mockito.any(QueueListenerRequest.class));
    }
}
*/