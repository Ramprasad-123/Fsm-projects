package com.hgc.apihub.testfsm.controller;

//TODO sample code, to be removed/updated

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBDao;
import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.statemachine.configuration.FSMDBConfig;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.apihub.testfsm.model.TestFsmRequest;
import com.hgc.apihub.testfsm.model.TestFsmResponse;
import com.hgc.apihub.testfsm.service.TestFsmService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@WebMvcTest(TestFsmController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@Import(SanitizedExceptionHandler.class)
class TestFsmControllerTest {

    @MockBean
    private FSMDBConfig fsmDBConfig;
    @MockBean
    private AmazonDynamoDB amazonDynamoDB;
    @MockBean
    private DynamoDBMapper dynamoDBMapper;
    @MockBean
    private TestFsmService testfsmService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void createTestFsm() throws Exception {
        // arrange
        var response = AsyncStateResponse.asyncStateBuilder()
                .transactionId("ID0000021")
                .eventId("ID0000022")
                .state(State.ACCEPTED.name())
                .links(List.of(Link.withSelfRelation("https://apihub.hgc.com/test/ID0000021")))
                .build();
        BDDMockito.given(testfsmService.createTestFsm(Mockito.any(TestFsmRequest.class))).willReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.post("/v1")
        .contentType(MediaType.APPLICATION_JSON_VALUE)
        .content(OBJECT_MAPPER.writeValueAsString(new TestFsmRequest())))
        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
        .andExpect(MockMvcResultMatchers.jsonPath("@.state").value(response.getState()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.transaction_id").value(response.getTransactionId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.event_id").value(response.getEventId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].relation").value(response.getLinks().get(0).getRelation()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].method").value(response.getLinks().get(0).getMethod().name()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].href").value(response.getLinks().get(0).getHref()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(202))
        .andExpect(MockMvcResultMatchers.status().isAccepted());
    }

    @Test
    void getTestFsmByTransactionIdAndEventId() throws Exception {
        // arrange
        var response = new TestFsmResponse(200, "ID0000021", "ID0000022", State.PROCESSED.name(), null, null);
        BDDMockito.given(testfsmService.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022")).willReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.get("/v1/transaction/ID0000021/event/ID0000022"))
        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
        .andExpect(MockMvcResultMatchers.jsonPath("@.transaction_id").value(response.getTransactionId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.event_id").value(response.getEventId()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.state").value(response.getState()))
        .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
        .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void logStatus() throws Exception {
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.post("/v1/status")
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .content("test"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void logFiles() throws Exception {
        // arrange
        var multipartFile = new MockMultipartFile("file", "test.txt", "text/plain", "Spring Framework".getBytes());
        BDDMockito.given(testfsmService.logFiles(Mockito.anyString(), Mockito.any())).willReturn(new Response(HttpStatus.OK));
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/files?subject=test")
                        .file(multipartFile))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
