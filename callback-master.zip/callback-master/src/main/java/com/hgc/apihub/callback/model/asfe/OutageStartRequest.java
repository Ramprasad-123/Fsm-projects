package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.apihub.callback.model.asfe.enums.CallbackType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Generated;

import java.util.List;

@Schema(description = "Outage end maintenance request body")
@Generated
public class OutageStartRequest extends BasicAsFeRequest {
    public OutageStartRequest(@JsonProperty(value = "unique_id") final String uniqueIdValue,
                              @JsonProperty(value = "callback_type") final CallbackType callbackTypeValue,
                              @JsonProperty(value = "channel") final String channelValue,
                              @JsonProperty(value = "store") final Store storeValue,
                              @JsonProperty(value = "affect_cust_lnoc") final List<AffectCustLnoc> affectCustLnocValue) {
        super(uniqueIdValue, callbackTypeValue, channelValue, storeValue, affectCustLnocValue);
    }
}
