package com.hgc.apihub.hsbc.payme.model.dynamodb;

import com.hgc.apihub.hsbc.payme.model.PayMeSubType;
import com.hgc.apihub.hsbc.payme.model.PayMeType;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.statemachine.deliver.model.DeliverType;
import com.hgc.lib.microservices.statemachine.model.SubState;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;

@Setter
@DynamoDbBean
@NoArgsConstructor
public class PayMeEntity extends DynamoDBEntity {

    public static final String REQUEST_ID_INDEX = "request_id-index";

    private PayMeType type;
    private PayMeSubType subType;
    private String requestId;

    public PayMeEntity(final PayMeType typeEnum, final PayMeSubType subTypeEnum, final String requestIdValue, final String transactionId, final String eventId, final String state, final SubState subState, final String data, final String callbackUrl) {
        super(transactionId, eventId, state, subState, data, DeliverType.CALLBACK, callbackUrl);
        this.type = typeEnum;
        this.subType = subTypeEnum;
        this.requestId = requestIdValue;
    }

    public PayMeEntity(final PayMeType typeEnum, final PayMeSubType subTypeEnum, final String requestIdValue) {
        this.type = typeEnum;
        this.subType = subTypeEnum;
        this.requestId = requestIdValue;
    }

    public static PayMeEntity buildClone(final PayMeEntity item, final String eventId, final String state, final SubState subState, final PayMeType typeEnum, final PayMeSubType subTypeEnum, final String requestIdValue) {
        var clone = new PayMeEntity();
        clone.setTransactionId(item.getTransactionId());
        clone.setEventId(eventId);
        clone.setCorrelationId(item.getCorrelationId());
        clone.setState(state);
        clone.setSubState(subState);
        clone.setDeliverType(item.getDeliverType());
        clone.setCallbackUrl(item.getCallbackUrl());
        clone.setCallbackAuthType(item.getCallbackAuthType());
        clone.setCallbackAuthSecret(item.getCallbackAuthSecret());
        clone.setType(typeEnum);
        clone.setSubType(subTypeEnum);
        clone.setRequestId(requestIdValue);
        clone.setExpirationEpochTime(item.getExpirationEpochTime());
        return clone;
    }

    /**
     * Get type
     *
     * @return type
     */
    @DynamoDbConvertedBy(value = PayMeTypeConverter.class)
    public PayMeType getType() {
        return type;
    }

    /**
     * Get subtype
     *
     * @return subtype
     */
    @DynamoDbAttribute(value = "sub_type")
    @DynamoDbConvertedBy(value = PayMeSubTypeConverter.class)
    public PayMeSubType getSubType() {
        return subType;
    }

    /**
     * Get request ID
     *
     * @return request ID
     */
    @DynamoDbAttribute(value = "request_id")
    @DynamoDbSecondaryPartitionKey(indexNames = REQUEST_ID_INDEX)
    public String getRequestId() {
        return requestId;
    }
}
