package com.hgc.apihub.fsmadapter.model;

import com.hgc.lib.microservices.common.validation.BlankValidationTest;
import com.hgc.lib.microservices.common.validation.NullValidationTest;

import java.util.List;

import static com.hgc.apihub.fsmadapter.AdapterTestHelper.*;

public class MessageRequestValidationTest implements NullValidationTest<MessageRequest>, BlankValidationTest<MessageRequest> {

    @Override
    public List<MessageRequest> nullInstances() {
        return List.of(getNullMessageRequest());
    }

    @Override
    public List<Integer> numberOfNonNullAnnotations() {
        return List.of(1);
    }

    @Override
    public List<MessageRequest> blankInstances() {
        return List.of(getBlackMessageRequest());
    }

    @Override
    public List<Integer> numberOfNonBlankAnnotations() {
        return List.of(1);
    }

    @Override
    public MessageRequest validInstance() {
        return getMessageRequest();
    }
}
