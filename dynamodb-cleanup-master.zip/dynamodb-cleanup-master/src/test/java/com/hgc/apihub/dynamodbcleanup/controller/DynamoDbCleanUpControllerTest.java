package com.hgc.apihub.dynamodbcleanup.controller;

//TODO sample code, to be removed

import com.hgc.apihub.dynamodbcleanup.service.DynamoDbCleanUpService;
import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static com.hgc.apihub.dynamodbcleanup.DynamoDbCleanUpTestHelper.getDeleteRecordSuccessResponse;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@WebMvcTest
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@AutoConfigureMockMvc(addFilters = false)
@Import(SanitizedExceptionHandler.class)
class DynamoDbCleanUpControllerTest {

    @MockBean
    private DynamoDbCleanUpService dynamoDbCleanUpService;

    @MockBean
    private BuildProperties buildProperties;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void cleanUpA2pSmsTable() throws Exception {
        // arrange
        Mockito.when(dynamoDbCleanUpService.deleteRecords(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getDeleteRecordSuccessResponse());
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.patch("/v1/clean-up/a2p-sms?start_date=2021-01-01 00:00:00&end_date=2021-04-01 23:59:59"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void cleanUpTnssIntegrationTable() throws Exception {
        // arrange
        Mockito.when(dynamoDbCleanUpService.deleteRecords(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getDeleteRecordSuccessResponse());
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.patch("/v1/clean-up/tnss-integration?start_date=2021-01-01 00:00:00&end_date=2021-04-01 23:59:59"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void cleanUpA2pSmsTableValidationFail() throws Exception {
        // arrange
        Mockito.when(dynamoDbCleanUpService.deleteRecords(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getDeleteRecordSuccessResponse());
        // act
            this.mockMvc.perform(MockMvcRequestBuilders.patch("/v1/clean-up/a2p-sms?start_date=X2022-01-01 00:00:00&end_date=2022-04-01 23:59:59"))
                    .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                    .andExpect(MockMvcResultMatchers.jsonPath("@.message").isNotEmpty())
                    .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(400))
                    .andExpect(MockMvcResultMatchers.status().isBadRequest()).andDo(print());


    }

    @Test
    void cleanUpTnssIntegrationTableValidationFail() throws Exception {
        // arrange
        Mockito.when(dynamoDbCleanUpService.deleteRecords(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getDeleteRecordSuccessResponse());
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.patch("/v1/clean-up/tnss-integration?start_date=X2022-01-01 00:00:00&end_date=2022-04-01 23:59:59"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(400))
                .andExpect(MockMvcResultMatchers.status().isBadRequest()).andDo(print());


    }

    @Test
    void cleanUpInvalidDateFormat() throws Exception {
        // arrange
        Mockito.when(dynamoDbCleanUpService.deleteRecords(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getDeleteRecordSuccessResponse());
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.patch("/v1/clean-up/tnss-integration?start_date=2022-01-01&end_date=2022-04-01 23:59:59"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(400))
                .andExpect(MockMvcResultMatchers.status().isBadRequest()).andDo(print());


    }
}
