package com.hgc.apihub.fsmadapter.service;

import com.hgc.apihub.fsmadapter.model.AdapterResponse;
import com.hgc.apihub.fsmadapter.model.InitiateMessageRequest;
import com.hgc.apihub.fsmadapter.model.dynamodb.AdapterDynamoDBDao;
import com.hgc.lib.core.exception.ResourceNotFoundException;
import com.hgc.lib.microservices.aws.fsm.model.AWSQueueMessagingTemplate;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.configuration.APIMConfig;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.DeliveredRequest;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.hgc.apihub.fsmadapter.AdapterTestHelper.*;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@ExtendWith(SpringExtension.class)
class MessageServiceTest {

    @MockBean
    private APIMConfig apimConfig;

    @MockBean
    private AdapterDynamoDBDao adapterDynamoDBDao;

    @MockBean
    private AWSQueueMessagingTemplate queueMessagingTemplate;

    private MessageService messageService;

    @BeforeEach
    void setup() {
        BDDMockito.given(apimConfig.host()).willReturn("test-api.hgc.com.hk");
        BDDMockito.given(apimConfig.scheme()).willReturn("http");
        BDDMockito.given(apimConfig.port()).willReturn("8080");
        messageService = new MessageService(apimConfig, adapterDynamoDBDao, queueMessagingTemplate);
    }

    @Test
    void sendMessage() throws Throwable {
        // arrange
        var urlArgument = ArgumentCaptor.forClass(String.class);
        var messageArgument = ArgumentCaptor.forClass(String.class);
        var request = getMessageRequest();
        // act
        var response = messageService.sendMessage(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(200, response.getStatus());
        Mockito.verify(queueMessagingTemplate).convertAndSend(urlArgument.capture(), messageArgument.capture());
        Assertions.assertEquals(request.getQueueName(), urlArgument.getValue());
        Assertions.assertEquals(request.getBody(), messageArgument.getValue());
    }

    @Test
    void initiateMessage() throws Exception {
        // arrange
        var urlArgument = ArgumentCaptor.forClass(String.class);
        var messageArgument = ArgumentCaptor.forClass(QueueListenerRequest.class);
        var request = getInitiateMessageRequest();
        // act
        var response = (AdapterResponse) messageService.initiateMessage(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(202, response.getStatus());
        var asyncResponse = OBJECT_MAPPER.readValue(response.getBody(), AsyncStateResponse.class);
        Assertions.assertEquals(State.ACCEPTED.name(), asyncResponse.getState());
        Assertions.assertNotNull(asyncResponse.getTransactionId());
        Assertions.assertNotNull(asyncResponse.getEventId());
        Assertions.assertEquals("http://test-api.hgc.com.hk:8080/v1/message/transaction/" + asyncResponse.getTransactionId() + "/event/" + asyncResponse.getEventId() + "?table_name=test_fsm&retry_after=" + request.getRetryAfter(), response.getHref());
        Mockito.verify(queueMessagingTemplate).convertAndSend(urlArgument.capture(), messageArgument.capture());
        Assertions.assertEquals(request.getQueueName(), urlArgument.getValue());
        Assertions.assertNotNull(messageArgument.getValue().getCorrelationId());
        Assertions.assertEquals(State.ACCEPTED.name(), messageArgument.getValue().getQueueState());
        Assertions.assertEquals(request.getQueueName(), messageArgument.getValue().getQueueName());
        Assertions.assertEquals(OBJECT_MAPPER.writeValueAsString(new DeliveredRequest(request.getBody())), OBJECT_MAPPER.writeValueAsString(messageArgument.getValue().getBody()));
        // arrange
        request = new InitiateMessageRequest("test message", "test queue", "test_fsm", null, null, null, 10, "http://test.com");;
        // act
        response = (AdapterResponse) messageService.initiateMessage(request);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(202, response.getStatus());
    }

    @Test
    void getByTransactionIdAndEventId() throws Exception {
        // arrange
        var data = OBJECT_MAPPER.writeValueAsString(getAdapterResponse());
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return getDynamoDBEntity(State.ACCEPTED, data, null);
            }
        };
        BDDMockito.given(adapterDynamoDBDao.getByTransactionIdAndEventId(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).willAnswer(answer);
        // act
        var response = (AdapterResponse) messageService.getByTransactionIdAndEventId("ID0000021", "ID0000022", "test_fsm", 5);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(data, response.getBody());
    }

    @Test
    void getByTransactionIdAndEventIdAsync() throws Exception {
        // arrange
        var data = OBJECT_MAPPER.writeValueAsString(new AdapterResponse(202, "test"));
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return getDynamoDBEntity(State.ACCEPTED, data, null);
            }
        };
        BDDMockito.given(adapterDynamoDBDao.getByTransactionIdAndEventId(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).willAnswer(answer);
        // act
        var response = (AdapterResponse) messageService.getByTransactionIdAndEventId("ID0000021", "ID0000022", "test_fsm", 5);
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(data, response.getBody());
        Assertions.assertEquals("http://test-api.hgc.com.hk:8080/v1/message/transaction/ID0000021/event/ID0000022?table_name=test_fsm&retry_after=5", response.getHref());
    }

    @Test
    void getByTransactionIdAndEventIdResourceNotFoundException() {
        // arrange
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return null;
            }
        };
        BDDMockito.given(adapterDynamoDBDao.getByTransactionIdAndEventId(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).willAnswer(answer);
        // assert
        Assertions.assertThrows(ResourceNotFoundException.class, () -> messageService.getByTransactionIdAndEventId("ID0000021", "ID0000022", "test_fsm", 5));
    }
}
