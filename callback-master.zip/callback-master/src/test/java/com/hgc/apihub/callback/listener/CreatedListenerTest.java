package com.hgc.apihub.callback.listener;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.apihub.callback.AsfeTestHelper;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.BasicQueueListenerRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageEndRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageStartRequest;
import com.hgc.apihub.callback.model.asfe.ProcessScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.apihub.callback.service.asfe.AsfeService;
import com.hgc.lib.microservices.aws.fsm.common.AWSQueueListenerTest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.model.FieldErrorMessage;
import com.hgc.lib.microservices.statemachine.exception.ConditionalCheckFailedException;
import com.hgc.lib.microservices.statemachine.model.ErrorStateResponse;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

import static com.hgc.apihub.callback.AsfeTestHelper.getAsfeAsyncResponse;
import static com.hgc.apihub.callback.AsfeTestHelper.getFsmEntity;
import static com.hgc.apihub.callback.AsfeTestHelper.getProcessOutageEndRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getProcessOutageStartRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getProcessScheduledMaintenanceStartRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getQueueListenerRequest;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@ExtendWith(SpringExtension.class)
class CreatedListenerTest extends AWSQueueListenerTest {

    private CreatedListener listener;

    @MockBean
    AsfeService asfeService;

    @Override
    protected AWSStateGraph constructStateGraph() {
        return AsfeTestHelper.constructStateGraph();
    }

    @BeforeEach
    void setup() throws Exception {
        this.init();
        listener = new CreatedListener(asfeService);
        this.setDependencies(listener, State.CREATED.name());
    }

    @Test
    void deserializeDataTest() throws Exception {
        // arrange
        var item = getFsmEntity(State.CREATED);
        // act
        var data = listener.deserializeData(item);
        // assert
        Assertions.assertNotNull(data);
    }

    @Test
    void deserializeBodyTest() throws Exception {
        // arrange
        var bodyJson = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE));
        // act
        var statData = listener.deserializeBody(bodyJson);
        // assert
        Assertions.assertNotNull(statData);
        Assertions.assertNotNull(statData.getBody());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNoSubTypesPresentTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        // assert
        Assertions.assertThrows(ConditionalCheckFailedException.class, () -> listener.listener(OBJECT_MAPPER.writeValueAsString(QueueListenerRequest.builder().transactionId("TRAN0001").eventId("EVEN0002").body(requestBody).build()),
                acknowledgment, messageHeaders));

    }

    @Test
    void executeCleanForCreateScheduledMaintenanceSubTypesNotEqualTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        // assert
        Assertions.assertThrows(ConditionalCheckFailedException.class,
                () -> listener.listener(OBJECT_MAPPER.writeValueAsString(BasicQueueListenerRequest.childBuilder().transactionId("TRAN0001").eventId("EVEN0002").body(requestBody).subTypeList(new ArrayDeque<>(List.of(SubType.CMHK_NOTIFY))).build()),
                        acknowledgment, messageHeaders));
    }

    private void mockHelperForCreatedListenerTest(final List<SubType> subTypes) {
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) throws JsonProcessingException {
                var data = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(getAsfeAsyncResponse(subTypes));
                return new DynamoDBEntity("TRAN001", "EVEN002", State.CREATED.name(), SubState.ENTERED, data, null, null);
            }
        };
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).thenAnswer(answer);
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyCmhkTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyCmhkRetryTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(1, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyCmhkRejectedTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setRetryCount(5);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("test", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(5, listenerBody.getRetryCount());
        Assertions.assertFalse(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyCmhkPassThroughForRejectTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setRetryCount(5);
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("to be recorded in last sub state");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(5, listenerBody.getRetryCount());
        Assertions.assertFalse(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyCmhkRejected4xxTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("400", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(0, listenerBody.getRetryCount());
        Assertions.assertFalse(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyAsfeTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setSuccess(true);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = new ArrayList<>(List.of(SubType.AS_NOTIFICATION_QUEUE));
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyAsfe(Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyAsfeRetryTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setSuccess(true);
        requestBody.setErrorMessage("Proceed for retry");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyAsfe(Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(1, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyAsfeRejectedTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setRetryCount(4);
        requestBody.setErrorMessage("Rejected, no retry");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyAsfe(Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(5, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceNotifyAsfePassThroughTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("to be recorded in last sub state");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(0, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceUpdateAsNotificationQueueTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setSuccess(true);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = new ArrayList<SubType>();
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceUpdateAsNotificationQueueRetryTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setSuccess(true);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(1, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceUpdateAsNotificationQueueRejectedTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setRetryCount(5);
        requestBody.setErrorMessage("Rejected, no retry");
        requestBody.setSuccess(false);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("test", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), ErrorStateResponse.class));

        Assertions.assertEquals(State.REJECTED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceUpdateAsNotificationRejectedPassThroughTest() throws Exception {
        // arrange
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("previous sub state failed");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of();
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        ErrorStateResponse errorStateData = OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), ErrorStateResponse.class);
        Assertions.assertNotNull(errorStateData);
        Assertions.assertEquals(requestBody.getErrorMessage(), errorStateData.getFieldErrorMessages().get(0).getMessage());


        Assertions.assertEquals(State.REJECTED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());
    }

    @Test
    void executeCleanForOutageStartNotifyCmhkTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageStartNotifyAsfeTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        requestBody.setSuccess(true);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyAsfe(Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageStartNotifyAsfeRetryTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        requestBody.setSuccess(true);
        requestBody.setErrorMessage("Proceed for retry");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyAsfe(Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(1, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForOutageStartNotifyAsfeRejectedTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        requestBody.setRetryCount(5);
        requestBody.setErrorMessage("Rejected, no retry");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(5, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForOutageStartNotifyAsfePassThroughTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("to be recorded in last sub state");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(0, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForOutageStartNotifyAsfeRejected4xxTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("400", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(0, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForOutageStartUpdateAsNotificationUpdateTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        requestBody.setSuccess(true);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of();
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageStartNotifyCmhkPassThroughForRejectTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        requestBody.setRetryCount(5);
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("to be recorded in last sub state");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(5, listenerBody.getRetryCount());
        Assertions.assertFalse(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForOutageStartUpdateAsNotificationRejectedPassThroughTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageStartRequest();
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("previous sub state failed");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of();
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        ErrorStateResponse errorStateData = OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), ErrorStateResponse.class);
        Assertions.assertNotNull(errorStateData);
        Assertions.assertEquals(requestBody.getErrorMessage(), errorStateData.getFieldErrorMessages().get(0).getMessage());


        Assertions.assertEquals(State.REJECTED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());
    }

    @Test
    void executeCleanForOutageEndNotifyCmhkTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyCmhk(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageEndNotifyAsfeTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        requestBody.setSuccess(true);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyAsfe(Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageEndNotifyAsfeRetryTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        requestBody.setSuccess(true);
        requestBody.setErrorMessage("Proceed for retry");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.notifyAsfe(Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(1, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForOutageEndNotifyAsfeRejectedTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        requestBody.setRetryCount(5);
        requestBody.setErrorMessage("Rejected, no retry");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("500", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(5, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForOutageEndNotifyAsfePassThroughTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("to be recorded in last sub state");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(0, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForOutageEndNotifyAsfeRejected4xxTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(new FieldErrorMessage("400", "test"));
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(0, listenerBody.getRetryCount());
        Assertions.assertTrue(listenerBody.isSuccess());
    }

    @Test
    void executeCleanForOutageEndUpdateAsNotificationQueueTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        requestBody.setSuccess(true);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of();
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(remainingSubTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());


        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());

        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageEndNotifyCmhkPassThroughForRejectTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        requestBody.setRetryCount(5);
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("to be recorded in last sub state");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of(SubType.AS_NOTIFY, SubType.AS_NOTIFICATION_QUEUE);
        mockHelperForCreatedListenerTest(incomingSubTypes);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertNotNull(OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class));

        Assertions.assertEquals(State.CREATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
        Assertions.assertEquals(remainingSubTypes, queueListenerBodyArgument.getValue().getSubTypes());
        Assertions.assertEquals(5, listenerBody.getRetryCount());
        Assertions.assertFalse(listenerBody.isSuccess());
        Assertions.assertNotNull(listenerBody.getErrorMessage());
    }

    @Test
    void executeCleanForOutageEndUpdateAsNotificationRejectedPassThroughTest() throws Exception {
        // arrange
        var requestBody = getProcessOutageEndRequest();
        requestBody.setSuccess(false);
        requestBody.setErrorMessage("previous sub state failed");
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var incomingSubTypes = List.of(SubType.AS_NOTIFICATION_QUEUE);
        var remainingSubTypes = List.of();
        mockHelperForCreatedListenerTest(incomingSubTypes);
        Mockito.when(asfeService.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(incomingSubTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        ErrorStateResponse errorStateData = OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), ErrorStateResponse.class);
        Assertions.assertNotNull(errorStateData);
        Assertions.assertEquals(requestBody.getErrorMessage(), errorStateData.getFieldErrorMessages().get(0).getMessage());


        Assertions.assertEquals(State.REJECTED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());
    }
}