package com.hgc.apihub.dynamodbcleanup.dao.dynamoDb;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDBLockClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedQueryList;
import com.hgc.lib.microservices.aws.fsm.configuration.DynamoDBConfig;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.stream.Stream;

import static com.hgc.apihub.dynamodbcleanup.DynamoDbCleanUpTestHelper.getFailedBatches;

@ExtendWith(SpringExtension.class)
class DynamoDbTnssIntegrationDaoTest {
    @MockBean
    private AmazonDynamoDBLockClient amazonDynamoDBLockClient;

    @MockBean
    private DynamoDBMapper dynamoDBMapper;

    @MockBean
    private DynamoDBConfig dynamoDBConfig;

    private DynamoDbTnssIntegrationDao dynamoDbTnssIntegrationDao;

    @BeforeEach
    void setUp() {
        this.dynamoDBMapper = Mockito.mock(DynamoDBMapper.class);
        this.dynamoDBConfig = Mockito.mock(DynamoDBConfig.class);
        Mockito.when(dynamoDBConfig.getLock()).thenReturn(new DynamoDBConfig.Lock("test"));
        dynamoDbTnssIntegrationDao = new DynamoDbTnssIntegrationDao(dynamoDBConfig, Mockito.mock(DynamoDBMapper.class), Mockito.mock(AmazonDynamoDBLockClient.class));
    }

    @Test
    void deleteRecords() {
        // arrange
        var itemList = Mockito.mock(PaginatedQueryList.class);
        Mockito.when(itemList.size()).thenReturn(1);
        var item = new DynamoDbTnssIntegrationEntity();
        item.setTransactionId("test");
        item.setEventId("test");
        item.setCreateDate(LocalDateTime.now());
        item.setLastUpdateDate(LocalDateTime.now());
        Answer<Stream> answer = invocation -> Stream.of(item);
        Mockito.when(itemList.stream()).thenAnswer(answer);
        Mockito.when(dynamoDbTnssIntegrationDao.getDynamoDBMapper().query(Mockito.eq(DynamoDbTnssIntegrationEntity.class), Mockito.any(DynamoDBQueryExpression.class), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(itemList);
        // act
        var actual = dynamoDbTnssIntegrationDao.deleteRecords(new ArrayList<>() {{
            add("test");
            add("test");
        }});
        // assert
        Assertions.assertNotNull(actual.getMessage());
        Assertions.assertEquals(200, actual.getStatus());
    }

    @Test
    void deleteRecordsFail() {
        // arrange
        var itemList = Mockito.mock(PaginatedQueryList.class);
        Mockito.when(itemList.size()).thenReturn(1);
        var item = new DynamoDbTnssIntegrationEntity();
        item.setTransactionId("test");
        item.setEventId("test");
        item.setCreateDate(LocalDateTime.now());
        item.setLastUpdateDate(LocalDateTime.now());
        Answer<Stream> answer = new Answer<>() {
            public Stream answer(InvocationOnMock invocation) throws Throwable {
                return Stream.of(item);
            }
        };
        var totalFailedBatches = getFailedBatches();
        Mockito.when(itemList.stream()).thenAnswer(answer);
        Mockito.when(dynamoDbTnssIntegrationDao.getDynamoDBMapper().query(Mockito.eq(DynamoDbTnssIntegrationEntity.class), Mockito.any(DynamoDBQueryExpression.class), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(itemList);
        Mockito.when(dynamoDbTnssIntegrationDao.getDynamoDBMapper().batchWrite(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(totalFailedBatches);
        // act
        var actual = dynamoDbTnssIntegrationDao.deleteRecords(new ArrayList<>() {{
            add("test");
            add("test");
        }});
        // assert
        Assertions.assertNotNull(actual.getMessage());
        Assertions.assertEquals(500, actual.getStatus());
    }

    @Test
    void deleteRecordsNoItemsToDelete() {
        // arrange
        var itemList = Mockito.mock(PaginatedQueryList.class);
        Mockito.when(itemList.size()).thenReturn(0);
        Mockito.when(dynamoDbTnssIntegrationDao.getDynamoDBMapper().query(Mockito.eq(DynamoDbTnssIntegrationEntity.class), Mockito.any(DynamoDBQueryExpression.class), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(itemList);
        // act
        var actual = dynamoDbTnssIntegrationDao.deleteRecords(new ArrayList<>() {
        });
        // assert
        Assertions.assertNotNull(actual.getMessage());
        Assertions.assertEquals(200, actual.getStatus());
    }
}