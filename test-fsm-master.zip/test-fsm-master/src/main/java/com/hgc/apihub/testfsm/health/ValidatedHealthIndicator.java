package com.hgc.apihub.testfsm.health;

//TODO sample code, to be removed/updated

import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;

@RequiredArgsConstructor
public class ValidatedHealthIndicator implements HealthIndicator {

    private final StateHealthComponent component;

    @Override
    public final Health health() {
        component.updateHealthCheck();
        if (component.getA2P().graphHealth() == Status.UP) {
            return Health.up().build();
        } else {
            return Health.down().build();
        }
    }
}
