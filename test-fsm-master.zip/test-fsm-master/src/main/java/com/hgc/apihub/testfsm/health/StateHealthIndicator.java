package com.hgc.apihub.testfsm.health;

//TODO sample code, to be removed/updated

import com.hgc.lib.microservices.health.AbstractHealthContributor;
import com.hgc.lib.microservices.statemachine.model.State;
import org.springframework.stereotype.Component;

@Component
public class StateHealthIndicator extends AbstractHealthContributor {

    StateHealthIndicator(final StateHealthComponent component) {
        this.getContributors().put(State.VALIDATED.name().toLowerCase(), new ValidatedHealthIndicator(component));
        this.getContributors().put("CUSTOM".toLowerCase(), new CustomHealthIndicator());
        this.getContributors().put(State.PROCESSED.name().toLowerCase(), new ProcessedHealthIndicator());
    }
}
