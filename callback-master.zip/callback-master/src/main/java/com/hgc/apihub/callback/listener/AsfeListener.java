package com.hgc.apihub.callback.listener;

import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.exception.ExceptionHandlerType;
import com.hgc.lib.microservices.model.FieldErrorMessage;
import com.hgc.lib.microservices.statemachine.exception.MessageNotSupportedException;
import com.hgc.lib.microservices.statemachine.model.ErrorStateResponse;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import org.apache.logging.log4j.Level;
import org.springframework.util.CollectionUtils;

import java.util.List;

public interface AsfeListener {

    default void messageSupportedCheck(final AsFeAction action, final List<AsFeAction> supportedActions) throws MessageNotSupportedException {
        if (action != null && !CollectionUtils.isEmpty(supportedActions)) {
            supportedActions.stream().filter(e -> e == action).findAny().orElseThrow(MessageNotSupportedException::new);
        }
    }

    default void rejectedStateData(final String transactionId, final String eventId, final AsFeAction action, final List<FieldErrorMessage> fieldErrorMessages, final QueueListenerResponse.Builder builder,
                                   final LoggerWrapper logger) {
        logger.unify(builder.getLogBuilderId(), Level.ERROR, "Error occurred while {} with transaction id {} and event id {}; {}", action.toValue(), transactionId, eventId, fieldErrorMessages);
        builder.state(State.REJECTED.name()).stateData(ErrorStateResponse.buildBadResponse(transactionId, eventId, ExceptionHandlerType.InvalidRequestException, fieldErrorMessages));
    }
}
