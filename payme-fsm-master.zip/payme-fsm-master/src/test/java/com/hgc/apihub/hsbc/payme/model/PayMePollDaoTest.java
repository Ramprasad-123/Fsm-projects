package com.hgc.apihub.hsbc.payme.model;

import com.hgc.apihub.hsbc.payme.model.dynamodb.PayMePollDao;
import com.hgc.apihub.hsbc.payme.model.dynamodb.PayMePollEntity;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;
import software.amazon.awssdk.services.dynamodb.paginators.ScanIterable;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class PayMePollDaoTest {

    private PayMePollDao paymePollDao;
    private DynamoDbClient dynamoDbClient;

    @BeforeEach
    void setup() {
        dynamoDbClient = Mockito.mock(DynamoDbClient.class);
        paymePollDao = new PayMePollDao("test-poll", dynamoDbClient);
    }

    @Test
    void getAll() {
        // arrange=
        var item1 = new PayMePollEntity("ID0000021", "ID0000022", "ID0000023", PayMeType.PAYMENT, 600, 1200, null);
        var item2 = new PayMePollEntity("ID0000024", "ID0000025", "ID0000026", PayMeType.PAYMENT, 600, 1200, null);
        var item3 = new PayMePollEntity();
        item3.setTransactionId("ID0000027");
        item3.setEventId("ID0000028");
        item3.setCorrelationId("ID0000029");
        item3.setType(PayMeType.REFUND);
        item3.setStartDuration(600);
        item3.setEndDuration(1200);
        item3.setData(null);
        item3.setCreateDate(LocalDateTime.now());
        var response = new ArrayList<ScanResponse>();
        List.of(item1, item2, item3).forEach(item -> response.add(ScanResponse.builder()
                .items(List.of(Map.of("transaction_id", AttributeValue.fromS(item.getTransactionId()),"event_id", AttributeValue.fromS(item.getEventId()),"correlation_id", AttributeValue.fromS(item.getCorrelationId()),"type", AttributeValue.fromS(item.getType().name()),"start_duration", AttributeValue.fromS(item.getStartDuration().toString()), "end_duration", AttributeValue.fromS(item.getEndDuration().toString()))))
                .build()
        ));
        var itemList = Mockito.mock(ScanIterable.class);
        BDDMockito.given(itemList.iterator()).willReturn(response.iterator());
        BDDMockito.given(dynamoDbClient.scanPaginator(Mockito.any(ScanRequest.class))).willReturn(itemList);
        // act
        var items = paymePollDao.getAll();
        // assert
        Assertions.assertNotNull(items);
        org.assertj.core.api.Assertions.assertThat(item1).usingRecursiveComparison().ignoringFields("createDate").isEqualTo(items.get(0));
        org.assertj.core.api.Assertions.assertThat(item2).usingRecursiveComparison().ignoringFields("createDate").isEqualTo(items.get(1));
        org.assertj.core.api.Assertions.assertThat(item3).usingRecursiveComparison().ignoringFields("createDate").isEqualTo(items.get(2));
    }

    @Test
    void polling() {
        // arrange
        var item = new PayMePollEntity("ID0000021", "ID0000022", "ID0000023", PayMeType.PAYMENT, 600, 1200, null);
        var entity = ArgumentCaptor.forClass(PutItemRequest.class);
        BDDMockito.given(dynamoDbClient.putItem(Mockito.any(PutItemRequest.class))).willReturn(Mockito.mock(PutItemResponse.class));
        // act
        paymePollDao.startPolling(item);
        // assert
        Mockito.verify(dynamoDbClient, Mockito.atLeastOnce()).putItem(entity.capture());
        Assertions.assertTrue(entity.getValue().item().get("polling").bool());
        // act
        paymePollDao.endPolling(item);
        // assert
        Mockito.verify(dynamoDbClient, Mockito.atLeastOnce()).putItem(entity.capture());
        Assertions.assertFalse(entity.getValue().item().get("polling").bool());
    }
}
