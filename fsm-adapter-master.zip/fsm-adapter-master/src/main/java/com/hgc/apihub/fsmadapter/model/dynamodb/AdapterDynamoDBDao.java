package com.hgc.apihub.fsmadapter.model.dynamodb;

import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class AdapterDynamoDBDao {

    private final DynamoDbClient dynamoDbClient;

    public final void save(final DynamoDBEntity item, final String tableName) {
        this.getDynamoDbTable(tableName).putItem(requestConsumer -> requestConsumer.item(item));
    }

    public final DynamoDBEntity getByTransactionIdAndEventId(final String transactionId, final String eventId, final String tableName) {
        return this.getDynamoDbTable(tableName)
                .getItem(Key.builder()
                        .partitionValue(transactionId)
                        .sortValue(eventId)
                        .build()
                );
    }

    public final void updateAttributesByTransactionIdAndEventId(final String transactionId, final String eventId, final String tableName, final Map<String, String> attributesToUpdate) {
        if (!attributesToUpdate.isEmpty()) {
            var keyToGet = new HashMap<String, AttributeValue>();
            keyToGet.put("transaction_id", AttributeValue.fromS(transactionId));
            keyToGet.put("event_id", AttributeValue.fromS(eventId));
            var item = new HashMap<>(dynamoDbClient
                    .getItem(GetItemRequest.builder()
                            .key(keyToGet)
                            .tableName(tableName)
                            .build()
                    )
                    .item()
            );
            attributesToUpdate.entrySet().stream()
                    .filter(entry -> item.get(entry.getKey()) != null)
                    .forEach(entry -> item.put(entry.getKey(), AttributeValue.fromS(entry.getValue())));
            dynamoDbClient
                    .putItem(PutItemRequest.builder()
                            .tableName(tableName)
                            .item(item)
                            .build()
                    );
        }
    }

    private DynamoDbTable<DynamoDBEntity> getDynamoDbTable(final String tableName) {
        return DynamoDbEnhancedClient.builder()
                .dynamoDbClient(dynamoDbClient)
                .build()
                .table(tableName, TableSchema.fromClass(DynamoDBEntity.class));
    }
}
