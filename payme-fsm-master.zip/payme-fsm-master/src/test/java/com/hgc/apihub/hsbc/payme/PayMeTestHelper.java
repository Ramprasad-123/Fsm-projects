package com.hgc.apihub.hsbc.payme;

import com.hgc.apihub.hsbc.payme.model.PayMeSubType;
import com.hgc.apihub.hsbc.payme.model.PayMeType;
import com.hgc.apihub.hsbc.payme.model.dynamodb.PayMeEntity;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;

public final class PayMeTestHelper {

    private PayMeTestHelper() {
    }

    public static PayMeEntity getPayMeEntity(PayMeType type, PayMeSubType subType, State state, String data) {
        return getPayMeEntity(type, subType, state, data, "http://test.com");
    }

    public static PayMeEntity getPayMeEntity(PayMeType type, PayMeSubType subType, State state, String data, String callbackUrl) {
        return new PayMeEntity(type, subType, "0002900F06457710500000001", "ID0000021", "ID0000022", state.name(), SubState.ENTERED, data, callbackUrl);
    }

    public static String getPayMeStateResponse() {
        return "{\"status\":200,\"transaction_id\":\"d5f4e291013841018b1bbc7ed9d50397\",\"event_id\":\"ea0b62efc1b6422dae639d8333734285\",\"state\":\"POLLED\",\"create_date\":\"2022-11-07 11:44:52.132\",\"last_update_date\":\"2022-11-07 11:50:56.148\",\"type\":\"PAYMENT\",\"sub_type\":\"POLL\",\"request_id\":\"4292bd4a-4920-44ee-8e63-9ea86d774f1a\",\"process_response\":{\"status\":200,\"process_code\":\"PR007\",\"process_message\":\"Payment Request Expired\",\"currency\":\"HKD\",\"total_amount\":20.77,\"created_time\":\"2022-11-07T03:44:52Z\",\"effective_duration\":240}}";
    }
}
