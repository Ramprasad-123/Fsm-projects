package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import lombok.Getter;
import lombok.Setter;

@Getter
public class ProcessScheduledMaintenanceRequest implements QueueListenerBody {

    @JsonProperty("api_request")
    private final ScheduledMaintenanceRequest request;

    @JsonProperty("action")
    private final AsFeAction action;

    @Setter
    @JsonProperty("success")
    private boolean success;

    @Setter
    @JsonProperty("retry_count")
    private Integer retryCount;

    @Setter
    @JsonProperty("error_message")
    private String errorMessage;

    public ProcessScheduledMaintenanceRequest(@JsonProperty("api_request") final ScheduledMaintenanceRequest requestValue, @JsonProperty("action") final AsFeAction actionValue) {
        this.request = requestValue;
        this.action = actionValue;
        this.retryCount = 0;
        this.success = true;
    }
}
