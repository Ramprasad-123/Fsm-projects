package com.hgc.apihub.testfsm.health;

//TODO sample code, to be removed/updated

import com.hgc.apihub.testfsm.configuration.A2PGraphQLConfig;
import com.hgc.lib.microservices.health.HealthOperations;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class HealthIndicatorTest {

    @MockBean
    private A2PGraphQLConfig a2pGraphQLConfig;

    @MockBean
    private HealthOperations healthOperations;

    @BeforeEach
    void setup() {
        Mockito.when(a2pGraphQLConfig.getHealthUrl()).thenReturn("http://test.com/health");
        Mockito.when(healthOperations.healthCheck("http://test.com/health")).thenReturn(Status.UP);
    }

    @Test
    void validated() {
        // arrange
        var component = new StateHealthComponent(a2pGraphQLConfig, healthOperations);
        var indicator = new ValidatedHealthIndicator(component);
        // act
        var health = indicator.health();
        // assert
        Assertions.assertNotNull(health);
        Assertions.assertEquals(Status.UP.getCode(), health.getStatus().getCode());
        // arrange
        Mockito.when(healthOperations.healthCheck("http://test.com/health")).thenReturn(Status.DOWN);
        component = new StateHealthComponent(a2pGraphQLConfig, healthOperations);
        indicator = new ValidatedHealthIndicator(component);
        // act
        health = indicator.health();
        // assert
        Assertions.assertNotNull(health);
        Assertions.assertEquals(Status.DOWN.getCode(), health.getStatus().getCode());
    }

    @Test
    void custom() {
        // arrange
        var indicator = new CustomHealthIndicator();
        // act
        var health = indicator.health();
        // assert
        Assertions.assertNotNull(health);
        Assertions.assertEquals(Status.UP.getCode(), health.getStatus().getCode());
    }

    @Test
    void processed() {
        // arrange
        var indicator = new ProcessedHealthIndicator();
        // act
        var health = indicator.health();
        // assert
        Assertions.assertNotNull(health);
        Assertions.assertEquals(Status.UP.getCode(), health.getStatus().getCode());
    }

    @Test
    void all() {
        // arrange
        var component = new StateHealthComponent(a2pGraphQLConfig, healthOperations);
        var validated = new ValidatedHealthIndicator(component);
        var custom = new CustomHealthIndicator();
        var processed = new ProcessedHealthIndicator();
        // act
        var validatedHealth = validated.health();
        var customHealth = custom.health();
        var processedHealth = processed.health();
        // assert
        Assertions.assertNotNull(validatedHealth);
        Assertions.assertEquals(Status.UP.getCode(), validatedHealth.getStatus().getCode());
        Assertions.assertNotNull(custom);
        Assertions.assertEquals(Status.UP.getCode(), customHealth.getStatus().getCode());
        Assertions.assertNotNull(processedHealth);
        Assertions.assertEquals(Status.UP.getCode(), processedHealth.getStatus().getCode());
    }
}