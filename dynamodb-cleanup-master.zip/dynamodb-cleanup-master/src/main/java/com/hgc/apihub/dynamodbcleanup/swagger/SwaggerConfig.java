package com.hgc.apihub.dynamodbcleanup.swagger;

import com.hgc.lib.microservices.swagger.AbstractSwaggerConfig;
import org.springframework.context.annotation.Configuration;

import java.util.function.Predicate;

import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
public class SwaggerConfig extends AbstractSwaggerConfig  {

    @Override
    public final String apiGroupName() {
        return "dynamodb-cleanup-v1";
    }

    @Override
    public final String apiBasePackage() {
        return "com.hgc.apihub.dynamodbcleanup.controller";
    }

    @Override
    public final Predicate<String> apiPaths() {
        return regex("/dynamodb-cleanup/v1.*");
    }

    @Override
    public final String apiInfoDescription() {
        return "Microservice build on spring boot for HGC";
    }
}
