package com.hgc.apihub.callback.model.asfe.enums;

public enum SubType {

    CMHK_NOTIFY,
    AS_NOTIFY,
    OUTAGE_START,
    OUTAGE_END,
    AS_NOTIFICATION_QUEUE
}
