#!/bin/bash

/home/docker_user/awscli/bin/aws dynamodb create-table --table-name callback_lock --attribute-definitions AttributeName=key,AttributeType=S --key-schema AttributeName=key,KeyType=HASH --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=5 --endpoint-url http://localhost:8000

/home/docker_user/awscli/bin/aws dynamodb create-table --table-name callback --attribute-definitions AttributeName=transaction_id,AttributeType=S AttributeName=event_id,AttributeType=S --key-schema AttributeName=transaction_id,KeyType=HASH AttributeName=event_id,KeyType=RANGE --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=5 --endpoint-url http://localhost:8000

/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "callback"}, "state": {"S": "ACCEPTED"}, "entry_node": {"BOOL": true}}' --endpoint-url http://localhost:8000
/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "callback"}, "state": {"S": "VALIDATED"}, "sqs_name": {"S": "callback-validate"}, "sqs_dlq_name": {"S": "callback-dlq"}}' --endpoint-url http://localhost:8000
/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "callback"}, "state": {"S": "CREATED"}, "sqs_name": {"S": "callback-create"}, "sqs_dlq_name": {"S": "callback-dlq"}}' --endpoint-url http://localhost:8000
/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "callback"}, "state": {"S": "PROCESSED"}, "sqs_name": {"S": "callback-process"}, "sqs_dlq_name": {"S": "callback-dlq"}}' --endpoint-url http://localhost:8000
/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "callback"}, "state": {"S": "REJECTED"}, "entry_node": {"BOOL": true}}' --endpoint-url http://localhost:8000

/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_edge --item '{"project_name": {"S": "callback"}, "state": {"S": "ACCEPTED"}, "to_states": {"S": "VALIDATED"}}' --endpoint-url http://localhost:8000
/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_edge --item '{"project_name": {"S": "callback"}, "state": {"S": "VALIDATED"}, "to_states": {"S": "CREATED"}, "weights": {"S": "[{\"expression\":\"return proceed\",\"bindings\":{\"proceed\":true}}]"}}' --endpoint-url http://localhost:8000
/home/docker_user/awscli/bin/aws dynamodb put-item --table-name state_edge --item '{"project_name": {"S": "callback"}, "state": {"S": "CREATED"}, "to_states": {"S": "CREATED,PROCESSED"}, "weights": {"S": "[{\"expression\":\"return proceed_to_create\",\"bindings\":{\"proceed_to_create\":true}},{\"expression\":\"return proceed_to_process\",\"bindings\":{\"proceed_to_process\":true}}]"}}' --endpoint-url http://localhost:8000
