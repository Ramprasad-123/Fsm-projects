package com.hgc.apihub.callback.service.asfe;

import com.hgc.apihub.callback.configuration.CmhkConfig;
import com.hgc.apihub.callback.dao.asfe.AtomsDao;
import com.hgc.apihub.callback.exception.asfe.CmhkTokenException;
import com.hgc.apihub.callback.model.asfe.ProcessScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.apihub.callback.model.asfe.enums.CallbackType;
import com.hgc.apihub.graphqlatoms.client.type.AsNotificationQueueUpdateInput;
import com.hgc.lib.core.exception.GraphQLMutationException;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestOperations;

import java.util.stream.Stream;

import static com.hgc.apihub.callback.AsfeTestHelper.*;

@ExtendWith(SpringExtension.class)
class AsfeServiceTest {

    private AsfeService service;

    @MockBean
    private RestOperations restOperations;
    @MockBean
    private CmhkConfig config;
    @MockBean
    private CmhkAuthService cmhkAuthService;
    @MockBean
    private AtomsDao atomsDao;

    @BeforeEach
    public void setup() throws CmhkTokenException {
        Mockito.when(config.getHost()).thenReturn("test");
        Mockito.when(config.getTokenUrl()).thenReturn("test");
        Mockito.when(config.getNotifyUrl()).thenReturn("test");
        Mockito.when(config.getAppId()).thenReturn("test");
        Mockito.when(config.getAppSecret()).thenReturn("test");
        Mockito.when(cmhkAuthService.getToken()).thenReturn("test");
        restOperations = Mockito.mock(RestOperations.class);
        var serviceToSpy = new AsfeService(restOperations, config, cmhkAuthService, atomsDao);
        service = Mockito.spy(serviceToSpy);
    }

    private void mockCmhkNotifyCall(ResponseEntity expected) {
        Mockito.when(restOperations.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                (Class<Object>) ArgumentMatchers.any()
        )).thenReturn(expected);
    }

    @Test
    void notifyCmhk() {
        // arrange
        var cmhkNotifyResponse = getCmhkNotifySuccessResponse();
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.OK);
        Mockito.when(expected.getBody()).thenReturn(cmhkNotifyResponse);
        mockCmhkNotifyCall(expected);
        // act
        var actual = service.notifyCmhk(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE), QueueListenerResponse.builder(), getCmhkNotifyRequest());
        // assert
        Assertions.assertNull(actual);
    }

    @Test
    void notifyCmhkFailWith400() {
        // arrange
        var cmhkNotifyResponse = getCmhkNotifySuccessResponse();
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(expected.getBody()).thenReturn(cmhkNotifyResponse);
        mockCmhkNotifyCall(expected);
        // act
        var actual = service.notifyCmhk(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE), QueueListenerResponse.builder(), getCmhkNotifyRequest());
        // assert
        Assertions.assertNotNull(actual);
        Assertions.assertNotNull(actual.getField());
        Assertions.assertNotNull(actual.getMessage());
    }

    @Test
    void notifyCmhkFailWithGetTokenError() {
        // arrange
        var cmhkNotifyResponse = getCmhkNotifySuccessResponse();
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(expected.getStatusCodeValue()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR.value());
        Mockito.when(expected.getBody()).thenReturn(cmhkNotifyResponse);
        mockCmhkNotifyCall(expected);
        // act
        var actual = service.notifyCmhk(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE), QueueListenerResponse.builder(), getCmhkNotifyRequest());
        // assert
        Assertions.assertEquals("500", actual.getField());
    }

    @Test
    void notifyCmhkFailWithNot200() {
        // arrange
        var cmhkNotifyResponse = getCmhkNotifySuccessResponse();
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(expected.getStatusCodeValue()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR.value());
        Mockito.when(expected.getBody()).thenReturn(cmhkNotifyResponse);
        mockCmhkNotifyCall(expected);
        // act
        var actual = service.notifyCmhk(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE), QueueListenerResponse.builder(), getCmhkNotifyRequest());
        // assert
        Assertions.assertEquals("500", actual.getField());
    }

    @Test
    void notifyCmhkFailWithNullResponseBody() {
        // arrange
        var expected = Mockito.mock(ResponseEntity.class);
        Mockito.when(expected.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(expected.getStatusCodeValue()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR.value());
        Mockito.when(expected.getBody()).thenReturn(null);
        mockCmhkNotifyCall(expected);
        // act
        var actual = service.notifyCmhk(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE), QueueListenerResponse.builder(), getCmhkNotifyRequest());
        // assert
        Assertions.assertEquals("500", actual.getField());
    }

    private static Stream<Arguments> testArgumentProvider() {
        return Stream.of(
                Arguments.of(getScheduledMaintenanceStartRequest()),
                Arguments.of(getOutageStartRequest()),
                Arguments.of(getOutageEndRequest())
        );
    }

    @MethodSource("testArgumentProvider")
    @ParameterizedTest
    <T> void notifyAsfe(T request) throws GraphQLMutationException {
        // arrange
        Mockito.when(atomsDao.createAsNotify(Mockito.any())).thenReturn(null);
        // act
        var actual = service.notifyAsfe(request);
        // assert
        Assertions.assertNull(actual);
    }

    @Test
    void notifyAsfeFail() throws GraphQLMutationException {
        // arrange
        Mockito.when(atomsDao.createAsNotify(Mockito.any())).thenThrow(new GraphQLMutationException("test`"));
        // act
        var actual = service.notifyAsfe(getScheduledMaintenanceStartRequest());
        // assert
        Assertions.assertNotNull(actual);
        Assertions.assertEquals("500", actual.getField());
        Assertions.assertNotNull(actual.getMessage());
    }

    private static Stream<Arguments> updateAsNotificationQueueTestArgumentProvider() {
        return Stream.of(
                Arguments.of(getScheduledMaintenanceStartRequest(), null),
                Arguments.of(getOutageStartRequest(), null),
                Arguments.of(getOutageEndRequest(), null)
        );
    }

    @MethodSource("updateAsNotificationQueueTestArgumentProvider")
    @ParameterizedTest
    <T> void updateAsNotificationQueue(T request, final String errorMsg) throws GraphQLMutationException {
        // arrange
        Mockito.when(atomsDao.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenReturn(null);
        var input = ArgumentCaptor.forClass(AsNotificationQueueUpdateInput.class);
        // act
        var actual = service.updateAsNotificationQueue(request, errorMsg);
        // assert
        Assertions.assertNull(actual);
        Mockito.verify(atomsDao).updateAsNotificationQueue(Mockito.any(), input.capture());
        var expectedInput = (AsNotificationQueueUpdateInput) input.getValue();
        Assertions.assertNotNull(expectedInput.lastUpdtDate());
        Assertions.assertNotNull(expectedInput.lastUpdtBy());
        Assertions.assertTrue("DONE".equals(expectedInput.status()) || "ERROR".equals(expectedInput.status()));
    }

    private static Stream<Arguments> updateAsNotificationQueueFailTestArgumentProvider() {
        return Stream.of(
                Arguments.of(getScheduledMaintenanceStartRequest(), "error"),
                Arguments.of(getOutageStartRequest(), "error"),
                Arguments.of(getOutageEndRequest(), "error")
        );
    }

    @MethodSource("updateAsNotificationQueueFailTestArgumentProvider")
    @ParameterizedTest
    <T> void updateAsNotificationQueueFail(T request, final String errorMsg) throws GraphQLMutationException {
        // arrange
        Mockito.when(atomsDao.updateAsNotificationQueue(Mockito.any(), Mockito.any())).thenThrow(new GraphQLMutationException("test"));
        // act
        var actual = service.updateAsNotificationQueue(request, errorMsg);
        // assert
        Assertions.assertNotNull(actual);
        Assertions.assertEquals("500", actual.getField());
        Assertions.assertNotNull(actual.getMessage());
    }

    private static Stream<Arguments> mapCmhkNotifyRequestTestArgumentProvider() {
        return Stream.of(
                Arguments.of(getProcessScheduledMaintenanceStartRequest()),
                Arguments.of(getProcessScheduledMaintenanceEndRequest()),
                Arguments.of(getProcessOutageStartRequest()),
                Arguments.of(getProcessOutageStartRequestNoRemarks2()),
                Arguments.of(getProcessOutageEndRequest()),
                Arguments.of(getProcessOutageEndRequestNoRemarks2())
        );
    }

    @MethodSource("mapCmhkNotifyRequestTestArgumentProvider")
    @ParameterizedTest
    <T> void mapCmhkNotifyRequest(T request) throws GraphQLMutationException {
        // arrange
        Mockito.when(atomsDao.createAsNotify(Mockito.any())).thenReturn(null);
        // act
        var actual = AsfeService.mapCmhkNotifyRequest(request);
        // assert
        Assertions.assertNotNull(actual);
        if (request instanceof ProcessScheduledMaintenanceRequest requestObj) {
            if (CallbackType.PLANNED_MAINTENANCE_START == requestObj.getRequest().getCallbackType()) {
                Assertions.assertEquals("S", actual.getParams().getAction());
                Assertions.assertNotNull(actual.getParams().getTargetResumeTime());
            }
            if (CallbackType.PLANNED_MAINTENANCE_END == requestObj.getRequest().getCallbackType()) {
                Assertions.assertEquals("E", actual.getParams().getAction());
                Assertions.assertNotNull(actual.getParams().getTargetResumeTime());
            }
        }
    }
}