package com.hgc.apihub.callback.exception.ccHub;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/*
    Error handler return types control ============================================
    // Approach 1: Error response to be returned ------------------------------
    // 1a)  : return Enum defined error message
    var errorResponse = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, ExceptionHandlerType.InternalServerException);
    return new ResponseEntity<>(errorResponse, new HttpHeaders(), HttpStatus.NOT_FOUND);

    // 1b) : return exception info from exception object
    var errorResponse = new ErrorResponse(getExceptionCause(exception), HttpStatus.INTERNAL_SERVER_ERROR, ExceptionHandlerType.InternalServerException);
    return new ResponseEntity<>(errorResponse, new HttpHeaders(), HttpStatus.NOT_FOUND);

    // Approach 1: Error response NOT returned, return status code only  ------------------------------
    return handleExceptionInternal(exception, null, new HttpHeaders(), HttpStatus.NOT_FOUND,request);
 * */


@ControllerAdvice
public class SanitizedExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(SanitizedExceptionHandler.class);

    // Method to extract exception info
    private String getExceptionCause(Exception exception) {
        return exception.toString() + "-" + exception.getCause().toString();
    }


    // Custom Exception handlers --------------------------------------------------------------------------------------------------------
    @ExceptionHandler(CcHubNotFoundException.class)
    protected final ResponseEntity<Object> handleCcHubNotFoundException(final CcHubNotFoundException exception, final WebRequest request){
        var errorResponse = new ErrorResponse(HttpStatus.NOT_FOUND, ExceptionHandlerType.CcHubNotFoundException);
        return new ResponseEntity<>(errorResponse, new HttpHeaders(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CcHubDeleteOperationFailException.class)
    protected final ResponseEntity<Object> handleCcHubDeleteOperationFailException(final CcHubDeleteOperationFailException exception, final WebRequest request){
        var errorResponse = new ErrorResponse(HttpStatus.NOT_FOUND, ExceptionHandlerType.CcHubDeleteOperationFailException);
        return new ResponseEntity<>(errorResponse, new HttpHeaders(), HttpStatus.NOT_FOUND);
    }


}
