package com.hgc.apihub.testfsm.controller;

//TODO sample code, to be removed/updated

import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.statemachine.swagger.AsyncState202Response;
import com.hgc.lib.microservices.statemachine.swagger.ErrorState400Response;
import com.hgc.lib.microservices.swagger.Error400Response;
import com.hgc.lib.microservices.swagger.Error404Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import com.hgc.apihub.testfsm.model.TestFsmRequest;
import com.hgc.apihub.testfsm.model.TestFsmResponse;
import com.hgc.apihub.testfsm.service.TestFsmService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;

import java.util.List;

import static com.hgc.lib.microservices.MicroservicesHelper.*;

@RestController
@RequestMapping("/v1")
@Validated
@RequiredArgsConstructor
@Tag(name = "Test fsm Controller", description = "Operations pertaining to Test fsm")
public class TestFsmController {

    private final TestFsmService testfsmService;

    /**
     * Create Test fsm
     *
     * @param request the request
     * @return Test fsm
     */
    @Operation(
            summary = "Create Test fsm",
            description = "Create Test fsm asynchronous"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_202,
                            description = API_RESPONSE_CODE_202_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AsyncState202Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> createTestFsm(@Validated @RequestBody final TestFsmRequest request) throws Exception {
        var response = testfsmService.createTestFsm(request);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }

    /**
     * Get Test fsm by transaction ID and event ID
     *
     * @return Test fsm
     */
    @Operation(
            summary = "Get Test fsm",
            description = "Get Test fsm by transaction ID and event ID"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = TestFsmResponse.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_202,
                            description = API_RESPONSE_CODE_202_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AsyncState202Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorState400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @GetMapping(path = "/transaction/{transaction_id}/event/{event_id}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> getResponseByTransactionIdAndEventId(@Parameter(description = TRANSACTION_ID_SWAGGER_VALUE, required = true, example = TRANSACTION_ID_SWAGGER_EXAMPLE) @PathVariable("transaction_id") @NotBlank final String transactionId,
                                                                  @Parameter(description = EVENT_ID_SWAGGER_VALUE, required = true, example = EVENT_ID_SWAGGER_EXAMPLE) @PathVariable("event_id") @NotBlank final String eventId) throws Exception {
        var response = testfsmService.getResponseByTransactionIdAndEventId(transactionId, eventId);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }

    /**
     * Log status
     *
     * @param request the request
     * @return log status
     */
    @Operation(
            summary = "Log status"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE
                    )
            }
    )
    @PostMapping(path = "/status", consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> logStatus(@RequestBody final String request) {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Log files
     *
     * @param subject the subject
     * @param files   the files
     * @return success or not
     * @throws Exception the exception
     */
    @PostMapping(path = "/files", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> logFiles(@RequestParam final String subject, @RequestPart("file") final List<MultipartFile> files) throws Exception {
        var response = testfsmService.logFiles(subject, files);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }
}
