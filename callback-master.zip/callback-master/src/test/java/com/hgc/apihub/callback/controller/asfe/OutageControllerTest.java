package com.hgc.apihub.callback.controller.asfe;

import com.hgc.apihub.callback.listener.AcceptedListener;
import com.hgc.apihub.callback.model.asfe.OutageEndRequest;
import com.hgc.apihub.callback.model.asfe.OutageStartRequest;
import com.hgc.lib.microservices.aws.fsm.model.AWSQueueMessagingTemplate;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.configuration.APIMConfig;
import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.configuration.StateNodeConfig;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.State;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static com.hgc.apihub.callback.AsfeTestHelper.getAsfeAsyncResponse;
import static com.hgc.apihub.callback.AsfeTestHelper.getOutageStartRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getOutageEndRequest;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@WebMvcTest(OutageController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@Import(SanitizedExceptionHandler.class)
class OutageControllerTest {

    @MockBean
    private BuildProperties buildProperties;

    @MockBean
    private StateNodeConfig stateNodeConfig;

    @MockBean
    private DynamoDBDao dynamoDBDao;

    @MockBean
    private AWSStateGraph awsStateGraph;

    @MockBean
    private APIMConfig apimConfig;

    @MockBean
    private AWSQueueMessagingTemplate awsQueueMessagingTemplate;

    @MockBean
    private AcceptedListener service;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void startOutage() throws Exception {
        // arrange
        var response = AsyncStateResponse.asyncStateBuilder()
                .transactionId("ID0000021")
                .eventId("ID0000022")
                .state(State.ACCEPTED.name())
                .links(List.of(Link.withSelfRelation("https://apihub.hgc.com/test/ID0000021")))
                .build();
        BDDMockito.given(service.startOutage(Mockito.any(OutageStartRequest.class))).willReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.post("/v1/asfe/outage/start")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getOutageStartRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.state").value(response.getState()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.transaction_id").value(response.getTransactionId()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.event_id").value(response.getEventId()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].relation").value(response.getLinks().get(0).getRelation()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].method").value(response.getLinks().get(0).getMethod().name()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].href").value(response.getLinks().get(0).getHref()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(202))
                .andExpect(MockMvcResultMatchers.status().isAccepted());
    }

    @Test
    void endOutage() throws Exception {
        // arrange
        var response = AsyncStateResponse.asyncStateBuilder()
                .transactionId("ID0000021")
                .eventId("ID0000022")
                .state(State.ACCEPTED.name())
                .links(List.of(Link.withSelfRelation("https://apihub.hgc.com/test/ID0000021")))
                .build();
        BDDMockito.given(service.endOutage(Mockito.any(OutageEndRequest.class))).willReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.post("/v1/asfe/outage/end")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getOutageEndRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.state").value(response.getState()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.transaction_id").value(response.getTransactionId()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.event_id").value(response.getEventId()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].relation").value(response.getLinks().get(0).getRelation()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].method").value(response.getLinks().get(0).getMethod().name()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.links[0].href").value(response.getLinks().get(0).getHref()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(202))
                .andExpect(MockMvcResultMatchers.status().isAccepted());
    }

    @Test
    void getResponseByTransactionIdAndEventId() throws Exception {
        // arrange
        var response = getAsfeAsyncResponse();
        BDDMockito.given(service.getResponseByTransactionIdAndEventId("ID0000021", "ID0000022")).willReturn(response);
        // act
        this.mockMvc.perform(MockMvcRequestBuilders.get("/v1/asfe/outage/transaction/ID0000021/event/ID0000022"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.transaction_id").value(response.getTransactionId()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.event_id").value(response.getEventId()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.state").value(response.getState()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(202))
                .andExpect(MockMvcResultMatchers.status().isAccepted());
    }
}