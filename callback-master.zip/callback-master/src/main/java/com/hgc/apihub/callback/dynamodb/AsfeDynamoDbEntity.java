package com.hgc.apihub.callback.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsfeDynamoDbEntity extends DynamoDBEntity {

    @DynamoDBAttribute(attributeName = "action")
    @DynamoDBTypeConverted(converter = AsfeActionConverter.class)
    private AsFeAction action;

    public AsfeDynamoDbEntity(final AsFeAction actionValue, final FSMEntity item) {
        super(item.getTransactionId(), item.getEventId(), item.getState(), item.getSubState(), item.getData(), null, null);
        this.action = actionValue;
    }
}
