package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Generated;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
@Getter
@Generated
@RequiredArgsConstructor
public class CmhkAuthRequest implements Serializable {
    @JsonProperty("appId")
    private final String appId;

    @JsonProperty("appSecret")
    private final String appSecret;
}
