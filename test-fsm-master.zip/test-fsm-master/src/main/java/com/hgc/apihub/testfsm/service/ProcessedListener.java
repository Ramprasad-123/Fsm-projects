package com.hgc.apihub.testfsm.service;

//TODO sample code, to be removed/updated

import com.hgc.apihub.testfsm.model.TestFsmRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.service.BasicAWSProcessedListener;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.StateResponse;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
public class ProcessedListener extends BasicAWSProcessedListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(ProcessedListener.class);

    @Override
    public final void defaultBindings(final FSMEntity item, final QueueListenerResponse.Builder builder) {
        builder.addBinding("proceed_to_delivery", StringUtils.hasText(item.getCallbackUrl()));
    }

    @Override
    public final QueueListenerRequest<? extends QueueListenerBody> deserializeBody(final String body) throws Exception {
        return OBJECT_MAPPER.readValue(body, new TypeReference<QueueListenerRequest<TestFsmRequest>>() {
        });
    }

    @Override
    public final void executeClean(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) throws Exception {
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "inside processed execute clean...");
        builder.stateData(StateResponse.stateBuilder().transactionId(request.getTransactionId()).eventId(request.getEventId()).state(builder.getState()).build());
    }

    @Override
    public final void executeDirty(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) throws Exception {
        // do nothing
    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }
}
