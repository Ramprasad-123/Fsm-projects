package com.hgc.apihub.callback.dynamodb;

import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AsfeActionConverterTest {

    AsfeActionConverter converter;

    @BeforeEach
    void setUp() {
        converter = new AsfeActionConverter();
    }

    @Test
    void convert() {
        // arrange
        var expected = "OUTAGE_END";
        // act
        var actual = converter.convert(AsFeAction.OUTAGE_END);
        // assert
        Assertions.assertEquals(expected, actual);

        // arrange
        expected = null;
        // act
        actual = converter.convert(null);
        // assert
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void unconvert() {
        // arrange
        var expected = AsFeAction.OUTAGE_START;
        // act
        var actual = converter.unconvert("OUTAGE_START");
        // assert
        Assertions.assertEquals(expected, actual);

        // arrange
        expected = null;
        // act
        actual = converter.unconvert("");
        // assert
        Assertions.assertEquals(expected, actual);
    }
}