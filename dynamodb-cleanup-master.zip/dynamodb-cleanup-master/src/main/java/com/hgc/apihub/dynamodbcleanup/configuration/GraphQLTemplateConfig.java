package com.hgc.apihub.dynamodbcleanup.configuration;


import com.hgc.lib.graphql.client.GraphQLTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class GraphQLTemplateConfig {

    @Autowired
    private BuildProperties buildProperties;

    @Bean
    public GraphQLTemplate a2pGraphQLTemplate(final A2pGraphQLConfig a2pGraphQLConfig) {
        return GraphQLTemplate.builder()
                .serverUrl(a2pGraphQLConfig.getUrl())
                .connectTimeout(Duration.ofSeconds(a2pGraphQLConfig.getConnectTimeout()))
                .readTimeout(Duration.ofSeconds(a2pGraphQLConfig.getReadTimeout()))
                .writeTimeout(Duration.ofSeconds(a2pGraphQLConfig.getWriteTimeout()))
                .referer(buildProperties.getArtifact() + ":" + buildProperties.getVersion())
                .build();
    }

    @Bean
    public GraphQLTemplate graphQLTnssFbiTemplate(final GraphQLTnssFbiConfig graphQLFbiConfig) {
        return GraphQLTemplate.builder()
                .serverUrl(graphQLFbiConfig.getUrl())
                .connectTimeout(Duration.ofSeconds(graphQLFbiConfig.getConnectTimeout()))
                .readTimeout(Duration.ofSeconds(graphQLFbiConfig.getReadTimeout()))
                .writeTimeout(Duration.ofSeconds(graphQLFbiConfig.getWriteTimeout()))
                .referer(buildProperties.getArtifact() + ":" + buildProperties.getVersion())
                .build();
    }
}
