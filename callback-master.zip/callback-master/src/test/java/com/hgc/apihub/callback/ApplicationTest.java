package com.hgc.apihub.callback;

import com.hgc.apihub.callback.configuration.AtomsGraphQLConfig;
import com.hgc.apihub.callback.configuration.CmhkConfig;
import com.hgc.apihub.callback.configuration.GraphqlCcConfig;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = CallbackfsmTestConfig.class)
@ActiveProfiles("test")
class ApplicationTest {

    @Autowired
    private GraphqlCcConfig graphqlCcConfig;

    @Autowired
    private AtomsGraphQLConfig atomsGraphQLConfig;

    @Autowired
    private CmhkConfig cmhkConfig;

    @Autowired
    private GraphQLTemplate graphQlCcTemplate;

    @MockBean
    private AWSStateGraph awsStateGraph;

    @MockBean
    private BuildProperties buildProperties;

    @Test
    void configuration() {
        // assert
        Assertions.assertNotNull(graphqlCcConfig);
        Assertions.assertEquals("http://localhost:8016/graphql-cc/graphql", graphqlCcConfig.getUrl());
        Assertions.assertEquals(10, graphqlCcConfig.getConnectTimeout());
        Assertions.assertEquals(30, graphqlCcConfig.getReadTimeout());
        Assertions.assertEquals(30, graphqlCcConfig.getWriteTimeout());

        Assertions.assertNotNull(atomsGraphQLConfig);
        Assertions.assertEquals("http://localhost:8083/graphql-atoms/graphql", atomsGraphQLConfig.getUrl());
        Assertions.assertEquals(10, atomsGraphQLConfig.getConnectTimeout());
        Assertions.assertEquals(30, atomsGraphQLConfig.getReadTimeout());
        Assertions.assertEquals(30, atomsGraphQLConfig.getWriteTimeout());

        Assertions.assertNotNull(cmhkConfig);
        Assertions.assertNotNull(cmhkConfig.getHost());
        Assertions.assertNotNull(cmhkConfig.getTokenUrl());
        Assertions.assertNotNull(cmhkConfig.getAppId());
        Assertions.assertNotNull(cmhkConfig.getAppSecret());
    }

    @Test
    void restTemplateConfig() {
        // assert

        Assertions.assertNotNull(graphQlCcTemplate);
        Assertions.assertEquals("http://localhost:8016/graphql-cc/graphql", graphQlCcTemplate.getServerUrl());
        Assertions.assertEquals(10, graphQlCcTemplate.getConnectTimeout().getSeconds());
        Assertions.assertEquals(30, graphQlCcTemplate.getReadTimeout().getSeconds());
        Assertions.assertEquals(30, graphQlCcTemplate.getWriteTimeout().getSeconds());
    }
}
