package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.QueueRequestMetaData;
import lombok.Getter;

import java.util.Deque;

@Getter
public class BasicQueueListenerRequest<T extends QueueListenerBody> extends QueueListenerRequest<T> {

    @JsonProperty("sub_types")
    private final Deque<SubType> subTypes;

    @lombok.Builder(builderMethodName = "childBuilder")
    public BasicQueueListenerRequest(@JsonProperty("transaction_id") final String transactionId, @JsonProperty("event_id") final String eventId, @JsonProperty("correlation_id") final String correlationId,
                                     @JsonProperty("queue_state") final String queueState, @JsonProperty("queue_name") final String queueName, @JsonProperty("dlq_count") final int dlqCount,
                                     @JsonProperty("meta_data") final QueueRequestMetaData metaData, @JsonProperty("body") final T body, @JsonProperty("sub_types") final Deque<SubType> subTypeList) {
        super(transactionId, eventId, correlationId, queueState, queueName, dlqCount, metaData, body);
        this.subTypes = subTypeList;
    }

    public BasicQueueListenerRequest(final String transactionId, final String eventId, final T body, final Deque<SubType> subTypeList) {
        super(transactionId, eventId, null, null, null, 0, null, body);
        this.subTypes = subTypeList;
    }
}
