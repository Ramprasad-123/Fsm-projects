package com.hgc.apihub.hsbc.directdebit.model.dynamodb;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.hgc.apihub.hsbc.directdebit.model.DirectDebitType;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBDao;
import com.hgc.lib.microservices.statemachine.configuration.FSMDBConfig;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Primary
@Component
public class DirectDebitDao extends HGCDynamoDBDao<DirectDebitEntity> {

    /**
     * Constructor.
     *
     * @param fsmDBConfig              the FSM DB config
     * @param amazonDynamoDB           the amazon DynamoDB
     * @param dynamoDBMapper           the DynamoDB mapper
     */
    public DirectDebitDao(final FSMDBConfig fsmDBConfig, final AmazonDynamoDB amazonDynamoDB, final DynamoDBMapper dynamoDBMapper) {
        super(DirectDebitEntity.class, fsmDBConfig, amazonDynamoDB, dynamoDBMapper);
    }

    public final boolean existByReferenceId(final String referenceId) throws Exception {
        var results = getByReferenceId(referenceId);
        return !CollectionUtils.isEmpty(results);
    }

    public final DirectDebitEntity getByReferenceId(final String referenceId, final DirectDebitType type) throws Exception {
        var results = getByReferenceId(referenceId);
        return results.stream().filter(d -> type.name().equalsIgnoreCase(d.getType())).findFirst().orElse(null);
    }
}
