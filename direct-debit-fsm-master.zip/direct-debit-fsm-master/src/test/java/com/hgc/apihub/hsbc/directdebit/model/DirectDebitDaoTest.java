package com.hgc.apihub.hsbc.directdebit.model;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedQueryList;
import com.hgc.apihub.hsbc.directdebit.model.dynamodb.DirectDebitDao;
import com.hgc.apihub.hsbc.directdebit.model.dynamodb.DirectDebitEntity;
import com.hgc.lib.microservices.statemachine.configuration.FSMDBConfig;
import com.hgc.lib.microservices.statemachine.model.State;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.stream.Stream;

import static com.hgc.apihub.hsbc.directdebit.DirectDebitTestHelper.getDirectDebitEntity;

class DirectDebitDaoTest {

    private DynamoDBMapper dynamoDBMapper;
    private DirectDebitDao directDebitDao;

    @BeforeEach
    void setup() {
        var fsmDBConfig = new FSMDBConfig("test", null, new FSMDBConfig.Lock("test-lock", null, null), "dlq-table");
        dynamoDBMapper = Mockito.mock(DynamoDBMapper.class);
        var amazonDynamoDB = Mockito.mock(AmazonDynamoDB.class);
        directDebitDao = new DirectDebitDao(fsmDBConfig, amazonDynamoDB, dynamoDBMapper);
    }

    @Test
    void existByReferenceId() throws Exception {
        // arrange
        var type = DirectDebitType.AUTHORIZATION_INITIATE;
        var item = getDirectDebitEntity(type, State.VALIDATED);
        var itemList = Mockito.mock(PaginatedQueryList.class);
        Mockito.when(itemList.size()).thenReturn(1);
        Mockito.when(itemList.stream()).thenReturn(Stream.of(item));
        Mockito.when(dynamoDBMapper.query(Mockito.eq(DirectDebitEntity.class), Mockito.any(DynamoDBQueryExpression.class), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(itemList);
        // assert
        Assertions.assertTrue(directDebitDao.existByReferenceId(item.getReferenceId()));
        // act
        var responses = directDebitDao.getByReferenceId(item.getReferenceId(), type);
        // assert
        Assertions.assertNotNull(responses);
        org.assertj.core.api.Assertions.assertThat(item).usingRecursiveComparison().isEqualTo((responses));
        // arrange
        item = getDirectDebitEntity(DirectDebitType.AUTHORIZATION_UPDATE, State.VALIDATED);
        Mockito.when(itemList.stream()).thenReturn(Stream.of(item));
        // act
        responses = directDebitDao.getByReferenceId(item.getReferenceId(), type);
        // assert
        Assertions.assertNull(responses);
        // act
        Mockito.when(dynamoDBMapper.query(Mockito.eq(DirectDebitEntity.class), Mockito.any(DynamoDBQueryExpression.class), Mockito.any(DynamoDBMapperConfig.class))).thenReturn(null);
        // assert
        Assertions.assertFalse(directDebitDao.existByReferenceId(item.getReferenceId()));
    }
}
