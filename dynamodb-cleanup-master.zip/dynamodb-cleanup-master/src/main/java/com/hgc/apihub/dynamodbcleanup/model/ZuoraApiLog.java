package com.hgc.apihub.dynamodbcleanup.model;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
public class ZuoraApiLog implements Serializable {
    private String apiTransactionId;

    @Getter(AccessLevel.NONE)
    private String createDate;
}
