package com.hgc.apihub.hsbc.payme.model;

import com.hgc.apihub.hsbc.payme.model.dynamodb.PayMeDao;
import com.hgc.lib.microservices.statemachine.configuration.FSMDBConfig;
import com.hgc.lib.microservices.statemachine.model.State;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.BDDMockito;
import org.mockito.Mockito;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.QueryRequest;
import software.amazon.awssdk.services.dynamodb.model.QueryResponse;
import software.amazon.awssdk.services.dynamodb.paginators.QueryIterable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.hgc.apihub.hsbc.payme.PayMeTestHelper.getPayMeEntity;
import static com.hgc.apihub.hsbc.payme.PayMeTestHelper.getPayMeStateResponse;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

class PayMeDaoTest {

    private PayMeDao paymeDao;
    private DynamoDbClient dynamoDbClient;


    @BeforeEach
    void setup() {
        dynamoDbClient = Mockito.mock(DynamoDbClient.class);
        paymeDao = new PayMeDao(new FSMDBConfig("test", 10L, new FSMDBConfig.Lock("test-lock", null, null), "dlq-table"), dynamoDbClient);
    }

    @Test
    void getByRequestId() throws Exception {
        // arrange
        var type = PayMeType.PAYMENT;
        var subType = PayMeSubType.REQUEST;
        var requestId = "ID0000024";
        var entity = getPayMeEntity(null, null, State.PROCESSED, OBJECT_MAPPER.writeValueAsString(getPayMeStateResponse()));
        entity.setType(type);
        entity.setSubType(subType);
        entity.setRequestId(requestId);
        var response = new ArrayList<QueryResponse>();
        List.of(entity).forEach(item -> response.add(QueryResponse.builder()
                .items(List.of(Map.of("transaction_id", AttributeValue.fromS(item.getTransactionId()),"type", AttributeValue.fromS(item.getType().name()),"sub_type", AttributeValue.fromS(item.getSubType().name()), "request_id", AttributeValue.fromS(item.getRequestId()))))
                .build()
        ));
        var itemList = Mockito.mock(QueryIterable.class);
        BDDMockito.given(itemList.iterator()).willReturn(response.iterator());
        BDDMockito.given(dynamoDbClient.queryPaginator(Mockito.any(QueryRequest.class))).willReturn(itemList);
        // act
        var responses = paymeDao.getByRequestId(entity.getRequestId(), type, subType);
        // assert
        Assertions.assertNotNull(responses);
        org.assertj.core.api.Assertions.assertThat(entity).usingRecursiveComparison().comparingOnlyFields("transaction_id", "type", "sub_type", "request_id").isEqualTo(responses);
        // arrange
        BDDMockito.given(itemList.iterator()).willReturn(Collections.emptyIterator());
        // assert
        Assertions.assertNull(paymeDao.getByRequestId(entity.getRequestId(), type, PayMeSubType.CANCEL));
        Assertions.assertNull(paymeDao.getByRequestId(entity.getRequestId(), PayMeType.REFUND, subType));
        Assertions.assertNull(paymeDao.getByRequestId(entity.getRequestId(), null, subType));
        Assertions.assertNull(paymeDao.getByRequestId(entity.getRequestId(), type, null));
        Assertions.assertNull(paymeDao.getByRequestId(entity.getRequestId(), null, null));
    }
}
