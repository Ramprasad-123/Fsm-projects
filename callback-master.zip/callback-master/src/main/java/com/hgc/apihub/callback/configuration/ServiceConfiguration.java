package com.hgc.apihub.callback.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceConfiguration {

    @Bean
    @ConfigurationProperties(prefix = "graphql-cc")
    public GraphqlCcConfig graphqlCcConfigConfig() {
        return new GraphqlCcConfig();
    }

    @Bean
    @ConfigurationProperties(prefix = "graphql-atoms")
    public AtomsGraphQLConfig atomsGraphQLConfig() {
        return new AtomsGraphQLConfig();
    }

    @Bean
    @ConfigurationProperties(prefix = "cmhk")
    public CmhkConfig zuoraConfig() {
        return new CmhkConfig();
    }
}
