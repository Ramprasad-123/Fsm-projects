package com.hgc.apihub.dynamodbcleanup;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;
import com.hgc.apihub.dynamodbcleanup.model.DynamoDbOperationResponse;
import com.hgc.lib.microservices.model.Response;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class DynamoDbCleanUpTestHelper {

    private DynamoDbCleanUpTestHelper() {
    }

    public static DynamoDbOperationResponse getDeleteRecordSuccessResponse(){
        return new DynamoDbOperationResponse(200, "Operation success");
    }

    public static Response getSuccessResponse(){
        return new Response(200);
    }

    @NotNull
    public static List<DynamoDBMapper.FailedBatch> getFailedBatches() {
        List<DynamoDBMapper.FailedBatch> totalFailedBatches = new LinkedList();
        var pendingItems = new HashMap<String, List<WriteRequest>>();
        pendingItems.put("test", List.of());
        var failedBatch = new DynamoDBMapper.FailedBatch();
        failedBatch.setUnprocessedItems(pendingItems);
        failedBatch.setException(new RuntimeException("test"));
        totalFailedBatches.add(failedBatch);
        return totalFailedBatches;
    }
}
