package com.hgc.apihub.callback;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.apihub.callback.model.asfe.*;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.apihub.callback.model.asfe.enums.CallbackType;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.apihub.graphqlatoms.client.fragment.AsNotificationQueueFields;
import com.hgc.apihub.graphqlatoms.client.fragment.AsNotifyFields;
import com.hgc.apihub.graphqlatoms.client.queries.CreateAsNotifyMutation;
import com.hgc.apihub.graphqlatoms.client.queries.UpdateAsNotificationQueueMutation;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateEdge;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateNode;
import com.hgc.lib.microservices.aws.fsm.node.StateWeightConverter;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;

import java.util.Arrays;
import java.util.List;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;
import static com.hgc.lib.microservices.aws.fsm.common.AWSStateMachineMock.constructAWSStateGraph;

public class AsfeTestHelper {

    private AsfeTestHelper() {
    }

    public static AWSStateGraph constructStateGraph() {
        var nodes = List.of(
                new AWSStateNode("callback", State.ACCEPTED.name(), true, null, null),
                new AWSStateNode("callback", State.VALIDATED.name(), false, "callback-validate", "callback-dlq"),
                new AWSStateNode("callback", State.CREATED.name(), false, "callback-create", "callback-dlq"),
                new AWSStateNode("callback", State.PROCESSED.name(), false, "callback-process", "callback-dlq"),
                new AWSStateNode("callback", State.REJECTED.name(), true, null, null));
        var converter = new StateWeightConverter();
        var edges = List.of(
                new AWSStateEdge("callback", State.ACCEPTED.name(), List.of(State.VALIDATED.name()), null),
                new AWSStateEdge("callback", State.VALIDATED.name(), List.of(State.CREATED.name()), converter.unconvert("[{\"expression\":\"return proceed\",\"bindings\":{\"proceed\":true}}]")),
                new AWSStateEdge("callback", State.CREATED.name(), List.of(State.CREATED.name(), State.PROCESSED.name()), converter.unconvert("[" +
                        "{\"expression\":\"return proceed_to_create\",\"bindings\":{\"proceed_to_create\":true}}," +
                        "{\"expression\":\"return proceed_to_process\",\"bindings\":{\"proceed_to_process\":true}}" +
                        "]")));
        return constructAWSStateGraph(nodes, edges);
    }

    public static ScheduledMaintenanceRequest getScheduledMaintenanceStartRequest() {
        var store = getStore("Major", "2023-03-22 14:01:00", null);
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        var schMaint = new ScheduledMaintenanceRequest.SchMaint("2022-12-14 00:00:00", "2021-12-15 15:00:00");
        return new ScheduledMaintenanceRequest("1", CallbackType.PLANNED_MAINTENANCE_START, "CMHK", store, affectCustLnoc, schMaint);
    }

    public static ScheduledMaintenanceRequest getScheduledMaintenanceEndRequest() {
        var store = getStore("Major", null, "2023-03-22 14:01:00");
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        var schMaint = new ScheduledMaintenanceRequest.SchMaint("2022-12-14 00:00:00", "2021-12-15 15:00:00");
        return new ScheduledMaintenanceRequest("1", CallbackType.PLANNED_MAINTENANCE_END, "CMHK", store, affectCustLnoc, schMaint);
    }

    public static ScheduledMaintenanceRequest getScheduledMaintenanceRequestViolateNotNulls() {
        var store = getStore("Major", "2023-03-22 14:01:00", null);
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        return new ScheduledMaintenanceRequest("1", CallbackType.PLANNED_MAINTENANCE_START, "CMHK", store, affectCustLnoc, null);
    }

    public static ScheduledMaintenanceRequest getScheduledMaintenanceRequestViolateNotBlanks() {
        var store = getStore("Major", "2023-03-22 14:01:00", null);
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        return new ScheduledMaintenanceRequest("", CallbackType.PLANNED_MAINTENANCE_START, "CMHK", store, affectCustLnoc, getSchMaint());
    }

    public static ScheduledMaintenanceRequest.SchMaint getSchMaintViolateBlanks() {
        return new ScheduledMaintenanceRequest.SchMaint("", "");
    }

    public static ScheduledMaintenanceRequest.SchMaint getSchMaint() {
        return new ScheduledMaintenanceRequest.SchMaint("2022-12-14 00:00:00", "2021-12-15 15:00:00");
    }

    public static OutageStartRequest getOutageStartRequest() {
        var store = getStore("Minor", "2023-03-22 14:01:00", null);
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        return new OutageStartRequest("1", CallbackType.OUTAGE_START, "CMHK", store, affectCustLnoc);
    }

    public static BasicAsFeRequest getBasicAsfeRequest() {
        var store = getStore("Minor", "2023-03-22 14:01:00", "2023-03-22 15:01:00");
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        return new BasicAsFeRequest("1", CallbackType.OUTAGE_START, "CMHK", store, affectCustLnoc);
    }

    public static BasicAsFeRequest getBasicAsfeRequestViolateNotBlanks() {
        var store = getStoreViolateNotBlanks();
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("", "")
        );
        return new BasicAsFeRequest("", CallbackType.OUTAGE_START, "", store, affectCustLnoc);
    }

    public static BasicAsFeRequest getBasicAsfeRequestViolateNotNulls() {
        return new BasicAsFeRequest("1", null, "test", null, null);
    }

    public static BasicAsFeRequest.AffectCustLnoc getAffectCustLnoc() {
        return new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004");
    }

    public static BasicAsFeRequest.AffectCustLnoc getAffectCustLnocViolateBlanks() {
        return new BasicAsFeRequest.AffectCustLnoc("", "");
    }

    public static BasicAsFeRequest.Store getStore() {
        return new BasicAsFeRequest.Store("iyrMIN", "159920", "2022-12-13 12:34:56", "Minor", "2023-03-22 14:01:00", "GAS", "2023-03-22 14:02:00");
    }

    private static BasicAsFeRequest.Store getStore(final String severity, final String remark2, final String remarks7) {
        return new BasicAsFeRequest.Store("iyrMIN",
                "159920",
                "2022-12-13 12:34:56",
                severity,
                remark2,
                "GAS",
                remarks7);
    }

    public static BasicAsFeRequest.Store getStoreViolateNotBlanks() {
        return new BasicAsFeRequest.Store("",
                "",
                "",
                "",
                "2023-03-22 14:01:00",
                "GAS",
                "2023-03-22 14:02:00");
    }

    public static OutageStartRequest getOutageStartRequestNoRemark2() {
        var store = getStore("Minor", null, null);
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        return new OutageStartRequest("1", CallbackType.OUTAGE_START, "CMHK", store, affectCustLnoc);
    }

    public static OutageEndRequest getOutageEndRequest() {
        var store = getStore("MTCE", null, "2023-03-23 16:02:00");
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        return new OutageEndRequest("1", CallbackType.OUTAGE_RESUME, "CMHK", store, affectCustLnoc);
    }

    public static OutageEndRequest getOutageEndRequestNoRemark2() {
        var store = getStore("MTCE", "", "");
        var affectCustLnoc = List.of(
                new BasicAsFeRequest.AffectCustLnoc("700000000BB", "29801004"),
                new BasicAsFeRequest.AffectCustLnoc("700000001BB", "00009344")
        );
        return new OutageEndRequest("1", CallbackType.OUTAGE_RESUME, "CMHK", store, affectCustLnoc);
    }

    public static ProcessOutageStartRequest getProcessOutageStartRequest() {
        return new ProcessOutageStartRequest(getOutageStartRequest(), AsFeAction.OUTAGE_START);
    }

    public static ProcessOutageStartRequest getProcessOutageStartRequestNoRemarks2() {
        return new ProcessOutageStartRequest(getOutageStartRequestNoRemark2(), AsFeAction.OUTAGE_START);
    }

    public static ProcessOutageEndRequest getProcessOutageEndRequest() {
        return new ProcessOutageEndRequest(getOutageEndRequest(), AsFeAction.OUTAGE_END);
    }

    public static ProcessOutageEndRequest getProcessOutageEndRequestNoRemarks2() {
        return new ProcessOutageEndRequest(getOutageEndRequestNoRemark2(), AsFeAction.OUTAGE_END);
    }

    public static DynamoDBEntity getFsmEntity(final State state) throws JsonProcessingException {
        var data = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(getAsyncResponse());
        return new DynamoDBEntity(
                "T0000001",
                "E0000001",
                state.name(),
                SubState.ENTERED,
                data, null, null
        );
    }

    public static AsyncStateResponse getAsyncResponse() {
        return
                new AsyncStateResponse(
                        202,
                        "T0000001",
                        "E0000001",
                        State.ACCEPTED.name(),
                        "2023-01-10 12:12:12",
                        "2023-01-10 12:12:12",
                        List.of(Link.withSelfRelation("https://test-api.hgc.com.hk/v1/T0000001"))
                );
    }

    public static AsfeAsyncStateResponse getAsfeAsyncResponse(final List<SubType> remainingSubTypesValue) {
        return
                new AsfeAsyncStateResponse(
                        202,
                        "T0000001",
                        "E0000001",
                        State.ACCEPTED.name(),
                        "2023-01-10 12:12:12",
                        "2023-01-10 12:12:12",
                        List.of(Link.withSelfRelation("https://test-api.hgc.com.hk/v1/T0000001/event/E0000001")),
                        remainingSubTypesValue
                );
    }

    public static AsfeAsyncStateResponse getAsfeAsyncResponse() {
        return
                new AsfeAsyncStateResponse(
                        202,
                        "T0000001",
                        "E0000001",
                        State.ACCEPTED.name(),
                        "2023-01-10 12:12:12",
                        "2023-01-10 12:12:12",
                        List.of(Link.withSelfRelation("https://test-api.hgc.com.hk/v1/T0000001/event/E0000001")),
                        List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY)
                );
    }

    public static ProcessScheduledMaintenanceRequest getProcessScheduledMaintenanceStartRequest() {
        return new ProcessScheduledMaintenanceRequest(getScheduledMaintenanceStartRequest(), AsFeAction.SCHEDULED_MAINTENANCE);
    }

    public static ProcessScheduledMaintenanceRequest getProcessScheduledMaintenanceEndRequest() {
        return new ProcessScheduledMaintenanceRequest(getScheduledMaintenanceEndRequest(), AsFeAction.SCHEDULED_MAINTENANCE);
    }

    public static QueueListenerRequest<?> getQueueListenerRequest(final AsFeAction action) {
        if (action != null) {
            if (action == AsFeAction.SCHEDULED_MAINTENANCE) {
                return QueueListenerRequest.builder().body(getProcessScheduledMaintenanceStartRequest()).build();
            }
            if (action == AsFeAction.OUTAGE_START) {
                return QueueListenerRequest.builder().body(getProcessOutageStartRequest()).build();
            }
            if (action == AsFeAction.OUTAGE_END) {
                return QueueListenerRequest.builder().body(getProcessOutageEndRequest()).build();
            }
        }
        return QueueListenerRequest.builder().build();
    }

    public static CmhkTokenResponse getCmhkTokenResponse() {
        return new CmhkTokenResponse(200,
                "get bcocGenerateToken sucess",
                "The api invoke sucess",
                "76707894",
                "user",
                "access_token_value",
                "bearer",
                "9f94445f-067f-4158-bd8a-001eb62a6965");
    }

    public static CmhkTokenResponse getCmhkTokenResponseNoExpiresIn() {
        return new CmhkTokenResponse(200,
                "get bcocGenerateToken sucess",
                "The api invoke sucess",
                "",
                "user",
                "access_token_value",
                "bearer",
                "9f94445f-067f-4158-bd8a-001eb62a6965");
    }

    public static CmhkNotifyResponse getCmhkNotifySuccessResponse() {
        var outData = new CmhkNotifyResponse.OutData(List.of(new CmhkNotifyResponse.OutData.Beans()), "成功!", new CmhkNotifyResponse.OutData.Bean(), "0", new CmhkNotifyResponse.OutData.Object("0", "Success!"));
        return new CmhkNotifyResponse("SVC-200", "api call success!", "service url: /bcoc/business/NGCS/pushMessage/v1/noti_pushAlarmData, startTime: 2022-12-07 14:42:40, elapsed: 153ms", outData);
    }

    public static CreateAsNotifyMutation.Data getCreateAsNotifyMutationData() {
        var createAsNotify = CreateAsNotifyMutation.CreateAsNotify.builder()
                .__typename("test")
                .fragments(CreateAsNotifyMutation.CreateAsNotify.Fragments.builder()
                        .asNotifyFields(AsNotifyFields.builder()
                                .__typename("test")
                                .uniqueId("1")
                                .build())
                        .build())
                .build();
        return CreateAsNotifyMutation.Data.builder().createAsNotify(createAsNotify).build();
    }

    public static CreateAsNotifyMutation.Data getCreateAsNotifyMutationDataWithEmptyId() {
        var createAsNotify = CreateAsNotifyMutation.CreateAsNotify.builder()
                .__typename("test")
                .fragments(CreateAsNotifyMutation.CreateAsNotify.Fragments.builder()
                        .asNotifyFields(AsNotifyFields.builder()
                                .__typename("test")
                                .build())
                        .build())
                .build();
        return CreateAsNotifyMutation.Data.builder().createAsNotify(createAsNotify).build();
    }

    public static CmhkNotifyRequest getCmhkNotifyRequest() {
        List<String> addressCodesList = Arrays.asList("1234","23456");
        return new CmhkNotifyRequest(new CmhkNotifyRequest.Params(
                "159920",
                "29801004 29801001",
                addressCodesList,
                "M",
                "O",
                "H",
                "S",
                "2022-12-13 12:34:56",
                "2022-12-14 00:00:00",
                "SW",
                "2021-12-15 15:00:00",
                "HGC"
        ));
    }

    public static UpdateAsNotificationQueueMutation.Data getUpdateAsNotificationQueueMutationData() {
        var updateAsNoti = UpdateAsNotificationQueueMutation.UpdateAsNotificationQueue.builder()
                .__typename("test")
                .fragments(UpdateAsNotificationQueueMutation.UpdateAsNotificationQueue.Fragments.builder()
                        .asNotificationQueueFields(AsNotificationQueueFields.builder()
                                .__typename("test")
                                .status("DONE")
                                .build())
                        .build())
                .build();
        return UpdateAsNotificationQueueMutation.Data.builder().updateAsNotificationQueue(updateAsNoti).build();
    }

    public static UpdateAsNotificationQueueMutation.Data getUpdateAsNotificationQueueMutationDataWithEmptyFields() {
        var createAsNotify = UpdateAsNotificationQueueMutation.UpdateAsNotificationQueue.builder()
                .__typename("test")
                .fragments(UpdateAsNotificationQueueMutation.UpdateAsNotificationQueue.Fragments.builder()
                        .asNotificationQueueFields(AsNotificationQueueFields.builder()
                                .__typename("test")
                                .build())
                        .build())
                .build();
        return UpdateAsNotificationQueueMutation.Data.builder().updateAsNotificationQueue(createAsNotify).build();
    }
}
