package com.hgc.apihub.dynamodbcleanup.model;

public enum TableName {
    a2p,
    tnssintegration
}
