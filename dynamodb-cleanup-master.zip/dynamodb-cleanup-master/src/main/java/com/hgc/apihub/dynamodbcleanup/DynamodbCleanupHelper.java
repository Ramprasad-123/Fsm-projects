package com.hgc.apihub.dynamodbcleanup;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DynamodbCleanupHelper {
    public static final String DATE_FORMAT_YMDHMS = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_YMD = "yyyy-MM-dd";
    public static final DateTimeFormatter DATE_FORMATTER_YMDHMS = DateTimeFormatter.ofPattern(DATE_FORMAT_YMDHMS);
    public static final DateTimeFormatter DATE_FORMATTER_YMD = DateTimeFormatter.ofPattern(DATE_FORMAT_YMD);
    public static final ZoneId ZONE_CODE_GMT8 = ZoneId.of("Asia/Hong_Kong");
}
