package com.hgc.apihub.hsbc.payme.model.dynamodb;


import com.hgc.apihub.hsbc.payme.model.PayMeSubType;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public class PayMeSubTypeConverter implements AttributeConverter<PayMeSubType> {

    @Override
    public final EnhancedType<PayMeSubType> type() {
        return EnhancedType.of(PayMeSubType.class);
    }

    @Override
    public final AttributeValueType attributeValueType() {
        return AttributeValueType.S;
    }

    @Override
    public final AttributeValue transformFrom(final PayMeSubType input) {
        if (input != null) {
            return AttributeValue.fromS(input.name());
        }
        return null;
    }

    @Override
    public final PayMeSubType transformTo(final AttributeValue input) {
        if (input != null) {
            return PayMeSubType.valueOf(input.s());
        }
        return null;
    }
}
