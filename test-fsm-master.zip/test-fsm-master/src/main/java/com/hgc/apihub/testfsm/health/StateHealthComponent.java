package com.hgc.apihub.testfsm.health;

import com.hgc.apihub.testfsm.configuration.A2PGraphQLConfig;
import com.hgc.lib.microservices.health.HealthOperations;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

@Component
@RequestScope
public class StateHealthComponent {

    private final A2PHealthIndicator a2p;

    public StateHealthComponent(final A2PGraphQLConfig a2pGraphQLConfig, final HealthOperations healthOperations) {
        a2p = new A2PHealthIndicator(a2pGraphQLConfig, healthOperations);
    }

    /**
     * Update health check based on provided state
     */
    protected void updateHealthCheck() {
        a2p.updateHealthCheck();
    }

    /**
     * Get A2P health indicator
     *
     * @return a2p
     */
    protected A2PHealthIndicator getA2P() {
        return a2p;
    }
}
