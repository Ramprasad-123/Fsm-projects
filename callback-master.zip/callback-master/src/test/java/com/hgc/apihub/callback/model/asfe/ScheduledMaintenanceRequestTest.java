package com.hgc.apihub.callback.model.asfe;

import com.hgc.lib.microservices.common.validation.BlankValidationTest;
import com.hgc.lib.microservices.common.validation.NullValidationTest;

import java.util.List;

import static com.hgc.apihub.callback.AsfeTestHelper.getScheduledMaintenanceRequestViolateNotBlanks;
import static com.hgc.apihub.callback.AsfeTestHelper.getScheduledMaintenanceRequestViolateNotNulls;
import static com.hgc.apihub.callback.AsfeTestHelper.getScheduledMaintenanceStartRequest;

class ScheduledMaintenanceRequestTest implements NullValidationTest<ScheduledMaintenanceRequest> , BlankValidationTest<ScheduledMaintenanceRequest> {

    @Override
    public List<ScheduledMaintenanceRequest> nullInstances() {
        return List.of(getScheduledMaintenanceRequestViolateNotNulls());
    }

    @Override
    public List<Integer> numberOfNonNullAnnotations() {
        return List.of(1);
    }

    @Override
    public ScheduledMaintenanceRequest validInstance() {
        return getScheduledMaintenanceStartRequest();
    }

    @Override
    public List<ScheduledMaintenanceRequest> blankInstances() {
        return List.of(getScheduledMaintenanceRequestViolateNotBlanks());
    }

    @Override
    public List<Integer> numberOfNonBlankAnnotations() {
        return List.of(1);
    }
}