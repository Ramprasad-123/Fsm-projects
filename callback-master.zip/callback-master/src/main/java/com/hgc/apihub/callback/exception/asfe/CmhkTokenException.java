package com.hgc.apihub.callback.exception.asfe;

public class CmhkTokenException extends Exception {
    public CmhkTokenException(final String message) {
        super(message);
    }
}
