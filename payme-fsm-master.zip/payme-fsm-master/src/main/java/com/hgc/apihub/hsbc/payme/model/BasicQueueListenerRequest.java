package com.hgc.apihub.hsbc.payme.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.QueueRequestMetaData;
import com.hgc.lib.microservices.statemachine.model.QueueRequestParallelMetaData;
import lombok.Getter;

@Getter
public class BasicQueueListenerRequest<T extends QueueListenerBody> extends QueueListenerRequest<T> {

    private final PayMeType type;
    @JsonProperty("sub_type")
    private final PayMeSubType subType;
    @JsonProperty("profile_id")
    private final String profileId;
    @JsonProperty("event_type")
    private final String eventType;
    @JsonProperty("polling_count")
    private int pollingCount;

    public BasicQueueListenerRequest(@JsonProperty("transaction_id") final String transactionId, @JsonProperty("event_id") final String eventId, @JsonProperty("correlation_id") final String correlationId,
                                     @JsonProperty("queue_state") final String queueState, @JsonProperty("queue_name") final String queueName, @JsonProperty("dlq_count") final int dlqCount,
                                     @JsonProperty("meta_data") final QueueRequestMetaData metaData, @JsonProperty("parallel_request_meta_data") final QueueRequestParallelMetaData parallelMetaData,
                                     @JsonProperty("body") final T body, @JsonProperty("type") final PayMeType typeEnum, @JsonProperty("sub_type") final PayMeSubType subTypeEnum,
                                     @JsonProperty("profile_id") final String profileIdValue, @JsonProperty("event_type") final String eventTypeValue, @JsonProperty("polling_count") final int pollingCountValue) {
        super(transactionId, eventId, correlationId, queueState, queueName, dlqCount, metaData, parallelMetaData, body);
        this.type = typeEnum;
        this.subType = subTypeEnum;
        this.profileId = profileIdValue;
        this.eventType = eventTypeValue;
        this.pollingCount = pollingCountValue;
    }

    public BasicQueueListenerRequest(final BasicQueueListenerRequest<? extends QueueListenerBody> request, final T body) {
        super(request.getTransactionId(), request.getEventId(), null, null, null, 0, null, null, body);
        this.type = request.getType();
        this.subType = request.getSubType();
        this.profileId = request.getProfileId();
        this.eventType = request.getEventType();
    }

    public BasicQueueListenerRequest(final String transactionId, final String eventId, final T body, final PayMeType typeEnum, final PayMeSubType subTypeEnum, final String profileIdValue, final String eventTypeValue) {
        super(transactionId, eventId, null, null, null, 0, null, null, body);
        this.type = typeEnum;
        this.subType = subTypeEnum;
        this.profileId = profileIdValue;
        this.eventType = eventTypeValue;
    }

    public BasicQueueListenerRequest(final String transactionId, final String eventId, final String correlationId, final String queueState, final String queueName, final QueueRequestMetaData metaData, final QueueRequestParallelMetaData parallelMetaData, final T body, final PayMeType typeEnum, final PayMeSubType subTypeEnum) {
        this(transactionId, eventId, correlationId, queueState, queueName, 0, metaData, parallelMetaData, body, typeEnum, subTypeEnum, null, null, 0);
    }

    public BasicQueueListenerRequest(final T body, final PayMeType typeEnum, final PayMeSubType subTypeEnum, final String profileIdValue, final String eventTypeValue) {
        this(null, null, body, typeEnum, subTypeEnum, profileIdValue, eventTypeValue);
    }

    public final void incrementPollingCount() {
        this.pollingCount++;
    }
}
