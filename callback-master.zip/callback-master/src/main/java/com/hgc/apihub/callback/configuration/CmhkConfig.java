package com.hgc.apihub.callback.configuration;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CmhkConfig {
    private String host;
    private String tokenUrl;
    private String appId;
    private String appSecret;
    private String notifyUrl;
}
