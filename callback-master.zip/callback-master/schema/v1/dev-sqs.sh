#!/bin/bash

/home/docker_user/awscli/bin/aws sqs create-queue --queue-name callback-dlq --endpoint-url http://localhost:9324

/home/docker_user/awscli/bin/aws sqs create-queue --queue-name callback-validate --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"callback-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324
/home/docker_user/awscli/bin/aws sqs create-queue --queue-name callback-create --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"callback-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324
/home/docker_user/awscli/bin/aws sqs create-queue --queue-name callback-process --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"callback-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324