# Callback

Hub allows to register notification subscription.