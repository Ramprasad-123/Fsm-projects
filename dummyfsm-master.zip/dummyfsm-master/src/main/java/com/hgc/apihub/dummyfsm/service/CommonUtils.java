package com.hgc.apihub.dummyfsm.service;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Service
public class CommonUtils {
    public static final String DATE_FORMAT_YMD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_YMDHMS = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_ISO8601 = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final ZoneId ZONE_CODE_GMT = ZoneId.of("UTC");                    // GMT
    public static final ZoneId ZONE_CODE_GMT8 = ZoneId.of("Asia/Hong_Kong");        // GMT+8

    public static String getFormattedCurrentDate(String dateFormat) {
        return getFormattedDate(LocalDateTime.now(ZONE_CODE_GMT8), dateFormat);
    }

    public static String getFormattedDate(LocalDateTime date, String dateFormat) {
        if (!StringUtils.isEmpty(date)) return DateTimeFormatter.ofPattern(dateFormat).format(date);
        return null;
    }

    public static String convertStringDateToAnotherFormat(String dateInput, String dateFormatInput, String dateformatOutput) {
        if (StringUtils.isEmpty(dateInput)) return null;
        return LocalDate.parse(dateInput, DateTimeFormatter.ofPattern(dateFormatInput)).format(
                DateTimeFormatter.ofPattern(dateformatOutput)
        );
    }

}
