package com.hgc.apihub.hsbc.payme.model;

import com.hgc.apihub.hsbc.payme.model.dynamodb.PayMeSubTypeConverter;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import java.util.stream.Stream;

public class PayMeSubTypeConverterTest {

    private final PayMeSubTypeConverter converter = new PayMeSubTypeConverter();

    @ParameterizedTest(name = "{0} has an ordinal of {1}.")
    @MethodSource("provideArguments")
    void transformFrom(PayMeSubType enumValue, AttributeValue ordinal) {
        // act
        var value = converter.transformFrom(enumValue);
        // assert
        Assertions.assertEquals(ordinal, value);
    }

    @ParameterizedTest(name = "ordinal {1} is mapped back to {0}.")
    @MethodSource("provideArguments")
    void transformTo(PayMeSubType enumValue, AttributeValue ordinal) {
        // act
        var value = converter.transformTo(ordinal);
        // assert
        Assertions.assertEquals(enumValue, value);
    }

    static Stream<Arguments> provideArguments() {
        return Stream.of(
                Arguments.of(null, null),
                Arguments.of(PayMeSubType.REQUEST, AttributeValue.fromS("REQUEST")),
                Arguments.of(PayMeSubType.STATUS_NOTIFICATION, AttributeValue.fromS("STATUS_NOTIFICATION")),
                Arguments.of(PayMeSubType.CANCEL, AttributeValue.fromS("CANCEL"))
        );
    }
}
