package com.hgc.apihub.hsbc.payme.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import lombok.Getter;

@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PolledRequest implements QueueListenerBody {

    @JsonProperty("transaction_id")
    private final String transactionId;

    @JsonProperty("event_id")
    private final String eventId;

    @JsonProperty("poll_event_id")
    private final String pollEventId;

    public PolledRequest(@JsonProperty("transaction_id") final String transactionIdValue, @JsonProperty("event_id") final String eventIdValue, @JsonProperty("poll_event_id") final String pollEventIdValue) {
        this.transactionId = transactionIdValue;
        this.eventId = eventIdValue;
        this.pollEventId = pollEventIdValue;
    }
}
