package com.hgc.apihub.dummyfsm.service;

import com.hgc.apihub.dummyfsm.model.CurrentTime;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.aws.fsm.model.AWSQueueMessagingTemplate;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.configuration.APIMConfig;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.FSMEntityDao;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.node.StateGraph;
import com.hgc.lib.microservices.statemachine.service.FSMMessagingTemplate;
import com.hgc.lib.microservices.statemachine.service.QueueEntryNodeListener;
import com.hgc.apihub.dummyfsm.controller.DummyFsmController;
import com.hgc.apihub.dummyfsm.model.DummyFsmRequest;
import com.hgc.apihub.dummyfsm.model.DummyFsmResponse;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Getter
@RequiredArgsConstructor
public class DummyFsmService implements QueueEntryNodeListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(DummyFsmService.class);

    private final APIMConfig apimConfig;
    private final AWSStateGraph awsStateGraph;
    private final DynamoDBDao<? extends DynamoDBEntity> dynamoDBDao;
    private final AWSQueueMessagingTemplate queueMessagingTemplate;

    public final Response createDummyFsm(final DummyFsmRequest request) throws Exception {
        return acceptAndProceedNextState(new QueueListenerRequest<>(request), DummyFsmController.class, new DynamoDBEntity());
    }

    public final Response getResponseByTransactionIdAndEventId(final String transactionId, final String eventId) throws Exception {
        return getResponseByTransactionIdAndEventId(transactionId, eventId, DummyFsmResponse.class);
    }

    public final ResponseEntity<CurrentTime> getCurrentTimeResponse() {
        return new ResponseEntity<>(new CurrentTime(CommonUtils.getFormattedCurrentDate(CommonUtils.DATE_FORMAT_YMDHMS)), HttpStatus.OK);
    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }

    @Override
    public final StateGraph getStateGraph() {
        return this.awsStateGraph;
    }

    @Override
    public final FSMEntityDao<? extends FSMEntity> getFSMEntityDao() {
        return this.dynamoDBDao;
    }

    @Override
    public final FSMMessagingTemplate getFSMMessagingTemplate() {
        return this.queueMessagingTemplate;
    }
}
