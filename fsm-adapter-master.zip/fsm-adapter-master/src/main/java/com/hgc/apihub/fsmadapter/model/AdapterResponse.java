package com.hgc.apihub.fsmadapter.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hgc.lib.microservices.model.Response;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
@JsonPropertyOrder({"status", "body"})
@Schema(description = "Adapter response")
public class AdapterResponse extends Response {

    @Schema(description = "Adapter body", requiredMode = Schema.RequiredMode.REQUIRED, example = "test message")
    private final String body;

    @JsonIgnore
    @Schema(hidden = true)
    private String href;

    public AdapterResponse(@JsonProperty("status") final Integer status, @JsonProperty("body") final String bodyValue) {
        super(status);
        this.body = bodyValue;
    }

    public final void setHref(final String hrefValue) {
        this.href = hrefValue;
    }
}
