package com.hgc.apihub.fsmadapter.controller;

import com.hgc.apihub.fsmadapter.exception.AdapterExceptionHandlerType;
import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@WebMvcTest(RedisController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@Import(SanitizedExceptionHandler.class)
public class RedisControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StringRedisTemplate redisTemplate;

    @Test
    void checkCache() throws Throwable {
        // arrange
        BDDMockito.given(redisTemplate.hasKey(Mockito.anyString())).willReturn(true);
        // act
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/redis?cache_key=test"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void checkCacheNotFound() throws Throwable {
        // arrange
        BDDMockito.given(redisTemplate.hasKey(Mockito.anyString())).willReturn(false);
        // act
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/redis?cache_key=test"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.ResourceNotFoundException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.ResourceNotFoundException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.ResourceNotFoundException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.ResourceNotFoundException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
        // arrange
        BDDMockito.given(redisTemplate.hasKey(Mockito.anyString())).willReturn(null);
        // act
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/redis?cache_key=test"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.ResourceNotFoundException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.ResourceNotFoundException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.ResourceNotFoundException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.ResourceNotFoundException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    @Test
    void deleteCache() throws Throwable {
        // arrange
        BDDMockito.given(redisTemplate.delete(Mockito.anyString())).willReturn(true);
        // act
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1/redis?cache_key=test"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void deleteCacheNotFound() throws Throwable {
        // arrange
        BDDMockito.given(redisTemplate.delete(Mockito.anyString())).willReturn(false);
        // act
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1/redis?cache_key=test"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.ResourceNotFoundException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.ResourceNotFoundException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.ResourceNotFoundException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.ResourceNotFoundException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
        // arrange
        BDDMockito.given(redisTemplate.delete(Mockito.anyString())).willReturn(null);
        // act
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1/redis?cache_key=test"))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.ResourceNotFoundException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.ResourceNotFoundException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.ResourceNotFoundException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.ResourceNotFoundException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
}
