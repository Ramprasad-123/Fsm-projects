package com.hgc.apihub.fsmadapter.exception;

import com.hgc.lib.microservices.exception.ExceptionType;
import com.hgc.lib.microservices.model.ErrorResponse;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * List of Admin exception handler types used to construct {@link ErrorResponse}.
 *
 * @author Sooraj Mohanan
 */
public enum AdapterExceptionHandlerType implements ExceptionType {

    QueueDoesNotExistException(
            "ADP-40401",
            "Message Queue Does Not Exist",
            "The queue you are trying to send message to does not exist. Please try again with valid message queue.",
            HttpStatus.NOT_FOUND,
            software.amazon.awssdk.services.sqs.model.QueueDoesNotExistException.class
    ),
    ResourceNotFoundException(
            "ADP-40402",
            "Resource not found",
            "The resource you queried does not exist. Please try again with valid values.",
            HttpStatus.NOT_FOUND,
            com.hgc.lib.core.exception.ResourceNotFoundException.class, software.amazon.awssdk.services.dynamodb.model.ResourceNotFoundException.class
    ),
    MessagingOperationFailedException(
            "ADP-50001",
            "Messaging Operation Failed",
            "The messaging operation you are trying failed. Please try again after some time.",
            HttpStatus.INTERNAL_SERVER_ERROR,
            io.awspring.cloud.sqs.operations.MessagingOperationFailedException.class
    );

    private final String code;
    private final String reason;
    private final String message;
    private final HttpStatus status;
    private final List<Class<? extends Throwable>> exceptionClasses;

    private static final Map<Class<? extends Throwable>, ExceptionType> EXCEPTION_CLASS_MAP = new HashMap<>();

    static {
        Arrays.stream(AdapterExceptionHandlerType.values()).forEach(e -> e.exceptionClasses.forEach(c -> EXCEPTION_CLASS_MAP.put(c, e)));
    }

    @SafeVarargs
    AdapterExceptionHandlerType(final String codeValue, final String reasonValue, final String messageValue, final HttpStatus statusValue,
                                final Class<? extends Throwable>... exceptionClassesValue) {
        this.code = codeValue;
        this.reason = reasonValue;
        this.message = messageValue;
        this.status = statusValue;
        this.exceptionClasses = Arrays.asList(exceptionClassesValue);
    }

    public static ExceptionType fromExceptionClass(final Class<? extends Throwable> exceptionClass) {
        if (exceptionClass == null) {
            return null;
        }
        return EXCEPTION_CLASS_MAP.get(exceptionClass);
    }

    public String getCode() {
        return code;
    }

    public String getReason() {
        return reason;
    }

    public String getMessage() {
        return message;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
