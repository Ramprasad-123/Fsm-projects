package com.hgc.apihub.callback.dao.asfe;

import com.hgc.apihub.graphqlatoms.client.queries.CreateAsNotifyMutation;
import com.hgc.apihub.graphqlatoms.client.queries.UpdateAsNotificationQueueMutation;
import com.hgc.apihub.graphqlatoms.client.type.AsNotificationQueueUpdateInput;
import com.hgc.apihub.graphqlatoms.client.type.AsNotifyInput;
import com.hgc.lib.core.exception.GraphQLMutationException;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.model.FieldErrorMessage;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.function.Supplier;

import static com.hgc.apihub.callback.helper.asfe.AsfeHelper.getError;

@Component
@RequiredArgsConstructor
public class AtomsDao {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(AtomsDao.class);
    public static final String AS_NOTIFY_RECORD_CREATION_FAILED = "as_notify record creation failed";
    public static final String AS_NOTIFY_RECORD_CREATION_SUCCESS = "as_notify record creation success with id:{}";
    public static final String AS_NOTIFICATION_QUEUE_RECORD_UPDATE_FAILED = "as_notification_queue record update failed";
    public static final String AS_NOTIFICATION_QUEUE_RECORD_UPDATED = "as_notification_queue record updated success with status:{}";

    // GraphQL Templates
    private final GraphQLTemplate atomsGraphQLTemplate;

    public FieldErrorMessage createAsNotify(final AsNotifyInput input) throws GraphQLMutationException {
        var mutation = CreateAsNotifyMutation.builder()
                .input(input)
                .withUniqueId(true)
                .build();
        var response = atomsGraphQLTemplate.mutation(mutation);
        if (response.hasErrors()) {
            throw new GraphQLMutationException(getError(response.getErrors()));
        }

        Supplier<GraphQLMutationException> supplier = () -> new GraphQLMutationException(AS_NOTIFY_RECORD_CREATION_FAILED);

        var fields = Optional.ofNullable(response.getData()).stream()
                .flatMap(Optional::stream)
                .map(CreateAsNotifyMutation.Data::getCreateAsNotify)
                .flatMap(Optional::stream)
                .map(CreateAsNotifyMutation.CreateAsNotify::getFragments)
                .map(CreateAsNotifyMutation.CreateAsNotify.Fragments::getAsNotifyFields)
                .findFirst()
                .orElseThrow(supplier);

        var id = fields.getUniqueId();
        if (id.isPresent()) {
            LOGGER.unify(Level.INFO, AS_NOTIFY_RECORD_CREATION_SUCCESS, id.get());
            return null;
        } else {
            return new FieldErrorMessage("500", AS_NOTIFY_RECORD_CREATION_FAILED);
        }
    }

    public FieldErrorMessage updateAsNotificationQueue(final String id, final AsNotificationQueueUpdateInput input) throws GraphQLMutationException {
        var mutation = UpdateAsNotificationQueueMutation.builder()
                .input(input)
                .uniqueId(id)
                .withStatus(true)
                .build();
        var response = atomsGraphQLTemplate.mutation(mutation);
        if (response.hasErrors()) {
            throw new GraphQLMutationException(getError(response.getErrors()));
        }

        Supplier<GraphQLMutationException> supplier = () -> new GraphQLMutationException(AS_NOTIFICATION_QUEUE_RECORD_UPDATE_FAILED);

        var fields = Optional.ofNullable(response.getData()).stream()
                .flatMap(Optional::stream)
                .map(UpdateAsNotificationQueueMutation.Data::getUpdateAsNotificationQueue)
                .flatMap(Optional::stream)
                .map(UpdateAsNotificationQueueMutation.UpdateAsNotificationQueue::getFragments)
                .map(UpdateAsNotificationQueueMutation.UpdateAsNotificationQueue.Fragments::getAsNotificationQueueFields)
                .findFirst()
                .orElseThrow(supplier);

        var status = fields.getStatus();
        if (status.isPresent()) {
            LOGGER.unify(Level.INFO, AS_NOTIFICATION_QUEUE_RECORD_UPDATED, status.get());
            return null;
        } else {
            return new FieldErrorMessage("500", AS_NOTIFICATION_QUEUE_RECORD_UPDATE_FAILED);
        }    }
}
