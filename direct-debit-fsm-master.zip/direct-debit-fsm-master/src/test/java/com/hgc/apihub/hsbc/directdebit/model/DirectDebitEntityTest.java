package com.hgc.apihub.hsbc.directdebit.model;

import com.hgc.apihub.hsbc.directdebit.model.dynamodb.DirectDebitEntity;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static com.hgc.apihub.hsbc.directdebit.DirectDebitTestHelper.getDirectDebitEntity;

class DirectDebitEntityTest {

    @Test
    void mapping() {
        // arrange
        var item = getDirectDebitEntity(DirectDebitType.AUTHORIZATION_INITIATE, State.VALIDATED);
        // assert
        Assertions.assertNotNull(item);
        Assertions.assertNotNull(item.getType());
        Assertions.assertNotNull(item.getReferenceId());
        // arrange
        item = new DirectDebitEntity("ID0000023", DirectDebitType.AUTHORIZATION_INITIATE, State.VALIDATED.name(), SubState.EXITED);
        // assert
        Assertions.assertNotNull(item);
        Assertions.assertNotNull(item.getType());
        Assertions.assertNotNull(item.getReferenceId());
        // arrange
        item = new DirectDebitEntity("ID0000023", DirectDebitType.AUTHORIZATION_INITIATE, "ID0000021");
        // assert
        Assertions.assertNotNull(item);
        Assertions.assertNotNull(item.getType());
        Assertions.assertNotNull(item.getTransactionId());
        Assertions.assertNotNull(item.getReferenceId());
        // arrange
        item = new DirectDebitEntity(DirectDebitType.AUTHORIZATION_INITIATE, "ID0000021");
        // assert
        Assertions.assertNotNull(item);
        Assertions.assertNotNull(item.getType());
        Assertions.assertNotNull(item.getTransactionId());
    }
}
