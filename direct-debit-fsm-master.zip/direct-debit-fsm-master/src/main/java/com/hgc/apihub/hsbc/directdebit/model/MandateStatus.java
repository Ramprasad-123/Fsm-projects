package com.hgc.apihub.hsbc.directdebit.model;

import lombok.Getter;

@Getter
public enum MandateStatus {

    ERROR("Error"),
    ACTIVE("Active"),
    SUSPENDED("Suspended"),
    DORMANT("Dormant"),
    EXPIRED("Expired"),
    CANCELLED("Cancelled via other channels"),
    DELETED("DDA becomes obsolete"),
    PDNG("Pending from Debtor's bank response (DDAE)"),
    PDFP("Pending from Debtor's bank response (EDDA)"),
    PDOU("Pending to debtor accounts with HSBC DDA response");

    private final String description;

    MandateStatus(final String descriptionValue) {
        this.description = descriptionValue;
    }

    public static boolean isPending(final MandateStatus status) {
        return PDNG == status || PDFP == status ||  PDOU == status;
    }
}
