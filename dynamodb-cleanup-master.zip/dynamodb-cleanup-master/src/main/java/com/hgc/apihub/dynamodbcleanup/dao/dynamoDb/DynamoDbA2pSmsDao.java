package com.hgc.apihub.dynamodbcleanup.dao.dynamoDb;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDBLockClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.hgc.apihub.dynamodbcleanup.model.DynamoDbOperationResponse;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

@Primary
@Component
public class DynamoDbA2pSmsDao extends DynamoDBDao<DynamoDbA2pSmsEntity> {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(DynamoDbA2pSmsDao.class);

    @Value("${dynamodb.a2p-table-name}")
    private String tableName;

    public DynamoDbA2pSmsDao(@Value("${dynamodb.a2p-table-name}") final String a2pTableName, @Value("${dynamodb.a2p-lock-table-name}") final String a2pLockTableName, final DynamoDBMapper dynamoDBMapper,
                             final AmazonDynamoDBLockClient amazonDynamoDBLockClient) {
        super(DynamoDbA2pSmsEntity.class, a2pTableName, a2pLockTableName, dynamoDBMapper, amazonDynamoDBLockClient);
    }

    public DynamoDbOperationResponse deleteRecords(final ArrayList<String> transactionIds) {
        Set<FSMEntity> treeSet = new TreeSet<>(Comparator.comparing(FSMEntity::getTransactionId));
        Set<FSMEntity> itemsToDelete = Collections.synchronizedSet(treeSet);
        var response = new DynamoDbOperationResponse(HttpStatus.OK.value(), "");

        if (!CollectionUtils.isEmpty(transactionIds)) {

            // Loop and query by transactionId from DynamoDb.
            var results = this.getByTransactionIdList(transactionIds);
            results.forEach(result -> {
                var item = new DynamoDbTnssIntegrationEntity();
                item.setTransactionId(result.getTransactionId());
                item.setEventId(result.getEventId());
                item.setCreateDate(result.getCreateDate());
                item.setLastUpdateDate(result.getLastUpdateDate());
                itemsToDelete.add(item);
            });

            LOGGER.unify(Level.INFO, "Item count from log table : {}, item count fetched from DynamoDb : {}", transactionIds.size(), results.size());

            DynamoDBMapperConfig.TableNameOverride config = new DynamoDBMapperConfig.TableNameOverride(tableName);
            var dynamoDBMapperConfig = new DynamoDBMapperConfig.Builder().withTableNameOverride(config).build();
            var failedRecords = this.getDynamoDBMapper().batchWrite(Collections.emptyList(), itemsToDelete, dynamoDBMapperConfig);

            if (CollectionUtils.isEmpty(failedRecords)) {
                var message = "Cleanup success, items deleted : " + results.size();
                LOGGER.unify(Level.INFO, message);
                response.setMessage(message);
            } else {
                LOGGER.unify(Level.ERROR, "Cleanup error, items deletion fails, batch size : {}", failedRecords.size());
                LOGGER.unify(Level.ERROR, "Reason : ", failedRecords.stream().findAny().map(DynamoDBMapper.FailedBatch::getException).orElse(null));
                response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                response.setMessage("Cleanup error, items deletion fails, batch size:" + failedRecords.size() + "." + "Reason:" + failedRecords.stream().findAny().map(DynamoDBMapper.FailedBatch::getException).orElse(null));
            }
        } else {
            var message = "There is no item to delete";
            LOGGER.unify(Level.INFO, message);
            response.setMessage(message);
        }
        return response;
    }

    public ArrayList<DynamoDBEntity> getByTransactionIdList(ArrayList<String> transactionIds) {
        var results = new ArrayList<DynamoDBEntity>();
        for (var id : transactionIds) {
            var queryResult = this.getDynamoDBMapper().query(getClazz(), this.queryByTransactionIdList(id), this.tableNameOverride()).stream().findAny();
            queryResult.ifPresentOrElse(results::add, () -> LOGGER.unify(Level.INFO, "Not found for transaction_id:" + id));
        }
        return results;
    }

    public DynamoDBQueryExpression<DynamoDbA2pSmsEntity> queryByTransactionIdList(final String transactionId) {
        return (new DynamoDBQueryExpression<DynamoDbA2pSmsEntity>())
                .withKeyConditionExpression("transaction_id = :transactionId")
                .withExpressionAttributeValues(Map.of(":transactionId", (new AttributeValue()).withS(transactionId)))
                .withProjectionExpression("transaction_id, event_id, create_date");

    }
}
