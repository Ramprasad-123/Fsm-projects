package com.hgc.apihub.dummyfsm.controller;

//TODO sample code, to be removed/updated

import com.hgc.apihub.dummyfsm.model.CurrentTime;
import com.hgc.apihub.dummyfsm.model.DummyFsmRequest;
import com.hgc.apihub.dummyfsm.model.DummyFsmResponse;
import com.hgc.apihub.dummyfsm.service.DummyFsmService;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.statemachine.swagger.AsyncState202Response;
import com.hgc.lib.microservices.statemachine.swagger.ErrorState400Response;
import com.hgc.lib.microservices.swagger.Error400Response;
import com.hgc.lib.microservices.swagger.Error404Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;

import static com.hgc.lib.microservices.MicroservicesHelper.*;

@RestController
@RequestMapping("/v1")
@Validated
@RequiredArgsConstructor
@Api(tags = "Operations pertaining to Dummy fsm")
public class DummyFsmController {

    private static final String API_RESPONSE_CODE_200_SWAGGER_VALUE = "Dummy fsm successfully retrieved";
    private static final String API_RESPONSE_CODE_202_SWAGGER_VALUE = "Create Dummy fsm accepted";
    private static final String API_RESPONSE_CODE_400_SWAGGER_VALUE = "Request/Parameter is invalid";
    private static final String API_RESPONSE_CODE_404_SWAGGER_VALUE = "Dummy fsm not found";
    private static final String API_RESPONSE_CODE_500_SWAGGER_VALUE = "Server/Unknown/Querying error occurred";

    private final DummyFsmService dummyfsmService;

    @ApiOperation(value = "Create a Dummy fsm asynchronous")
    @ApiResponses(
            value = {
                    @ApiResponse(code = API_RESPONSE_CODE_202, message = API_RESPONSE_CODE_202_SWAGGER_VALUE, response = AsyncState202Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_400, message = API_RESPONSE_CODE_400_SWAGGER_VALUE, response = Error400Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_500, message = API_RESPONSE_CODE_500_SWAGGER_VALUE, response = Error500Response.class)
            }
    )
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> createDummyFsm(@Validated @RequestBody final DummyFsmRequest request) throws Exception {
        var response = dummyfsmService.createDummyFsm(request);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }

    @ApiOperation(
            value = "Get a Dummy fsm by transaction ID and event ID"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = API_RESPONSE_CODE_200, message = API_RESPONSE_CODE_200_SWAGGER_VALUE, response = DummyFsmResponse.class),
                    @ApiResponse(code = API_RESPONSE_CODE_202, message = API_RESPONSE_CODE_202_SWAGGER_VALUE, response = AsyncState202Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_400, message = API_RESPONSE_CODE_400_SWAGGER_VALUE, response = ErrorState400Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_404, message = API_RESPONSE_CODE_404_SWAGGER_VALUE, response = Error404Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_500, message = API_RESPONSE_CODE_500_SWAGGER_VALUE, response = Error500Response.class)
            }
    )
    @GetMapping(path = "/transaction/{transaction_id}/event/{event_id}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> getResponseByTransactionIdAndEventId(@ApiParam(value = TRANSACTION_ID_SWAGGER_VALUE, required = true, example = TRANSACTION_ID_SWAGGER_EXAMPLE) @PathVariable("transaction_id") @NotBlank final String transactionId,
                                                                  @ApiParam(value = EVENT_ID_SWAGGER_VALUE, required = true, example = EVENT_ID_SWAGGER_EXAMPLE) @PathVariable("event_id") @NotBlank final String eventId) throws Exception {
        var response = dummyfsmService.getResponseByTransactionIdAndEventId(transactionId, eventId);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }

    @ApiOperation(value = "How soon is now?")
    @ApiResponses(
            value = {
                    @ApiResponse(code = API_RESPONSE_CODE_200, message = API_RESPONSE_CODE_200_SWAGGER_VALUE, response = CurrentTime.class),
            }
    )
    @GetMapping(path = "/syncApi", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<CurrentTime> syncApi() throws Exception {
        return dummyfsmService.getCurrentTimeResponse();
    }
}
