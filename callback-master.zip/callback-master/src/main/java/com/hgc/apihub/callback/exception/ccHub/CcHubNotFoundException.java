package com.hgc.apihub.callback.exception.ccHub;

public class CcHubNotFoundException extends Exception {
    public CcHubNotFoundException(final String message){
        super(message);
    }
}
