package com.hgc.apihub.hsbc.directdebit.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

class DirectDebitTypeTest {

    @ParameterizedTest(name = "{0} has a property of {1}.")
    @MethodSource("provideArguments")
    void testResult(DirectDebitType result, String value, boolean authorizationType) {
        // assert
        Assertions.assertEquals(result, DirectDebitType.fromValue(value));
        if (result != null) {
            Assertions.assertEquals(authorizationType, DirectDebitType.authorizationFSMType(result));
        }
    }

    private static Stream<Arguments> provideArguments() {
        return Stream.of(
                Arguments.of(null, null, false),
                Arguments.of(null, "", false),
                Arguments.of(DirectDebitType.AUTHORIZATION_INITIATE, "AUTHORIZATION_INITIATE", true),
                Arguments.of(DirectDebitType.AUTHORIZATION_OTP_CONFIRMATION, "AUTHORIZATION_OTP_CONFIRMATION", true),
                Arguments.of(DirectDebitType.AUTHORIZATION_OTP_REGENERATION, "AUTHORIZATION_OTP_REGENERATION", true),
                Arguments.of(DirectDebitType.AUTHORIZATION_STATUS, "AUTHORIZATION_STATUS", false),
                Arguments.of(DirectDebitType.REPORTS, "reports", false)
        );
    }

    @Test
    void InvalidVale() {
        // assert
        var thrown = Assertions.assertThrows(IllegalArgumentException.class, () -> DirectDebitType.fromValue("test"));
        Assertions.assertEquals("does not support value test!", thrown.getMessage());
    }
}
