package com.hgc.apihub.callback.service.ccHub;

import com.hgc.apihub.callback.dao.ccHub.CchubDao;
import com.hgc.apihub.callback.exception.ccHub.CcHubDeleteOperationFailException;
import com.hgc.apihub.callback.exception.ccHub.CcHubNotFoundException;
import com.hgc.apihub.callback.exception.ccHub.GraphQLMutationException;
import com.hgc.apihub.callback.model.ccHub.HubRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class HubService {

    private CchubDao cchubDao;

    public final ResponseEntity createHub(String userId, HubRequest hubRequest) throws GraphQLMutationException {
        return new ResponseEntity<>(cchubDao.createHub(userId, hubRequest), HttpStatus.CREATED);
    }

    public final ResponseEntity deleteHub(String hubId) throws GraphQLMutationException, CcHubNotFoundException, CcHubDeleteOperationFailException {
        return new ResponseEntity<>(cchubDao.deleteHub(hubId), HttpStatus.NO_CONTENT);
    }

    public ResponseEntity getHubList(Integer page, Integer size) throws GraphQLMutationException {
        return new ResponseEntity<>(cchubDao.getHubList(page, size), HttpStatus.OK);
    }
}
