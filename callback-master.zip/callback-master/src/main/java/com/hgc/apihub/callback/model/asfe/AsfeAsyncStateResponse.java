package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import lombok.Generated;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Generated
@Getter
@Setter
@JsonPropertyOrder({"status", "reference_no", "order_action", "transaction_id", "event_id", "state", "create_date", "last_update_date", "links"})
public class AsfeAsyncStateResponse extends AsyncStateResponse {

    @JsonProperty("remaining_sub_types")
    private List<SubType> remainingSubTypes;

    @lombok.Builder(builderMethodName = "childBuilder")
    public AsfeAsyncStateResponse(@JsonProperty("status") final Integer status,
                                  @JsonProperty("transaction_id") final String transactionId, @JsonProperty("event_id") final String eventId, @JsonProperty("state") final String state, @JsonProperty("create_date") final String createDate,
                                  @JsonProperty("last_update_date") final String lastUpdateDate, @JsonProperty("links") final List<Link> links, @JsonProperty("remaining_sub_types") final List<SubType> remainingSubTypesValue) {
        super(status, transactionId, eventId, state, createDate, lastUpdateDate, links);
        remainingSubTypes = remainingSubTypesValue;
    }
}
