package com.hgc.apihub.fsmadapter.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;

@Getter
@Schema(description = "Message request body")
public class MessageRequest {

    @NotNull
    @Schema(description = "Message body", requiredMode = Schema.RequiredMode.REQUIRED, example = "test message")
    private final String body;

    @NotBlank
    @JsonProperty("queue_name")
    @Schema(description = "Messaging queue name", requiredMode = Schema.RequiredMode.REQUIRED, example = "test queue")
    private final String queueName;

    public MessageRequest(@JsonProperty("body") final String bodyValue, @JsonProperty("queue_name") final String queueNameValue) {
        this.body = bodyValue;
        this.queueName = queueNameValue;
    }
}
