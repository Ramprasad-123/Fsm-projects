# HSBC PayMe FSM library

Library which contains common functions for HSBC PayMe FSM to consume.

## Getting Started

For understanding the project source code, the following knowledge will be helpful in no particular order:
* Java
* Maven
* Spring Framework
* AWS SQS
* AWS DynamoDB
* Git

The list above is not an exhaustive list.

### Prerequisites

* [Git](https://git-scm.com/) is installed. Required for checking out the source code.
* [JDK 21](https://jdk.java.net/21/) is installed. Required for development and running the project.

### Installing

To obtain a local copy of the master branch of the repository, you can run the following command.
```
git clone git@gitlab.hk:hgc/hgc-groups/hgc-global-communications/api-hub/hsbc/payme-fsm.git
```

## Usage

## Built With

* [JDK 21](https://jdk.java.net/18/) - The core project built on JVM
* [Maven](https://maven.apache.org/) - Dependency Management
    * [Maven Wrapper](https://maven.apache.org/wrapper/) is also included in the project

## Authors

* **Sooraj Mohanan** - [\<Sooraj.Mohanan@hgc.com.hk\>](mailto:Sooraj.Mohanan@hgc.com.hk)

## Copyright

Copyright &copy; 2018, [HGC Global Communications Limited](http://www.hgc.com.hk/Home/Index-en.html).
All rights reserved.