package com.hgc.apihub.fsmadapter.service;

import com.hgc.apihub.fsmadapter.controller.MessageController;
import com.hgc.apihub.fsmadapter.model.InitiateMessageRequest;
import com.hgc.apihub.fsmadapter.model.MessageRequest;
import com.hgc.apihub.fsmadapter.model.AdapterResponse;
import com.hgc.apihub.fsmadapter.model.dynamodb.AdapterDynamoDBDao;
import com.hgc.lib.core.exception.ResourceNotFoundException;
import com.hgc.lib.microservices.aws.fsm.model.AWSQueueMessagingTemplate;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.configuration.APIMConfig;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.statemachine.deliver.model.DeliverType;
import com.hgc.lib.microservices.statemachine.model.*;
import com.hgc.lib.microservices.statemachine.service.QueueListener;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Optional;

import static com.hgc.apihub.fsmadapter.AdapterHelper.RECORD_EXPIRATION_DAY;
import static com.hgc.lib.core.HGCHelper.randomUUID;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
@RequiredArgsConstructor
public class MessageService {

    public static final Configuration JSON_PATH_CONFIG = Configuration.defaultConfiguration().addOptions(Option.DEFAULT_PATH_LEAF_TO_NULL);

    private final APIMConfig apimConfig;
    private final AdapterDynamoDBDao adapterDynamoDBDao;
    private final AWSQueueMessagingTemplate queueMessagingTemplate;

    public final Response sendMessage(final MessageRequest request) throws Throwable {
        queueMessagingTemplate.convertAndSend(request.getQueueName(), request.getBody());
        return new Response(HttpStatus.OK);
    }

    public final Response initiateMessage(final InitiateMessageRequest request) throws Exception {
        queueMessagingTemplate.validateQueue(request.getQueueName());
        var item = new DynamoDBEntity();
        item.setTransactionId(randomUUID());
        item.setEventId(randomUUID());
        item.setCorrelationId(randomUUID());
        var listenerRequest = QueueListenerRequest.builder()
                .transactionId(item.getTransactionId())
                .eventId(item.getEventId())
                .correlationId(item.getCorrelationId())
                .queueState(State.ACCEPTED.name())
                .queueName(request.getQueueName())
                .body(new DeliveredRequest(request.getBody()))
                .build();
        var buildAcceptedRequestBuilder = FSMEntityRequest.BuildAccepted.builder()
                .item(item)
                .recordExpirationDay(RECORD_EXPIRATION_DAY);
        if (StringUtils.hasText(request.getCallbackUrl())) {
            buildAcceptedRequestBuilder.deliverType(DeliverType.CALLBACK)
                    .callbackUrl(request.getCallbackUrl())
                    .callbackAuthType(request.getCallbackAuthType())
                    .callbackAuthSecret(request.getCallbackAuthSecret());
        }
        if (StringUtils.hasText(request.getSelfLink())) {
            buildAcceptedRequestBuilder.selfLink(Link.withSelfRelation(request.getSelfLink()))
                    .updateSelfLinkWithIds(true);
        }
        var buildAcceptedRequest = buildAcceptedRequestBuilder.build();
        FSMEntity.buildAccepted(buildAcceptedRequest);
        adapterDynamoDBDao.save(item, request.getTableName());
        queueMessagingTemplate.convertAndSend(request.getQueueName(), listenerRequest);
        var asyncResponse = buildAcceptedRequest.getResponse();
        var response = new AdapterResponse(asyncResponse.getStatus(), OBJECT_MAPPER.writeValueAsString(asyncResponse));
        response.setHref(this.href(listenerRequest.getTransactionId(), listenerRequest.getEventId(), request.getTableName(), request.getRetryAfter()));
        return response;
    }

    public final Response getByTransactionIdAndEventId(final String transactionId, final String eventId, final String tableName, final Integer retryAfter) {
        var item = Optional.ofNullable(adapterDynamoDBDao.getByTransactionIdAndEventId(transactionId, eventId, tableName)).orElseThrow(() -> ResourceNotFoundException.withInvalidId("[" + QueueListener.joinKeys(transactionId, eventId) + "]"));
        var data = item.getData();
        var json = JsonPath.using(JSON_PATH_CONFIG).parse(data);
        var status = json.read("@.status", Integer.class);
        var response = new AdapterResponse(status, data);
        response.setHref(this.href(transactionId, eventId, tableName, retryAfter));
        return response;
    }

    private String href(final String transactionId, final String eventId, final String tableName, final int retryAfter) {
        return WebMvcLinkBuilder.linkTo(MessageController.class).toUriComponentsBuilder()
                .scheme(apimConfig.scheme())
                .host(apimConfig.host())
                .port(apimConfig.port())
                .path("/transaction/{transaction_id}/event/{event_id}?table_name={table_name}&retry_after={retry_after}")
                .buildAndExpand(transactionId, eventId, tableName, retryAfter)
                .toUriString();
    }
}
