package com.hgc.apihub.callback.listener;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.apihub.callback.AsfeTestHelper;
import com.hgc.apihub.callback.model.asfe.BasicQueueListenerRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.lib.microservices.aws.fsm.common.AWSQueueListenerTest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayDeque;
import java.util.List;
import java.util.stream.Stream;

import static com.hgc.apihub.callback.AsfeTestHelper.getAsfeAsyncResponse;
import static com.hgc.apihub.callback.AsfeTestHelper.getFsmEntity;
import static com.hgc.apihub.callback.AsfeTestHelper.getProcessScheduledMaintenanceStartRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getQueueListenerRequest;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@ExtendWith(SpringExtension.class)
class ProcessedListenerTest extends AWSQueueListenerTest {

    private ProcessedListener listener;

    @Override
    protected AWSStateGraph constructStateGraph() {
        return AsfeTestHelper.constructStateGraph();
    }

    @BeforeEach
    void setup() throws Exception {
        this.init();
        listener = new ProcessedListener();
        this.setDependencies(listener, State.PROCESSED.name());
    }

    @Test
    void deserializeDataTest() throws Exception {
        // arrange
        var item = getFsmEntity(State.PROCESSED);
        // act
        var data = listener.deserializeData(item);
        // assert
        Assertions.assertNotNull(data);
    }

    private static Stream<Arguments> testArgumentProvider() {
        return Stream.of(
                Arguments.of(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE)),
                Arguments.of(getQueueListenerRequest(AsFeAction.OUTAGE_START)),
                Arguments.of(getQueueListenerRequest(AsFeAction.OUTAGE_END))
        );
    }

    @MethodSource("testArgumentProvider")
    @ParameterizedTest
    void deserializeBodyTest(final QueueListenerRequest<?> queueListenerRequest) throws Exception {
        // arrange
        var bodyJson = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(queueListenerRequest);
        // act
        var statData = listener.deserializeBody(bodyJson);
        // assert
        Assertions.assertNotNull(statData);
        Assertions.assertNotNull(statData.getBody());
    }

    private void mockHelperForCreateScheduledMaintenanceTest() {
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) throws JsonProcessingException {
                var data = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(getAsfeAsyncResponse());
                return new DynamoDBEntity("TRAN001", "EVEN002", State.PROCESSED.name(), SubState.ENTERED, data, null, null);
            }
        };
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).thenAnswer(answer);
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceTest() throws Exception {
        //
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        mockHelperForCreateScheduledMaintenanceTest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY)))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());

        Assertions.assertEquals(State.PROCESSED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());
    }
}