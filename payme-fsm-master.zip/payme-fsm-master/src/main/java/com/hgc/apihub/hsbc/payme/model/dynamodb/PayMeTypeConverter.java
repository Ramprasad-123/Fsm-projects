package com.hgc.apihub.hsbc.payme.model.dynamodb;

import com.hgc.apihub.hsbc.payme.model.PayMeType;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public class PayMeTypeConverter implements AttributeConverter<PayMeType> {

    @Override
    public final EnhancedType<PayMeType> type() {
        return EnhancedType.of(PayMeType.class);
    }

    @Override
    public final AttributeValueType attributeValueType() {
        return AttributeValueType.S;
    }

    @Override
    public final AttributeValue transformFrom(final PayMeType input) {
        if (input != null) {
            return AttributeValue.fromS(input.name());
        }
        return null;
    }

    @Override
    public final PayMeType transformTo(final AttributeValue input) {
        if (input != null) {
            return PayMeType.valueOf(input.s());
        }
        return null;
    }
}
