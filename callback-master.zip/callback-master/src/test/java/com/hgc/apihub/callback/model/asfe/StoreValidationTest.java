package com.hgc.apihub.callback.model.asfe;

import com.hgc.lib.microservices.common.validation.BlankValidationTest;

import java.util.List;

import static com.hgc.apihub.callback.AsfeTestHelper.getStore;
import static com.hgc.apihub.callback.AsfeTestHelper.getStoreViolateNotBlanks;

class StoreValidationTest implements BlankValidationTest<BasicAsFeRequest.Store> {

    @Override
    public List<BasicAsFeRequest.Store> blankInstances() {
        return List.of(getStoreViolateNotBlanks());
    }

    @Override
    public List<Integer> numberOfNonBlankAnnotations() {
        return List.of(4);
    }

    @Override
    public BasicAsFeRequest.Store validInstance() {
        return getStore();
    }
}