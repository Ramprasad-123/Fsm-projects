package com.hgc.apihub.callback.controller.asfe;

import com.hgc.apihub.callback.listener.AcceptedListener;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.ScheduledMaintenanceRequest;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.statemachine.swagger.AsyncState202Response;
import com.hgc.lib.microservices.statemachine.swagger.ErrorState400Response;
import com.hgc.lib.microservices.swagger.Error400Response;
import com.hgc.lib.microservices.swagger.Error404Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;

import static com.hgc.lib.microservices.MicroservicesHelper.*;

@RestController
@RequestMapping("/v1/asfe/scheduledMaintenance")
@Validated
@RequiredArgsConstructor
@Tag(name = "Scheduled Maintenance Controller", description = "Operations pertaining to Scheduled Maintenance")
public class ScheduledMaintenanceController {

    private final AcceptedListener acceptedListener;

    @Operation(
            summary = "Create scheduled maintenance",
            description = "Create scheduled maintenance asynchronous"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_202,
                            description = API_RESPONSE_CODE_202_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AsyncState202Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> createScheduledMaintenance(@Validated @RequestBody final ScheduledMaintenanceRequest request) throws Exception {
        var response = acceptedListener.createScheduledMaintenance(request);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }

    @Operation(
            summary = "Get Scheduled Maintenance",
            description = "Get Scheduled Maintenance by transaction ID and event ID"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_200,
                            description = API_RESPONSE_CODE_200_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AsfeAsyncStateResponse.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_202,
                            description = API_RESPONSE_CODE_202_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AsyncState202Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_400,
                            description = API_RESPONSE_CODE_400_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorState400Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_404,
                            description = API_RESPONSE_CODE_404_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error404Response.class))
                    ),
                    @ApiResponse(
                            responseCode = API_RESPONSE_CODE_500,
                            description = API_RESPONSE_CODE_500_SWAGGER_VALUE,
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Error500Response.class))
                    )
            }
    )
    @GetMapping(path = "transaction/{transaction_id}/event/{event_id}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> getResponseByTransactionIdAndEventId(@Parameter(description = TRANSACTION_ID_SWAGGER_VALUE, required = true, example = TRANSACTION_ID_SWAGGER_EXAMPLE) @PathVariable("transaction_id") @NotBlank final String
                                                                          transactionId,
                                                                  @Parameter(description = EVENT_ID_SWAGGER_VALUE, required = true, example = EVENT_ID_SWAGGER_EXAMPLE) @PathVariable("event_id") @NotBlank final String eventId) throws Exception {
        var response = acceptedListener.getResponseByTransactionIdAndEventId(transactionId, eventId);
        return new ResponseEntity<>(response, response.getHttpStatus());
    }
}
