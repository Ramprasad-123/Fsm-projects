package com.hgc.apihub.dummyfsm.swagger;

import com.hgc.lib.microservices.swagger.AbstractSwaggerConfig;
import org.springframework.context.annotation.Configuration;

import java.util.function.Predicate;

import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
public class SwaggerConfig extends AbstractSwaggerConfig  {

    @Override
    public final String apiGroupName() {
        return "dummy-fsm-v1";
    }

    @Override
    public final String apiBasePackage() {
        return "com.hgc.apihub.dummyfsm.controller";
    }

    @Override
    public final Predicate<String> apiPaths() {
        return regex("/dummyfsm/v1.*");
    }

    @Override
    public final String apiInfoDescription() {
        return "Test service build on spring boot for HGC";
    }
}
