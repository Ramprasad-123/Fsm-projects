package com.hgc.apihub.callback.service.asfe;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.apihub.callback.configuration.CmhkConfig;
import com.hgc.apihub.callback.exception.asfe.CmhkTokenException;
import com.hgc.apihub.callback.model.asfe.CmhkAuthRequest;
import com.hgc.apihub.callback.model.asfe.CmhkTokenResponse;
import com.hgc.lib.logging.LoggerWrapper;
import lombok.Getter;
import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestOperations;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Component
@Getter
@Scope("singleton")
public class CmhkAuthService {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(CmhkAuthService.class);

    private final RestOperations restOperations;
    private final CmhkConfig cmhkConfig;

    private Long lastReset = getCurrentTimeSeconds();
    private String currentActiveToken = "";
    private Integer expiresIn = 0;

    public CmhkAuthService(@Qualifier("basicRestOperations") RestOperations restOperations, CmhkConfig cmhkConfig) {
        this.restOperations = restOperations;
        this.cmhkConfig = cmhkConfig;
    }

    private Long getCurrentTimeSeconds() {
        return TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
    }

    public final synchronized String getToken() throws CmhkTokenException {
        final long timePassed = getCurrentTimeSeconds() - lastReset;
        if (timePassed >= expiresIn) {
            LOGGER.unify(Level.DEBUG, "Access token has expired or not generated yet! Generating new one...");
            this.lastReset = getCurrentTimeSeconds();
            String getTokenUrl = cmhkConfig.getHost() + cmhkConfig.getTokenUrl();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            var payload = new CmhkAuthRequest(cmhkConfig.getAppId(), cmhkConfig.getAppSecret());
            HttpEntity<?> httpEntity = new HttpEntity<>(payload, headers);
            LOGGER.unify(Level.INFO, "Get CMHK Token request: url = {}", cmhkConfig.getTokenUrl());

            String token;
            try {
                var responseEntity = restOperations.exchange(getTokenUrl, HttpMethod.POST, httpEntity, String.class);
                LOGGER.unify(Level.DEBUG, "=== responseEntity = " + responseEntity);
                if (responseEntity.getStatusCode().is2xxSuccessful()) {
                    Optional<CmhkTokenResponse> body = Optional.ofNullable(OBJECT_MAPPER.readValue(responseEntity.getBody(), new TypeReference<>() {
                    }));
                    if (body.isPresent()) {
                        token = body.get().getAccessToken();
                        this.currentActiveToken = token;
                        this.expiresIn = StringUtils.hasLength(body.get().getExpiresIn()) ? Integer.parseInt(body.get().getExpiresIn()) : 0;
                    } else {
                        throw new CmhkTokenException("Response body not present.");
                    }
                } else {
                    LOGGER.unify(Level.INFO, "CMHK get token failed, status code = {}", responseEntity.getStatusCode());
                    throw new CmhkTokenException("CMHK get token failed.");
                }
            } catch (Exception ex) {
                LOGGER.unify(Level.INFO, "CMHK get token failed:{}", ex.getMessage());
                throw new CmhkTokenException(ex.getMessage());
            }
            LOGGER.unify(Level.DEBUG, "=== Token = " + token);
            LOGGER.unify(Level.INFO, "Using newly generated token, expires in : {} sec", expiresIn);
            return token;
        } else {
            LOGGER.unify(Level.DEBUG, "=== Token = " + currentActiveToken);
            LOGGER.unify(Level.INFO, "Using generated token, expires in : {} sec", expiresIn - timePassed);
            return currentActiveToken;
        }
    }
}
