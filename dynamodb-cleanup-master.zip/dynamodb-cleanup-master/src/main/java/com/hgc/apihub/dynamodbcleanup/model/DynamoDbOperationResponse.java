package com.hgc.apihub.dynamodbcleanup.model;

//TODO sample code, to be removed

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hgc.lib.microservices.model.Response;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonPropertyOrder({"status", "message"})
@ApiModel(description = "Response body")
public class DynamoDbOperationResponse extends Response {

    @JsonProperty("message")
    @ApiModelProperty(notes = "message", position = 2)
    private String message;

    public DynamoDbOperationResponse(@JsonProperty("status") final Integer status, @JsonProperty("message") final String message) {
        super(status);
        this.message = message;
    }
}
