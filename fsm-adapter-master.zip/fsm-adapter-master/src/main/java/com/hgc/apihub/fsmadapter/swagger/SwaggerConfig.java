package com.hgc.apihub.fsmadapter.swagger;

import com.hgc.lib.microservices.swagger.AbstractSwaggerConfig;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig extends AbstractSwaggerConfig  {

    @Bean
    public GroupedOpenApi publicApi() {
        // optional if needed to group and filter by paths or package or both or none
        return GroupedOpenApi.builder()
                .group("fsm-adapter-v1")
                .packagesToScan("com.hgc.apihub.fsmadapter.controller")
                .addOpenApiCustomizer(this.openApiCustomizer())
                .build();
    }

    @Override
    public final String apiInfoDescription() {
        return "Microservice build on spring boot to act as a FSM adapter";
    }
}
