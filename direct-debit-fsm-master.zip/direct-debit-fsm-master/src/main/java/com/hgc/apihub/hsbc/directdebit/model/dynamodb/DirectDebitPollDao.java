package com.hgc.apihub.hsbc.directdebit.model.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBPollDao;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DirectDebitPollDao extends HGCDynamoDBPollDao<DirectDebitPollEntity> {

    public DirectDebitPollDao(@Value("${fsm.poll.table-name:}") final String entityName, final DynamoDBMapper dynamoDBMapper) {
        super(DirectDebitPollEntity.class, entityName, dynamoDBMapper);
    }
}
