package com.hgc.apihub.dynamodbcleanup.configuration;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GraphQLTnssFbiConfig {

    private String url;
    private int connectTimeout;
    private int readTimeout;
    private int writeTimeout;
}
