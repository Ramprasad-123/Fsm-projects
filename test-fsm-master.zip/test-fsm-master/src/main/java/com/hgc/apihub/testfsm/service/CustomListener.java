package com.hgc.apihub.testfsm.service;

//TODO sample code, to be removed/updated

import com.hgc.apihub.testfsm.model.TestFsmRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.service.AbstractAWSQueueListener;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.StateData;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import org.apache.logging.log4j.Level;
import org.springframework.cloud.aws.messaging.listener.Acknowledgment;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
public class CustomListener extends AbstractAWSQueueListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(CustomListener.class);

    @SqsListener(value = "${aws.queue.name.CUSTOM}", deletionPolicy = SqsMessageDeletionPolicy.NEVER)
    public final void listener(final String request, final Acknowledgment acknowledgment, @Headers final MessageHeaders headers) throws Exception {
        this.listener(this.buildListenerRequest(request, "CUSTOM", headers), acknowledgment);
    }

    @Override
    public final StateData deserializeData(final FSMEntity item) throws Exception {
        if (StringUtils.hasText(item.getData())) {
            return OBJECT_MAPPER.readValue(item.getData(), AsyncStateResponse.class);
        }
        return null;
    }

    @Override
    public final QueueListenerRequest<? extends QueueListenerBody> deserializeBody(final String body) throws Exception {
        return OBJECT_MAPPER.readValue(body, new TypeReference<QueueListenerRequest<TestFsmRequest>>() {
        });
    }

    @Override
    public final void executeClean(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) throws Exception {
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "inside custom execute clean...");
    }

    @Override
    public final void executeDirty(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) throws Exception {
        // do nothing
    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }

}
