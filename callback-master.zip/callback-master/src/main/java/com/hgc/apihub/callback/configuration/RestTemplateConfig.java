package com.hgc.apihub.callback.configuration;


import com.hgc.lib.graphql.client.GraphQLTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class RestTemplateConfig {

    @Autowired
    private BuildProperties buildProperties;

    @Bean
    public GraphQLTemplate graphQlCcTemplate(final GraphqlCcConfig graphqlCcConfig) {
        return GraphQLTemplate.builder()
                .serverUrl(graphqlCcConfig.getUrl())
                .connectTimeout(Duration.ofSeconds(graphqlCcConfig.getConnectTimeout()))
                .readTimeout(Duration.ofSeconds(graphqlCcConfig.getReadTimeout()))
                .writeTimeout(Duration.ofSeconds(graphqlCcConfig.getWriteTimeout()))
                .referer(buildProperties.getArtifact() + ":" + buildProperties.getVersion())
                .build();
    }

    @Bean
    public GraphQLTemplate atomsGraphQLTemplate(final AtomsGraphQLConfig atomsGraphQLConfig) {
        return GraphQLTemplate.builder()
                .serverUrl(atomsGraphQLConfig.getUrl())
                .connectTimeout(Duration.ofSeconds(atomsGraphQLConfig.getConnectTimeout()))
                .readTimeout(Duration.ofSeconds(atomsGraphQLConfig.getReadTimeout()))
                .writeTimeout(Duration.ofSeconds(atomsGraphQLConfig.getWriteTimeout()))
                .referer(buildProperties.getArtifact() + ":" + buildProperties.getVersion())
                .build();
    }
}
