package com.hgc.apihub.fsmadapter.service;

import com.hgc.apihub.fsmadapter.model.DynamoDBRequest;
import com.hgc.apihub.fsmadapter.model.dynamodb.AdapterDynamoDBDao;
import com.hgc.lib.microservices.model.Response;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DynamoDBService {

    private final AdapterDynamoDBDao adapterDynamoDBDao;

    public final Response patchDynamoDB(final DynamoDBRequest request) {
        adapterDynamoDBDao.updateAttributesByTransactionIdAndEventId(request.transactionId(), request.eventId(), request.tableName(), request.attributes());
        return new Response(HttpStatus.OK);
    }
}
