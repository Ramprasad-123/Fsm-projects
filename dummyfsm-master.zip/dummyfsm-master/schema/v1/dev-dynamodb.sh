#!/bin/bash

~/.local/bin/aws dynamodb create-table --table-name dummy_fsm_lock --attribute-definitions AttributeName=key,AttributeType=S --key-schema AttributeName=key,KeyType=HASH --provisioned-throughput ReadCapacityUnits=20,WriteCapacityUnits=20 --endpoint-url http://localhost:8000

~/.local/bin/aws dynamodb create-table --table-name dummy_fsm --attribute-definitions AttributeName=transaction_id,AttributeType=S AttributeName=event_id,AttributeType=S --key-schema AttributeName=transaction_id,KeyType=HASH AttributeName=event_id,KeyType=RANGE --provisioned-throughput ReadCapacityUnits=20,WriteCapacityUnits=20 --endpoint-url http://localhost:8000

~/.local/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "dummy-fsm"}, "state": {"S": "ACCEPTED"}, "entry_node": {"BOOL": true}}' --endpoint-url http://localhost:8000
~/.local/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "dummy-fsm"}, "state": {"S": "VALIDATED"}, "sqs_name": {"S": "dummy-fsm-validate"}, "sqs_dlq_name": {"S": "dummy-fsm-dlq"}}' --endpoint-url http://localhost:8000
~/.local/bin/aws dynamodb put-item --table-name state_node --item '{"project_name": {"S": "dummy-fsm"}, "state": {"S": "PROCESSED"}, "sqs_name": {"S": "dummy-fsm-process"}, "sqs_dlq_name": {"S": "dummy-fsm-dlq"}}' --endpoint-url http://localhost:8000

~/.local/bin/aws dynamodb put-item --table-name state_edge --item '{"project_name": {"S": "dummy-fsm"}, "state": {"S": "ACCEPTED"}, "to_states": {"S": "VALIDATED"}}' --endpoint-url http://localhost:8000
~/.local/bin/aws dynamodb put-item --table-name state_edge --item '{"project_name": {"S": "dummy-fsm"}, "state": {"S": "VALIDATED"}, "to_states": {"S": "PROCESSED"}, "weights": {"S": "[{\"expression\":\"return success\",\"bindings\":{\"success\":true}}]"}}' --endpoint-url http://localhost:8000


#### Useful  commands --------------------------------------
# List all tables in Dynamodb tables
~/.local/bin/aws dynamodb list-tables --endpoint-url http://localhost:8000

# Describe tables
 ~/.local/bin/aws dynamodb describe-table --table-name state_node  --endpoint-url http://localhost:8000
 ~/.local/bin/aws dynamodb describe-table --table-name state_edge  --endpoint-url http://localhost:8000

# Get all items in a DynamoDb tables
~/.local/bin/aws dynamodb scan  --table-name state_node  --endpoint-url http://localhost:8000
~/.local/bin/aws dynamodb scan  --table-name state_edge  --endpoint-url http://localhost:8000

~/.local/bin/aws dynamodb scan  --table-name dummy_fsm  --endpoint-url http://localhost:8000 | less
~/.local/bin/aws dynamodb scan  --table-name dummy_fsm_lock  --endpoint-url http://localhost:8000

# Delete table
~/.local/bin/aws dynamodb delete-table --table-name dummy_fsm --endpoint-url http://localhost:8000
~/.local/bin/aws dynamodb delete-table --table-name dummy_fsm_lock --endpoint-url http://localhost:8000


# Get values by sorting key
~/.local/bin/aws dynamodb query --table-name state_node --key-condition-expression "project_name = :project_name" --expression-attribute-values  '{":project_name":{"S":"dummy-fsm"}}' --endpoint-url http://localhost:8000
~/.local/bin/aws dynamodb query --table-name state_edge --key-condition-expression "project_name = :project_name" --expression-attribute-values  '{":project_name":{"S":"dummy-fsm"}}' --endpoint-url http://localhost:8000

~/.local/bin/aws dynamodb query --table-name dummy_fsm --key-condition-expression "transaction_id = :transaction_id" --expression-attribute-values  '{":transaction_id":{"S":"2c92c0f873ed57b00173f57e8ae154bc"}}' --endpoint-url http://localhost:8000


# delete  values by sorting key
~/.local/bin/aws dynamodb delete-item --table-name state_edge --key '{"project_name": {"S": "dummy-fsm"},  "state": {"S": "VALIDATED"}}' --endpoint-url http://localhost:8000