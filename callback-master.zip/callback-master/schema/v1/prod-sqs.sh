#!/bin/bash

aws sqs create-queue --queue-name pubsub-a3p-callback-dlq

aws sqs create-queue --queue-name pubsub-a3p-callback-validate --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"callback-dlq\",\"maxReceiveCount\":\"5\"}"}'
aws sqs create-queue --queue-name pubsub-a3p-callback-create --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"callback-dlq\",\"maxReceiveCount\":\"5\"}"}'
aws sqs create-queue --queue-name pubsub-a3p-callback-process --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"callback-dlq\",\"maxReceiveCount\":\"5\"}"}'
