package com.hgc.apihub.fsmadapter.service;

import com.hgc.apihub.fsmadapter.model.dynamodb.AdapterDynamoDBDao;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.hgc.apihub.fsmadapter.AdapterTestHelper.getDynamoDBRequest;

@ExtendWith(SpringExtension.class)
class DynamoDBServiceTest {

    @MockBean
    private AdapterDynamoDBDao adapterDynamoDBDao;

    private DynamoDBService dynamoDBService;

    @BeforeEach
    void setup() {
        dynamoDBService = new DynamoDBService(adapterDynamoDBDao);
    }

    @Test
    void patchDynamoDB() {
        // act
        var response = dynamoDBService.patchDynamoDB(getDynamoDBRequest());
        // assert
        Assertions.assertNotNull(response);
        Assertions.assertEquals(200, response.getStatus());
    }
}
