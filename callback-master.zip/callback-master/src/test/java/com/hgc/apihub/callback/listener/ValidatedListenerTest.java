package com.hgc.apihub.callback.listener;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.apihub.callback.AsfeTestHelper;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.BasicQueueListenerRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageEndRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageStartRequest;
import com.hgc.apihub.callback.model.asfe.ProcessScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.lib.microservices.aws.fsm.common.AWSQueueListenerTest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.statemachine.exception.MessageNotSupportedException;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayDeque;
import java.util.List;
import java.util.stream.Stream;

import static com.hgc.apihub.callback.AsfeTestHelper.getAsfeAsyncResponse;
import static com.hgc.apihub.callback.AsfeTestHelper.getFsmEntity;
import static com.hgc.apihub.callback.AsfeTestHelper.getProcessOutageEndRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getProcessOutageStartRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getProcessScheduledMaintenanceStartRequest;
import static com.hgc.apihub.callback.AsfeTestHelper.getQueueListenerRequest;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@ExtendWith(SpringExtension.class)
class ValidatedListenerTest extends AWSQueueListenerTest {

    private ValidatedListener listener;

    @Override
    protected AWSStateGraph constructStateGraph() {
        return AsfeTestHelper.constructStateGraph();
    }

    @BeforeEach
    void setup() throws Exception {
        this.init();
        listener = new ValidatedListener();
        this.setDependencies(listener, State.VALIDATED.name());
    }

    @Test
    void deserializeDataTest() throws Exception {
        // arrange
        var item = getFsmEntity(State.VALIDATED);
        // act
        var data = listener.deserializeData(item);
        // assert
        Assertions.assertNotNull(data);
    }

    private static Stream<Arguments> testArgumentProvider() {
        return Stream.of(
                Arguments.of(getQueueListenerRequest(AsFeAction.SCHEDULED_MAINTENANCE)),
                Arguments.of(getQueueListenerRequest(AsFeAction.OUTAGE_START)),
                Arguments.of(getQueueListenerRequest(AsFeAction.OUTAGE_END))
        );
    }

    @MethodSource("testArgumentProvider")
    @ParameterizedTest
    void deserializeBodyTest(final QueueListenerRequest<?> queueListenerRequest) throws Exception {
        // arrange
        var bodyJson = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(queueListenerRequest);
        // act
        var statData = listener.deserializeBody(bodyJson);
        // assert
        Assertions.assertNotNull(statData);
        Assertions.assertNotNull(statData.getBody());
    }

    @Test
    void messageNotSupportedCheckTest() throws Exception {
        // arrange
        // act
        // assert
        Assertions.assertThrows(MessageNotSupportedException.class, () -> listener.messageSupportedCheck(AsFeAction.SCHEDULED_MAINTENANCE, List.of(AsFeAction.OUTAGE_START, AsFeAction.OUTAGE_END)));
        Assertions.assertDoesNotThrow(() -> listener.messageSupportedCheck(null, List.of(AsFeAction.OUTAGE_START, AsFeAction.OUTAGE_END)));
        Assertions.assertDoesNotThrow(() -> listener.messageSupportedCheck(AsFeAction.OUTAGE_START, List.of()));
    }

    private void mockHelperForCreateScheduledMaintenanceTest() {
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) throws JsonProcessingException {
                var data = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(getAsfeAsyncResponse());
                return new DynamoDBEntity("TRAN001", "EVEN002", State.VALIDATED.name(), SubState.ENTERED, data, null, null);
            }
        };
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).thenAnswer(answer);
    }

    private void mockHelperForOutageTest(final List<SubType> subTypes) {
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) throws JsonProcessingException {
                var data = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(getAsfeAsyncResponse(subTypes));
                return new DynamoDBEntity("TRAN001", "EVEN002", State.VALIDATED.name(), SubState.ENTERED, data, null, null);
            }
        };
        Mockito.when(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).thenAnswer(answer);
    }

    @Test
    void executeCleanForCreateScheduledMaintenanceTest() throws Exception {
        //
        var requestBody = getProcessScheduledMaintenanceStartRequest();
        mockHelperForCreateScheduledMaintenanceTest();
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        var subTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY)))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(subTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());

        Assertions.assertEquals(State.VALIDATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(subTypes, queueListenerBodyArgument.getValue().getSubTypes());
        var listenerBody = (ProcessScheduledMaintenanceRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageStartTest() throws Exception {
        //
        var subTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY);
        var requestBody = getProcessOutageStartRequest();
        mockHelperForOutageTest(subTypes);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(subTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(subTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());

        Assertions.assertEquals(State.VALIDATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(subTypes, queueListenerBodyArgument.getValue().getSubTypes());
        var listenerBody = (ProcessOutageStartRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }

    @Test
    void executeCleanForOutageEndTest() throws Exception {
        //
        var subTypes = List.of(SubType.CMHK_NOTIFY, SubType.AS_NOTIFY);
        var requestBody = getProcessOutageEndRequest();
        mockHelperForOutageTest(subTypes);
        var dynamoDbEntityArgument = ArgumentCaptor.forClass(DynamoDBEntity.class);
        var queueListenerBodyArgument = ArgumentCaptor.forClass(BasicQueueListenerRequest.class);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(new BasicQueueListenerRequest<>("TRAN0001", "EVEN0002", requestBody, new ArrayDeque<>(subTypes))), acknowledgment, messageHeaders);

        // assert
        Mockito.verify(dynamoDBMapper, Mockito.atMost(2)).save(dynamoDbEntityArgument.capture(), Mockito.isNull(), Mockito.any(DynamoDBMapperConfig.class));
        Assertions.assertEquals("TRAN001", dynamoDbEntityArgument.getValue().getTransactionId());
        Assertions.assertEquals("EVEN002", dynamoDbEntityArgument.getValue().getEventId());
        Assertions.assertEquals(subTypes, OBJECT_MAPPER.readValue(dynamoDbEntityArgument.getValue().getData(), AsfeAsyncStateResponse.class).getRemainingSubTypes());

        Assertions.assertEquals(State.VALIDATED.name(), dynamoDbEntityArgument.getValue().getState());
        Assertions.assertEquals(SubState.EXITED, dynamoDbEntityArgument.getValue().getSubState());

        Mockito.verify(queueMessagingTemplate).convertAndSend(Mockito.anyString(), queueListenerBodyArgument.capture());
        Assertions.assertNotNull(queueListenerBodyArgument.getValue().getBody());
        Assertions.assertEquals(subTypes, queueListenerBodyArgument.getValue().getSubTypes());
        var listenerBody = (ProcessOutageEndRequest) queueListenerBodyArgument.getValue().getBody();
        Assertions.assertNotNull(listenerBody);
    }
}