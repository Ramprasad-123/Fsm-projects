package com.hgc.apihub.hsbc.payme.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class BasicQueueListenerRequestTest {

    @Test
    void mapping() {
        // arrange
        var body = new PolledRequest("ID0000021", "ID0000022", "ID0000024");
        var request = new BasicQueueListenerRequest<>("ID0000021", "ID0000022", "ID0000023", "TEST", "test-queue", null, null, body, PayMeType.PAYMENT, PayMeSubType.REQUEST);
        // assert
        Assertions.assertNotNull(request);
        Assertions.assertEquals(0, request.getPollingCount());
        // act
        request.incrementPollingCount();
        Assertions.assertEquals(1, request.getPollingCount());
        // arrange
        var actual = new BasicQueueListenerRequest<>(body, PayMeType.PAYMENT, PayMeSubType.REQUEST, "1234", "test");
        // act
        var expected = new BasicQueueListenerRequest<>(actual, body);
        // assert
        Assertions.assertNotNull(expected);
        org.assertj.core.api.Assertions.assertThat(actual).usingRecursiveComparison().isEqualTo(expected);
    }
}
