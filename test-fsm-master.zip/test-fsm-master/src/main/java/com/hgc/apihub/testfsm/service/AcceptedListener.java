package com.hgc.apihub.testfsm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.apihub.testfsm.model.TestFsmRequest;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.service.BasicAWSAcceptedListener;
import com.hgc.lib.microservices.statemachine.model.DeliveredRequest;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
public class AcceptedListener extends BasicAWSAcceptedListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(AcceptedListener.class);

    @Override
    public final QueueListenerRequest<? extends QueueListenerBody> deserializeBody(final String body) throws Exception {
        return OBJECT_MAPPER.readValue(body, new TypeReference<QueueListenerRequest<DeliveredRequest>>() {
        });
    }

    @Override
    public final void executeClean(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) {
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "inside accepted execute clean...");
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "accepted request body; {}", ((DeliveredRequest) request.getBody()).getMessage());
        builder.addListenerRequest(QueueListenerRequest.builder()
                .transactionId(request.getTransactionId())
                .eventId(request.getEventId())
                .body(new TestFsmRequest()).build());
    }

    @Override
    public final void executeDirty(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) {
        // do nothing
    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }
}
