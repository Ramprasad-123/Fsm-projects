package com.hgc.apihub.callback.helper.asfe;

import com.apollographql.apollo.api.Error;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor
public class AsfeHelper {
    public static final String PROCEED = "proceed";
    public static final String PROCEED_TO_CREATE = "proceed_to_create";
    public static final String PROCEED_TO_PROCESS = "proceed_to_process";
    public static final String PROVIDER_CODE = "HGC";
    public static final String AFFECTED_PORT_TYPE = "GPON";
    public static final String ALARM_LEVEL = "O";
    public static final String API = "API";
    public static final String OUTAGE = "OUTAGE";
    public static final String SCH_MAINT = "SCH_MAINT";
    public static final String RESUME = "RESUME";
    public static final String DONE = "DONE";
    public static final String ERROR = "ERROR";

    public static List<SubType> getSubTypeAsList(final Deque<SubType> subTypes) {
        return subTypes != null ? new ArrayList<>(subTypes) : Collections.emptyList();
    }

    public static String getError(final List<Error> errors) {
        if (errors != null) {
            return errors.stream()
                    .map(Error::getMessage)
                    .filter(StringUtils::hasLength)
                    .collect(Collectors.joining(", "));
        }
        return null;
    }
}
