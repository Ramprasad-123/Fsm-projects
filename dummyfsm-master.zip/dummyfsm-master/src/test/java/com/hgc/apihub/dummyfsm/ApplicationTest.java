package com.hgc.apihub.dummyfsm;

import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = DummyFsmTestConfig.class)
@ActiveProfiles("test")
class ApplicationTest {

    @MockBean
    private AWSStateGraph awsStateGraph;

    @MockBean
    private BuildProperties buildProperties;

    @Test
    void configuration() {
        // assert
    }
}
