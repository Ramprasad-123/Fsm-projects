package com.hgc.apihub.callback.dao.asfe;

import com.apollographql.apollo.api.Error;
import com.apollographql.apollo.api.Response;
import com.hgc.apihub.graphqlatoms.client.queries.CreateAsNotifyMutation;
import com.hgc.apihub.graphqlatoms.client.queries.UpdateAsNotificationQueueMutation;
import com.hgc.apihub.graphqlatoms.client.type.AsNotificationQueueUpdateInput;
import com.hgc.apihub.graphqlatoms.client.type.AsNotifyInput;
import com.hgc.lib.core.exception.GraphQLMutationException;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.hgc.apihub.callback.AsfeTestHelper.getCreateAsNotifyMutationData;
import static com.hgc.apihub.callback.AsfeTestHelper.getCreateAsNotifyMutationDataWithEmptyId;
import static com.hgc.apihub.callback.AsfeTestHelper.getUpdateAsNotificationQueueMutationData;
import static com.hgc.apihub.callback.AsfeTestHelper.getUpdateAsNotificationQueueMutationDataWithEmptyFields;

@ExtendWith(SpringExtension.class)
class AtomsDaoTest {
    @MockBean
    private GraphQLTemplate graphQLTemplate;

    @MockBean
    private Response<Optional<CreateAsNotifyMutation.Data>> createAsNotifyData;

    @MockBean
    private Response<Optional<UpdateAsNotificationQueueMutation.Data>> updateAsNotificationQueueMutationData;

    private AtomsDao dao;

    @BeforeEach
    void setup() {
        var serviceToSpy = new AtomsDao(graphQLTemplate);
        dao = Mockito.spy(serviceToSpy);
    }

    @Test
    void createAsNotify() throws Exception {
        //arrange
        var expected = getCreateAsNotifyMutationData();
        Mockito.when(createAsNotifyData.hasErrors()).thenReturn(false);
        Mockito.when(createAsNotifyData.getData()).thenReturn(Optional.of(expected));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(CreateAsNotifyMutation.class))).thenReturn(createAsNotifyData);
        // act
        var actual = dao.createAsNotify(AsNotifyInput.builder().build());
        // assert
        Assertions.assertNull(actual);
    }

    @Test
    void createAsNotifyEmptyId() throws Exception {
        //arrange
        var expected = getCreateAsNotifyMutationDataWithEmptyId();
        Mockito.when(createAsNotifyData.hasErrors()).thenReturn(false);
        Mockito.when(createAsNotifyData.getData()).thenReturn(Optional.of(expected));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(CreateAsNotifyMutation.class))).thenReturn(createAsNotifyData);
        // act
        var actual = dao.createAsNotify(AsNotifyInput.builder().build());
        // assert
        Assertions.assertNotNull(actual);
    }

    @Test
    void createAsNotifyExceptionSupplierTest() {
        //arrange
        var expected = CreateAsNotifyMutation.Data.builder().build();
        Mockito.when(createAsNotifyData.hasErrors()).thenReturn(false);
        Mockito.when(createAsNotifyData.getData()).thenReturn(Optional.of(expected));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(CreateAsNotifyMutation.class))).thenReturn(createAsNotifyData);
        // act
        var actual = Assertions.assertThrows(GraphQLMutationException.class, () -> dao.createAsNotify(AsNotifyInput.builder().build()));
        // assert
        Assertions.assertNotNull(actual.getMessage());
    }

    @Test
    void createAsNotifyFailException() {
        //arrange
        var errors = List.of(new Error("Test error", List.of(new Error.Location(0L, 0L)), Map.of("test", "test")));
        Mockito.when(createAsNotifyData.hasErrors()).thenReturn(true);
        Mockito.when(createAsNotifyData.getErrors()).thenReturn(errors);
        Mockito.when(graphQLTemplate.mutation(Mockito.any(CreateAsNotifyMutation.class))).thenReturn(createAsNotifyData);
        // act
        var actual = Assertions.assertThrows(GraphQLMutationException.class, () -> dao.createAsNotify(AsNotifyInput.builder().build()));
        // assert
        Assertions.assertNotNull(actual.getMessage());
    }

    @Test
    void updateAsNotificationQueue() throws GraphQLMutationException {
        //arrange
        var expected = getUpdateAsNotificationQueueMutationData();
        Mockito.when(updateAsNotificationQueueMutationData.hasErrors()).thenReturn(false);
        Mockito.when(updateAsNotificationQueueMutationData.getData()).thenReturn(Optional.of(expected));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(UpdateAsNotificationQueueMutation.class))).thenReturn(updateAsNotificationQueueMutationData);
        // act
        var actual = dao.updateAsNotificationQueue("1", AsNotificationQueueUpdateInput.builder().build());
        // assert
        Assertions.assertNull(actual);
    }

    @Test
    void updateAsNotificationQueueEmptyStatus() throws GraphQLMutationException {
        //arrange
        var expected = getUpdateAsNotificationQueueMutationDataWithEmptyFields();
        Mockito.when(updateAsNotificationQueueMutationData.hasErrors()).thenReturn(false);
        Mockito.when(updateAsNotificationQueueMutationData.getData()).thenReturn(Optional.of(expected));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(UpdateAsNotificationQueueMutation.class))).thenReturn(updateAsNotificationQueueMutationData);
        // act
        var actual = dao.updateAsNotificationQueue("1", AsNotificationQueueUpdateInput.builder().build());
        // assert
        Assertions.assertNotNull(actual);
    }

    @Test
    void updateAsNotificationQueueExceptionSupplierTest() {
        //arrange
        var expected = UpdateAsNotificationQueueMutation.Data.builder().build();
        Mockito.when(updateAsNotificationQueueMutationData.hasErrors()).thenReturn(false);
        Mockito.when(updateAsNotificationQueueMutationData.getData()).thenReturn(Optional.of(expected));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(UpdateAsNotificationQueueMutation.class))).thenReturn(updateAsNotificationQueueMutationData);
        // act
        var actual = Assertions.assertThrows(GraphQLMutationException.class, () -> dao.updateAsNotificationQueue("1", AsNotificationQueueUpdateInput.builder().build()));
        // assert
        Assertions.assertNotNull(actual.getMessage());
    }

    @Test
    void updateAsNotificationQueueFailException() {
        //arrange
        var errors = List.of(new Error("Test error", List.of(new Error.Location(0L, 0L)), Map.of("test", "test")));
        Mockito.when(updateAsNotificationQueueMutationData.hasErrors()).thenReturn(true);
        Mockito.when(updateAsNotificationQueueMutationData.getErrors()).thenReturn(errors);
        Mockito.when(graphQLTemplate.mutation(Mockito.any(UpdateAsNotificationQueueMutation.class))).thenReturn(updateAsNotificationQueueMutationData);
        // act
        var actual = Assertions.assertThrows(GraphQLMutationException.class, () -> dao.updateAsNotificationQueue("1", AsNotificationQueueUpdateInput.builder().build()));
        // assert
        Assertions.assertNotNull(actual.getMessage());    }
}