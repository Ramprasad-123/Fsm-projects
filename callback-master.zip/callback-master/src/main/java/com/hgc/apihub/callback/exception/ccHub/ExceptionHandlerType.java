package com.hgc.apihub.callback.exception.ccHub;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum ExceptionHandlerType {

    // custom exceptions that is to return to API caller
    CcHubNotFoundException(
            10001,
            "No Hub with this information exist",
            "No Hub with this information exist."
    ),
    CcHubDeleteOperationFailException(
            10002,
            "Delete Hub fail",
            "Delete Hub fail."
    );


    private int code;
    private String reason;
    private String message;
    private List<Class<? extends Throwable>> exceptionClasses;
    private static Map<Class<? extends Throwable>, ExceptionHandlerType> exceptionClassMap = new HashMap<>();


    ExceptionHandlerType(final int codeValue, final String reasonValue, final String messageValue, final Class<? extends Throwable>... exceptionClassesValue) {
        this.code = codeValue;
        this.reason = reasonValue;
        this.message = messageValue;
        this.exceptionClasses = Arrays.asList(exceptionClassesValue);
    }

    public int getCode() {
        return code;
    }

    public String getReason() {
        return reason;
    }

    public String getMessage() {
        return message;
    }
}
