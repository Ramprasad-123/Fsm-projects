# HGC Dummy FSM for stress testing

Test FSM service build on spring boot for HGC

## Getting Started

For understanding the project source code, the following knowledge will be helpful in no particular order:
* Java
* Maven
* Spring Framework
* AWS SQS
* AWS DynamoDB
* Git
* Log4j2

The list above is not an exhaustive list.

### Prerequisites

* [Git](https://git-scm.com/) is installed. Required for checking out the source code.
* [JDK 13](https://jdk.java.net/13/) is installed. Required for development and running the project.

### HGC Core Library required
In order to build and run the project locally, the following Parent POM and core libraries need to be in place in .m2/repository
Examine the readme of these project on GitLab .
Clone and build these dependencies locally.
* Java Parent
* Microservices Core
* Microservices parent pom
* Log Unification
* Microservices State Machine
* Microservices AWS FSM
* Microservices-AWS-FSM-parent pom

Before build locally

To obtain a local copy of the master branch of the repository, you can run the following command.
```
git clone git@gitlab.com:hgc-global-communications/api-hub/dummy-fsm.git
```

### Development
* IntelliJ is the preferred IDE


### Build


## Built With

* [JDK 13](https://jdk.java.net/13/) - The core project built on JVM
* [Maven](https://maven.apache.org/) - Dependency Management
* [Spring Boot 2.3.3](https://spring.io/projects/spring-boot) - Spring framework

## Versioning


## Authors

* **Robert Suen** - [\<robert.suen@hgc.com.hk\>](mailto:robert.suen@hgc.com.hk)

## Copyright

Copyright &copy; 2021, [HGC Global Communications Limited](http://www.hgc.com.hk/Home/Index-en.html).
All rights reserved.