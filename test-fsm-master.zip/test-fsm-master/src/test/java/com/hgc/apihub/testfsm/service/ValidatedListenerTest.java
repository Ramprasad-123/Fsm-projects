package com.hgc.apihub.testfsm.service;

//TODO sample code, to be removed/updated

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.hgc.lib.microservices.aws.fsm.common.AWSQueueListenerTest;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.model.Link;
import com.hgc.lib.microservices.statemachine.model.AsyncStateResponse;
import com.hgc.lib.microservices.statemachine.model.FSMEntityDaoRequest;
import com.hgc.lib.microservices.statemachine.model.FSMLockClient;
import com.hgc.lib.microservices.statemachine.model.FSMLockWrapper;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.SubState;
import com.hgc.apihub.testfsm.TestFsmTestHelper;
import com.hgc.apihub.testfsm.model.TestFsmRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Map;

import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;
import static com.hgc.lib.microservices.statemachine.StateMachineHelper.convertLocalDateTime;
import static com.hgc.lib.microservices.statemachine.common.StateMachineMock.removeLastUpdateDate;
import static com.hgc.lib.microservices.statemachine.service.QueueListener.HEADER_MESSAGE_GROUP_ID;

@ExtendWith(SpringExtension.class)
class ValidatedListenerTest extends AWSQueueListenerTest {

    private ValidatedListener listener;

    @BeforeEach
    void setup() throws Exception {
        this.init();
        listener = new ValidatedListener();
        this.setDependencies(listener, State.VALIDATED.name());
    }

    @Override
    protected AWSStateGraph constructStateGraph() {
        return TestFsmTestHelper.constructStateGraph();
    }

    @Test
    void listener() throws Exception {
        // arrange
        var requestBody = new TestFsmRequest();
        var response = AsyncStateResponse.asyncStateBuilder().transactionId("ID0000021").eventId("ID0000022").state(State.ACCEPTED.name()).links(List.of(Link.withSelfRelation("https://apihub.hgc.com/test/abc123"))).build();
        var item = new HGCDynamoDBEntity("TEST", "CREATE", null, "ID0000021", "ID0000022", State.ACCEPTED.name(), SubState.ENTERED, OBJECT_MAPPER.writeValueAsString(response), null, null, null, null);
        var answer = new Answer<DynamoDBEntity>() {
            @Override
            public DynamoDBEntity answer(InvocationOnMock invocation) {
                return item;
            }
        };
        BDDMockito.given(dynamoDBMapper.load(Mockito.eq(DynamoDBEntity.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(DynamoDBMapperConfig.class))).willAnswer(answer);
        var updateArgument = ArgumentCaptor.forClass(FSMEntityDaoRequest.Update.class);
        var urlArgument = ArgumentCaptor.forClass(String.class);
        var requestArgument = ArgumentCaptor.forClass(QueueListenerRequest.class);
        var headerArgument = ArgumentCaptor.forClass(Map.class);
        // act
        listener.listener(OBJECT_MAPPER.writeValueAsString(QueueListenerRequest.builder().transactionId("ID0000021").eventId("ID0000022").body(requestBody).build()), acknowledgment, messageHeaders);
        // assert
        Mockito.verify(dynamoDBDao, Mockito.atLeastOnce()).update(updateArgument.capture());
        Assertions.assertEquals("ID0000021", updateArgument.getValue().getItem().getTransactionId());
        Assertions.assertEquals("ID0000022", updateArgument.getValue().getItem().getEventId());
        Assertions.assertEquals(State.VALIDATED.name(), updateArgument.getValue().getItem().getState());
        Assertions.assertEquals(SubState.EXITED, updateArgument.getValue().getItem().getSubState());
        var expected = AsyncStateResponse.asyncStateBuilder().transactionId("ID0000021").eventId("ID0000022").state(State.VALIDATED.name()).links(List.of(Link.withSelfRelation("https://apihub.hgc.com/test/abc123"))).build();
        expected.setCreateDate(convertLocalDateTime(item.getCreateDate()));
        Assertions.assertEquals(removeLastUpdateDate(OBJECT_MAPPER.writeValueAsString(expected)), removeLastUpdateDate(updateArgument.getValue().getItem().getData()));
        Mockito.verify(queueMessagingTemplate).convertAndSend(urlArgument.capture(), requestArgument.capture(), headerArgument.capture());
        Assertions.assertEquals("test-fsm-custom.fifo", urlArgument.getValue());
        Assertions.assertEquals(OBJECT_MAPPER.writeValueAsString(requestBody), OBJECT_MAPPER.writeValueAsString(requestArgument.getValue().getBody()));
        Assertions.assertEquals("test-123456789", headerArgument.getValue().get(HEADER_MESSAGE_GROUP_ID));
        Mockito.verify(dynamoDBDao, Mockito.atLeastOnce()).releaseLock(Mockito.any(FSMLockClient.class), Mockito.any(FSMLockWrapper.class));
    }
}
