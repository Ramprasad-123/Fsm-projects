package com.hgc.apihub.dummyfsm.model;

//TODO sample code, to be removed/updated

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.StateResponse;
import io.swagger.annotations.ApiModel;
import lombok.Getter;

@Getter
@ApiModel(description = "Dummy fsm response body")
public class DummyFsmResponse extends StateResponse {

    public DummyFsmResponse(@JsonProperty("status") final Integer status, @JsonProperty("transaction_id") final String transactionId, @JsonProperty("event_id") final String eventId, @JsonProperty("state") final State state) {
        super(status, transactionId, eventId, state.toString());    // upgrade to fsm 2.1.0: enum to string
    }
}
