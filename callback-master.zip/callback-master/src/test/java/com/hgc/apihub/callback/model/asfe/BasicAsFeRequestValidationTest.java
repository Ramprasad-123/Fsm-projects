package com.hgc.apihub.callback.model.asfe;

import com.hgc.lib.microservices.common.validation.BlankValidationTest;
import com.hgc.lib.microservices.common.validation.NullValidationTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.List;
import java.util.stream.Stream;

import static com.hgc.apihub.callback.AsfeTestHelper.*;

class BasicAsFeRequestValidationTest implements BlankValidationTest<BasicAsFeRequest>, NullValidationTest<BasicAsFeRequest> {

    private static Stream<Arguments> testArgumentProvider() {
        return Stream.of(
                Arguments.of("M", getScheduledMaintenanceStartRequest().getAbbreviateCallbackType()),
                Arguments.of("M", getScheduledMaintenanceEndRequest().getAbbreviateCallbackType()),
                Arguments.of("A", getOutageStartRequest().getAbbreviateCallbackType()),
                Arguments.of("A", getOutageEndRequest().getAbbreviateCallbackType())
        );
    }

    @MethodSource("testArgumentProvider")
    @ParameterizedTest
    void getAbbreviateCallbackType(final String expected, final String actual) {
        // arrange
        // act
        // assert
        Assertions.assertEquals(expected, actual);
    }

    private static Stream<Arguments> testArgumentProviderForSeverity() {
        return Stream.of(
                Arguments.of("H", getScheduledMaintenanceStartRequest().getCategorizedSeverity()),
                Arguments.of("L", getOutageStartRequest().getCategorizedSeverity()),
                Arguments.of("L", getOutageEndRequest().getCategorizedSeverity())
        );
    }

    @MethodSource("testArgumentProviderForSeverity")
    @ParameterizedTest
    void getCategorizedSeverity(final String expected, final String actual) {
        // arrange
        // act
        // assert
        Assertions.assertEquals(expected, actual);
    }

    private static Stream<Arguments> testArgumentProviderForAction() {
        return Stream.of(
                Arguments.of("S", getScheduledMaintenanceStartRequest().getAbbreviatedAction()),
                Arguments.of("E", getScheduledMaintenanceEndRequest().getAbbreviatedAction()),
                Arguments.of("S", getOutageStartRequest().getAbbreviatedAction()),
                Arguments.of("E", getOutageEndRequest().getAbbreviatedAction())
        );
    }

    @MethodSource("testArgumentProviderForAction")
    @ParameterizedTest
    void getAbbreviatedAction(final String expected, final String actual) {
        // arrange
        // act
        // assert
        Assertions.assertEquals(expected, actual);
    }

    @Override
    public List<BasicAsFeRequest> blankInstances() {
        return List.of(getBasicAsfeRequestViolateNotBlanks());
    }

    @Override
    public List<Integer> numberOfNonBlankAnnotations() {
        return List.of(2);
    }

    @Override
    public List<BasicAsFeRequest> nullInstances() {
        return List.of(getBasicAsfeRequestViolateNotNulls());
    }

    @Override
    public List<Integer> numberOfNonNullAnnotations() {
        return List.of(3);
    }

    @Override
    public BasicAsFeRequest validInstance() {
        return getBasicAsfeRequest();
    }
}