package com.hgc.apihub.dummyfsm;

//TODO sample code, to be removed/updated

import com.hgc.lib.microservices.aws.fsm.node.AWSStateEdge;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateGraph;
import com.hgc.lib.microservices.aws.fsm.node.AWSStateNode;
import com.hgc.lib.microservices.aws.fsm.node.StateWeightConverter;
import com.hgc.lib.microservices.statemachine.model.State;

import java.util.List;

import static com.hgc.lib.microservices.aws.fsm.common.AWSStateMachineMock.constructAWSStateGraph;

public class DummyFsmTestHelper {

    private DummyFsmTestHelper() {
    }

    public static AWSStateGraph constructStateGraph() {
        var nodes = List.of(new AWSStateNode("dummy-fsm", State.ACCEPTED.toString(), true, null, null),
                new AWSStateNode("dummy-fsm", State.VALIDATED.toString(), false, "dummy-fsm-validate", "dummy-fsm-dlq"),
                new AWSStateNode("dummy-fsm", State.PROCESSED.toString(), false, "dummy-fsm-process", "dummy-fsm-dlq"));
        var converter = new StateWeightConverter();
        var edges = List.of(new AWSStateEdge("dummy-fsm", State.ACCEPTED.toString(), List.of(State.VALIDATED.toString()), null),
                new AWSStateEdge("dummy-fsm", State.VALIDATED.toString() , List.of(State.PROCESSED.toString()), converter.unconvert("[{\"expression\":\"return success\",\"bindings\":{\"success\":true}}]")));
        return constructAWSStateGraph(nodes, edges);
    }
}
