package com.hgc.apihub.hsbc.directdebit.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

class MandateStatusTest {

    @ParameterizedTest(name = "{0} has a property of {1}.")
    @MethodSource("provideArguments")
    void testResult(MandateStatus result, String description, boolean isPending) {
        // assert
        Assertions.assertEquals(description, result.getDescription());
        Assertions.assertEquals(isPending, MandateStatus.isPending(result));
    }

    private static Stream<Arguments> provideArguments() {
        return Stream.of(
                Arguments.of(MandateStatus.ERROR, "Error", false),
                Arguments.of(MandateStatus.ACTIVE, "Active", false),
                Arguments.of(MandateStatus.SUSPENDED, "Suspended", false),
                Arguments.of(MandateStatus.DORMANT, "Dormant", false),
                Arguments.of(MandateStatus.EXPIRED, "Expired", false),
                Arguments.of(MandateStatus.CANCELLED, "Cancelled via other channels", false),
                Arguments.of(MandateStatus.DELETED, "DDA becomes obsolete", false),
                Arguments.of(MandateStatus.PDNG, "Pending from Debtor's bank response (DDAE)", true),
                Arguments.of(MandateStatus.PDFP, "Pending from Debtor's bank response (EDDA)", true),
                Arguments.of(MandateStatus.PDOU, "Pending to debtor accounts with HSBC DDA response", true)
        );
    }
}
