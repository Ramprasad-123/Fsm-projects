package com.hgc.apihub.dynamodbcleanup.controller;

//TODO sample code, to be removed

import com.hgc.apihub.dynamodbcleanup.model.DynamoDbOperationResponse;
import com.hgc.apihub.dynamodbcleanup.model.TableName;
import com.hgc.apihub.dynamodbcleanup.service.DateValidation;
import com.hgc.apihub.dynamodbcleanup.service.DynamoDbCleanUpService;
import com.hgc.lib.microservices.model.Response;
import com.hgc.lib.microservices.swagger.Error400Response;
import com.hgc.lib.microservices.swagger.Error404Response;
import com.hgc.lib.microservices.swagger.Error500Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;

import static com.hgc.lib.microservices.MicroservicesHelper.API_RESPONSE_CODE_200;
import static com.hgc.lib.microservices.MicroservicesHelper.API_RESPONSE_CODE_400;
import static com.hgc.lib.microservices.MicroservicesHelper.API_RESPONSE_CODE_404;
import static com.hgc.lib.microservices.MicroservicesHelper.API_RESPONSE_CODE_500;

@RestController
@RequestMapping("/v1/clean-up")
@Validated
@RequiredArgsConstructor
@Api(tags = "Operations pertaining to DynamoDb clean operations")
public class DynamoDbCleanUpController {

    private static final String API_RESPONSE_CODE_200_SWAGGER_VALUE = "Operation successfully executed";
    private static final String API_RESPONSE_CODE_400_SWAGGER_VALUE = "Request/Parameter is invalid";
    private static final String API_RESPONSE_CODE_500_SWAGGER_VALUE = "Server/Unknown/Querying error occurred";
    private static final String API_RESPONSE_CODE_404_SWAGGER_VALUE = "Transaction not found";

    private static final String SWAGGER_EXAMPLE_START_DATE = "2022-05-01 00:00:00";
    private static final String SWAGGER_EXAMPLE_END_DATE = "2022-05-31 23:59:59";

    private final DynamoDbCleanUpService dynamoDbCleanUpService;

    @ApiOperation(value = "Clean up a2p-sms table in DynamoDb")
    @ApiResponses(
            value = {
                    @ApiResponse(code = API_RESPONSE_CODE_200, message = API_RESPONSE_CODE_200_SWAGGER_VALUE, response = DynamoDbOperationResponse.class),
                    @ApiResponse(code = API_RESPONSE_CODE_400, message = API_RESPONSE_CODE_400_SWAGGER_VALUE, response = Error400Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_404, message = API_RESPONSE_CODE_404_SWAGGER_VALUE, response = Error404Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_500, message = API_RESPONSE_CODE_500_SWAGGER_VALUE, response = Error500Response.class)
            }
    )
    @PatchMapping(path = "/a2p-sms", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> cleanUpA2pSmsTable(
            @ApiParam(value="Start date", required = true,  example=SWAGGER_EXAMPLE_START_DATE) @RequestParam(name="start_date") @DateValidation @NotNull String startDate,
            @ApiParam(value="End date", required = true,  example=SWAGGER_EXAMPLE_END_DATE) @RequestParam(name="end_date") @DateValidation @NotNull String endDate
    ) throws Exception {
        var response = dynamoDbCleanUpService.deleteRecords(startDate, endDate, TableName.a2p.name());
        response.setStatus(HttpStatus.OK.value());
        return new ResponseEntity<>(response, response.getHttpStatus());
    }

    @ApiOperation(value = "Clean up tnss-integration table in DynamoDb")
    @ApiResponses(
            value = {
                    @ApiResponse(code = API_RESPONSE_CODE_200, message = API_RESPONSE_CODE_200_SWAGGER_VALUE, response = DynamoDbOperationResponse.class),
                    @ApiResponse(code = API_RESPONSE_CODE_404, message = API_RESPONSE_CODE_404_SWAGGER_VALUE, response = Error404Response.class),
                    @ApiResponse(code = API_RESPONSE_CODE_500, message = API_RESPONSE_CODE_500_SWAGGER_VALUE, response = Error500Response.class)
            }
    )
    @PatchMapping(value = "/tnss-integration", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response> cleanUpTnssIntegrationTable(
            @ApiParam(value="Start date", required = true,  example=SWAGGER_EXAMPLE_START_DATE) @RequestParam(name="start_date") @DateValidation @NotNull String startDate,
            @ApiParam(value="End date", required = true,  example=SWAGGER_EXAMPLE_END_DATE) @RequestParam(name="end_date") @DateValidation @NotNull String endDate
    ) throws Exception {
        var response = dynamoDbCleanUpService.deleteRecords(startDate, endDate, TableName.tnssintegration.name());
        return new ResponseEntity<>(response, response.getHttpStatus());
    }
}
