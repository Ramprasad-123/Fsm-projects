package com.hgc.apihub.testfsm;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBDao;
import com.hgc.lib.microservices.aws.fsm.model.DynamoDBEntity;
import com.hgc.lib.microservices.aws.fsm.model.HGCDynamoDBDao;
import com.hgc.lib.microservices.statemachine.configuration.FSMDBConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@SpringBootApplication
public class Application {

    public static void main(final String[] args) {
        SpringApplication.run(Application.class, args);
    }

    /**
     * HGC DynamoDB DAO as the primary DAO
     *
     * @param fsmDBConfig              the FSM DB config
     * @param amazonDynamoDB           the amazon DynamoDB
     * @param dynamoDBMapper           the DynamoDB mapper
     * @return DynamoDB DAO
     */
    @Bean
    @Primary
    public DynamoDBDao<? extends DynamoDBEntity> dynamoDBDao(final FSMDBConfig fsmDBConfig, final AmazonDynamoDB amazonDynamoDB, final DynamoDBMapper dynamoDBMapper) {
        return new HGCDynamoDBDao(fsmDBConfig, amazonDynamoDB, dynamoDBMapper);
    }
}
