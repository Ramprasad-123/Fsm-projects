package com.hgc.apihub.callback.service.ccHub;

import com.hgc.apihub.callback.dao.ccHub.CchubDao;
import com.hgc.apihub.callback.exception.ccHub.CcHubDeleteOperationFailException;
import com.hgc.apihub.callback.exception.ccHub.CcHubNotFoundException;
import com.hgc.apihub.callback.exception.ccHub.GraphQLMutationException;
import com.hgc.apihub.callback.model.ccHub.HubRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.hgc.apihub.callback.HubTestHelper.getCcHubFields;
import static com.hgc.apihub.callback.HubTestHelper.getHubResponse;

@ExtendWith(SpringExtension.class)
public class HubServiceTest {

    @MockBean
    private CchubDao cchubDao;

    private HubService hubService;

    @BeforeEach
    void setup() {
        var hubServiceToSpy = new HubService(cchubDao);
        hubService = Mockito.spy(hubServiceToSpy);
    }

    @Test
    void createHubTest() throws GraphQLMutationException {

        // arrange
        var expected = getCcHubFields();
        Mockito.when(cchubDao.createHub(Mockito.anyString(), Mockito.any(HubRequest.class)))
                .thenReturn(expected);

        // act
        var actual = hubService.createHub("12345", new HubRequest());

        // assert
        Assertions.assertNotNull(actual);
    }

    @Test
    void deleteHubTest() throws GraphQLMutationException, CcHubDeleteOperationFailException, CcHubNotFoundException {

        // arrange
        Mockito.when(cchubDao.deleteHub(Mockito.anyString()))
                .thenReturn(true);

        // act
        var actual = hubService.deleteHub("12345");

        // assert
        Assertions.assertNotNull(actual);
    }

    @Test
    void getHubListTest() throws GraphQLMutationException {

        // arrange
        var expected = getHubResponse();
        Mockito.when(cchubDao.getHubList(Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(expected);

        // act
        var actual = hubService.getHubList(1, 10);

        // assert
        Assertions.assertNotNull(actual);
    }


}
