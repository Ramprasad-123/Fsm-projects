package com.hgc.apihub.fsmadapter.model;

import com.hgc.lib.microservices.common.validation.BlankValidationTest;
import com.hgc.lib.microservices.common.validation.NullValidationTest;
import com.hgc.lib.microservices.model.AuthType;
import jakarta.validation.ConstraintViolation;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.stream.Collectors;

import static com.hgc.apihub.fsmadapter.AdapterTestHelper.*;

public class InitiateMessageRequestValidationTest implements NullValidationTest<InitiateMessageRequest>, BlankValidationTest<InitiateMessageRequest> {

    @Override
    public List<InitiateMessageRequest> nullInstances() {
        return List.of(getNullInitiateMessageRequest());
    }

    @Override
    public List<Integer> numberOfNonNullAnnotations() {
        return List.of(1);
    }


    @Override
    public List<InitiateMessageRequest> blankInstances() {
        return List.of(getBlackInitiateMessageRequest());
    }

    @Override
    public List<Integer> numberOfNonBlankAnnotations() {
        return List.of(2);
    }

    @Override
    public InitiateMessageRequest validInstance() {
        return getInitiateMessageRequest();
    }

    @Test
    void validator() {
        // assert
        var request = new InitiateMessageRequest("test message", "test queue", "test_fsm", "/test-fsm/v1", AuthType.BASIC, "test", 5, "test.com");
        var constraintViolations = validator.validate(request);
        var validationMessages = constraintViolations.stream().collect(Collectors.toMap(c -> c.getPropertyPath().toString(), ConstraintViolation::getMessage));
        Assertions.assertEquals("must be a valid URL", validationMessages.get("callbackUrl"));
        Assertions.assertEquals("must be a valid URL", validationMessages.get("selfLink"));
    }
}
