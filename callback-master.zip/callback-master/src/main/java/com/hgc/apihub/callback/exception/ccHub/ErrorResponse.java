package com.hgc.apihub.callback.exception.ccHub;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
@JsonPropertyOrder({"reference_id", "result", "status", "code", "reason", "message"})
public class ErrorResponse {
//public class ErrorResponse extends VoiceMessageResponse {

    private final int code;
    private final String reason;
    private final String message;
    private final int status;

    public ErrorResponse(final HttpStatus httpStatusValue, final ExceptionHandlerType exceptionHandlerEnum) {
        //super(null, null, httpStatusValue);
        this.code = exceptionHandlerEnum.getCode();
        this.reason = exceptionHandlerEnum.getReason();
        this.message = exceptionHandlerEnum.getMessage();
        this.status = httpStatusValue.value();
    }

    public ErrorResponse(final String message, final HttpStatus httpStatusValue, final ExceptionHandlerType exceptionHandlerEnum) {
        //super(referenceIdValue, resultType, httpStatusValue);
        this.code = exceptionHandlerEnum.getCode();
        this.reason = exceptionHandlerEnum.getReason();
        this.message = message;
        this.status = httpStatusValue.value();
    }
}
