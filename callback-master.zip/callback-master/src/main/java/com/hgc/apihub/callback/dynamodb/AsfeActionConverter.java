package com.hgc.apihub.callback.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import org.springframework.util.StringUtils;

public class AsfeActionConverter implements DynamoDBTypeConverter<String, AsFeAction> {

    @Override
    public final String convert(final AsFeAction action) {
        if (action != null) {
            return action.name();
        }
        return null;
    }

    @Override
    public final AsFeAction unconvert(final String action) {
        if (StringUtils.hasLength(action)) {
            return AsFeAction.fromValue(action);
        }
        return null;
    }
}
