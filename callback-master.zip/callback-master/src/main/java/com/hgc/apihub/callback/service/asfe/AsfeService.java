package com.hgc.apihub.callback.service.asfe;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hgc.apihub.callback.configuration.CmhkConfig;
import com.hgc.apihub.callback.dao.asfe.AtomsDao;
import com.hgc.apihub.callback.exception.asfe.CmhkTokenException;
import com.hgc.apihub.callback.model.asfe.*;
import com.hgc.apihub.callback.model.asfe.enums.CallbackType;
import com.hgc.apihub.graphqlatoms.client.type.AsNotificationQueueUpdateInput;
import com.hgc.apihub.graphqlatoms.client.type.AsNotifyInput;
import com.hgc.lib.core.HGCHelper;
import com.hgc.lib.core.exception.GraphQLMutationException;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.model.FieldErrorMessage;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import org.apache.logging.log4j.Level;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestOperations;

import java.util.stream.Collectors;

import static com.hgc.apihub.callback.CallbackHelper.parseRemarksAndAddTime;
import static com.hgc.apihub.callback.helper.asfe.AsfeHelper.*;
import static com.hgc.lib.core.HGCHelper.DATE_TIME_FORMATTER;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
public class AsfeService {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(AsfeService.class);
    public static final String NOTIFY_CMHK_ERROR = "Error occurred while notifying CMHK for transaction with transaction id {} and event id {} : {}";
    public static final String NOTIFY_CMHK_HEADER_KEY = "X-Channel-Id";
    public static final String NOTIFY_CMHK_HEADER_VALUE = "ALARM";
    private final RestOperations restOperations;
    private final CmhkConfig cmhkConfig;
    private final CmhkAuthService cmhkAuthService;
    private final AtomsDao atomsDao;

    public AsfeService(final RestOperations restOperationsValue, final CmhkConfig cmhkConfigValue, final CmhkAuthService cmhkAuthServiceValue, final AtomsDao atomsDaoValue) {
        restOperations = restOperationsValue;
        cmhkConfig = cmhkConfigValue;
        cmhkAuthService = cmhkAuthServiceValue;
        atomsDao = atomsDaoValue;
    }

    public final FieldErrorMessage notifyCmhk(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder, final CmhkNotifyRequest payload) {
        FieldErrorMessage fieldErrorMessage = null;
        String token;
        try {
            token = cmhkAuthService.getToken();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(token);
            headers.add(NOTIFY_CMHK_HEADER_KEY, NOTIFY_CMHK_HEADER_VALUE);
            var url = cmhkConfig.getHost() + cmhkConfig.getNotifyUrl();
            var requestEntity = new HttpEntity<>(payload, headers);
            LOGGER.unify(Level.INFO, "Calling cmhk notify url with url:{}, request:{}", url, requestEntity);
            LOGGER.unify(Level.INFO, "Calling cmhk notify url with payload:{}", OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(payload));
            var notifyResponse = restOperations.exchange(url, HttpMethod.POST, requestEntity, CmhkNotifyResponse.class);
            var body = notifyResponse.getBody();
            LOGGER.unify(Level.INFO, "CMHK response : {}", OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(notifyResponse.getBody()));
            if (notifyResponse.getStatusCode().is4xxClientError()) {
                LOGGER.unify(builder.getLogBuilderId(), Level.ERROR, NOTIFY_CMHK_ERROR, request.getTransactionId(), request.getEventId(), notifyResponse.toString());
                fieldErrorMessage = new FieldErrorMessage(Integer.toString(notifyResponse.getStatusCodeValue()), String.format("%s : bad request while notifying CMHK!", notifyResponse.getStatusCodeValue()));
            } else if (!notifyResponse.getStatusCode().is2xxSuccessful() || body == null) {
                LOGGER.unify(builder.getLogBuilderId(), Level.ERROR, NOTIFY_CMHK_ERROR, request.getTransactionId(), request.getEventId(), notifyResponse.toString());
                fieldErrorMessage = new FieldErrorMessage(Integer.toString(notifyResponse.getStatusCodeValue()), String.format("%s : error occurred while notifying CMHK!", notifyResponse.getStatusCodeValue()));
            } else {
                LOGGER.unify(builder.getLogBuilderId(), Level.INFO, "CMHK is notified for transaction with transaction id {} and event id {}", request.getTransactionId(), request.getEventId());
                LOGGER.unify(builder.getLogBuilderId(), Level.INFO, body);
            }
            return fieldErrorMessage;
        } catch (CmhkTokenException eValue) {
            return new FieldErrorMessage("500", eValue.getMessage());
        } catch (JsonProcessingException eValue) {
            return new FieldErrorMessage("400", eValue.getMessage());
        }
    }

    public static <T> CmhkNotifyRequest mapCmhkNotifyRequest(final T processRequestBody) {
        if (processRequestBody instanceof ProcessScheduledMaintenanceRequest requestBody) {
            var apiInput = requestBody.getRequest();
            if (CallbackType.PLANNED_MAINTENANCE_START == apiInput.getCallbackType()) {
                return new CmhkNotifyRequest(new CmhkNotifyRequest.Params(
                        apiInput.getStore().getId(),
                        null,
                        apiInput.getAffectCustLnoc().stream().map(BasicAsFeRequest.AffectCustLnoc::getBuildingId).distinct().collect(Collectors.toList()),
                        apiInput.getAbbreviateCallbackType(),
                        ALARM_LEVEL,
                        apiInput.getCategorizedSeverity(),
                        apiInput.getAbbreviatedAction(),
                        apiInput.getStore().getAddDate(),
                        apiInput.getSchMaint().getStartDate(),
                        AFFECTED_PORT_TYPE,
                        apiInput.getSchMaint().getEndDate(),
                        PROVIDER_CODE
                ));
            } else {
                return new CmhkNotifyRequest(new CmhkNotifyRequest.Params(
                        apiInput.getStore().getId(),
                        null,
                        apiInput.getAffectCustLnoc().stream().map(BasicAsFeRequest.AffectCustLnoc::getBuildingId).distinct().collect(Collectors.toList()), apiInput.getAbbreviateCallbackType(),
                        ALARM_LEVEL,
                        apiInput.getCategorizedSeverity(),
                        apiInput.getAbbreviatedAction(),
                        apiInput.getStore().getAddDate(),
                        apiInput.getSchMaint().getEndDate(),
                        AFFECTED_PORT_TYPE,
                        apiInput.getSchMaint().getEndDate(),
                        PROVIDER_CODE
                ));
            }
        } else if (processRequestBody instanceof ProcessOutageStartRequest requestBody) {
            var apiInput = requestBody.getRequest();
            return new CmhkNotifyRequest(new CmhkNotifyRequest.Params(
                    apiInput.getStore().getId(),
                    null,
                    apiInput.getAffectCustLnoc().stream().map(BasicAsFeRequest.AffectCustLnoc::getBuildingId).distinct().collect(Collectors.toList()),
                    apiInput.getAbbreviateCallbackType(),
                    ALARM_LEVEL,
                    apiInput.getCategorizedSeverity(),
                    apiInput.getAbbreviatedAction(),
                    apiInput.getStore().getAddDate(),
                    StringUtils.hasLength(apiInput.getStore().getRemarks2()) ? apiInput.getStore().getRemarks2() : apiInput.getStore().getAddDate(),
                    AFFECTED_PORT_TYPE,
                    StringUtils.hasLength(apiInput.getStore().getRemarks2()) ? parseRemarksAndAddTime(apiInput.getStore().getRemarks2()) : apiInput.getStore().getAddDate(),
                    PROVIDER_CODE
            ));
        } else {
            var apiInput = ((ProcessOutageEndRequest) processRequestBody).getRequest();
            return new CmhkNotifyRequest(new CmhkNotifyRequest.Params(
                    apiInput.getStore().getId(),
                    null,
                    apiInput.getAffectCustLnoc().stream().map(BasicAsFeRequest.AffectCustLnoc::getBuildingId).distinct().collect(Collectors.toList()),
                    apiInput.getAbbreviateCallbackType(),
                    ALARM_LEVEL,
                    apiInput.getCategorizedSeverity(),
                    apiInput.getAbbreviatedAction(),
                    apiInput.getStore().getAddDate(),
                    StringUtils.hasLength(apiInput.getStore().getRemarks7()) ? apiInput.getStore().getRemarks7() : apiInput.getStore().getAddDate(),
                    AFFECTED_PORT_TYPE,
                    StringUtils.hasLength(apiInput.getStore().getRemarks7()) ? apiInput.getStore().getRemarks7() : apiInput.getStore().getAddDate(),
                    PROVIDER_CODE
            ));
        }
    }

    public final <T> FieldErrorMessage notifyAsfe(final T apiRequest) {
        AsNotifyInput input;
        if (apiRequest instanceof ScheduledMaintenanceRequest request) {
            input = AsNotifyInput.builder()
                    .id(Integer.parseInt(request.getStore().getUniqueId()))
                    .outageId(request.getStore().getId())
                    .notifyType(API)
                    .addDate(request.getStore().getAddDate())
                    .action(SCH_MAINT)
                    .createDate(HGCHelper.getFormattedCurrentHongKongDateTime(DATE_TIME_FORMATTER))
                    .createBy(API)
                    .build();
        } else if (apiRequest instanceof OutageStartRequest request) {
            input = AsNotifyInput.builder()
                    .id(Integer.parseInt(request.getStore().getUniqueId()))
                    .outageId(request.getStore().getId())
                    .notifyType(API)
                    .addDate(request.getStore().getAddDate())
                    .action(OUTAGE)
                    .createDate(HGCHelper.getFormattedCurrentHongKongDateTime(DATE_TIME_FORMATTER))
                    .createBy(API)
                    .build();
        } else {
            var request = (OutageEndRequest) apiRequest;
            input = AsNotifyInput.builder()
                    .id(Integer.parseInt(request.getStore().getUniqueId()))
                    .outageId(request.getStore().getId())
                    .notifyType(API)
                    .addDate(request.getStore().getAddDate())
                    .action(RESUME)
                    .createDate(HGCHelper.getFormattedCurrentHongKongDateTime(DATE_TIME_FORMATTER))
                    .createBy(API)
                    .build();
        }
        try {
            return atomsDao.createAsNotify(input);
        } catch (GraphQLMutationException e) {
            return new FieldErrorMessage("500", e.getMessage());
        }
    }

    public <T> FieldErrorMessage updateAsNotificationQueue(final T apiRequest, final String errorMessages) {
        FieldErrorMessage fieldErrorMessage;
        var input = AsNotificationQueueUpdateInput.builder()
                .lastUpdtDate(HGCHelper.getFormattedCurrentHongKongDateTime(DATE_TIME_FORMATTER))
                .lastUpdtBy(API)
                .status(!StringUtils.hasLength(errorMessages) ? "DONE" : "ERROR")
                .build();
        try {
            fieldErrorMessage = atomsDao.updateAsNotificationQueue(((BasicAsFeRequest) apiRequest).getUniqueId(), input);
            if (StringUtils.hasLength(errorMessages)) {
                fieldErrorMessage = new FieldErrorMessage("400", errorMessages);
            }
        } catch (GraphQLMutationException e) {
            return new FieldErrorMessage("500", e.getMessage());
        }
        return fieldErrorMessage;
    }
}
