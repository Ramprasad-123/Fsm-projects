package com.hgc.apihub.callback.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.apihub.callback.exception.asfe.CmhkTokenException;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.BasicQueueListenerRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageEndRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageStartRequest;
import com.hgc.apihub.callback.model.asfe.ProcessScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.apihub.callback.model.asfe.enums.SubType;
import com.hgc.apihub.callback.service.asfe.AsfeService;
import com.hgc.lib.core.exception.GraphQLMutationException;
import com.hgc.lib.microservices.aws.fsm.service.BasicAWSCreatedListener;
import com.hgc.lib.microservices.model.FieldErrorMessage;
import com.hgc.lib.microservices.statemachine.exception.ConditionalCheckFailedException;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.State;
import com.hgc.lib.microservices.statemachine.model.StateData;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.Level;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hgc.apihub.callback.helper.asfe.AsfeHelper.PROCEED_TO_CREATE;
import static com.hgc.apihub.callback.helper.asfe.AsfeHelper.PROCEED_TO_PROCESS;
import static com.hgc.apihub.callback.helper.asfe.AsfeHelper.getSubTypeAsList;
import static com.hgc.apihub.callback.service.asfe.AsfeService.mapCmhkNotifyRequest;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
@RequiredArgsConstructor
public class CreatedListener extends BasicAWSCreatedListener implements AsfeListener {

    private static final String ERROR = "error";
    private AsFeAction action;

    private final AsfeService asfeService;

    @Override
    public final void defaultBindings(final FSMEntity item, final QueueListenerResponse.Builder builder) {
        builder.addBinding(PROCEED_TO_CREATE, false)
                .addBinding(PROCEED_TO_PROCESS, false);
    }

    @Override
    public final StateData deserializeData(final FSMEntity item) throws Exception {
        return OBJECT_MAPPER.readValue(item.getData(), AsfeAsyncStateResponse.class);
    }

    @Override
    public final QueueListenerRequest<? extends QueueListenerBody> deserializeBody(final String body) throws Exception {
        action = AsFeAction.fromValue(JsonPath.parse(body).read("@.body.action"));
        this.messageSupportedCheck(action, List.of(AsFeAction.SCHEDULED_MAINTENANCE, AsFeAction.OUTAGE_START, AsFeAction.OUTAGE_END));
        if (AsFeAction.SCHEDULED_MAINTENANCE == action) {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessScheduledMaintenanceRequest>>() {
            });
        } else if (AsFeAction.OUTAGE_START == action) {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessOutageStartRequest>>() {
            });
        } else {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessOutageEndRequest>>() {
            });
        }
    }

    @Override
    public void executeClean(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) throws CmhkTokenException, GraphQLMutationException {
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "inside created execute clean...action:{}", action);
        switch (action) {
            case SCHEDULED_MAINTENANCE -> executeCleanForScheduledMaintenance(request, builder);
            case OUTAGE_START -> executeCleanForOutageStart(request, builder);
            case OUTAGE_END -> executeCleanForOutageEnd(request, builder);
        }
    }

    private void executeCleanForOutageEnd(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder) throws CmhkTokenException, GraphQLMutationException {
        if (request instanceof BasicQueueListenerRequest<? extends QueueListenerBody>) {
            if (((AsfeAsyncStateResponse) builder.getStateData()).getRemainingSubTypes().equals(getSubTypeAsList(((BasicQueueListenerRequest<? extends QueueListenerBody>) request).getSubTypes()))) {
                var subType = ((BasicQueueListenerRequest<? extends QueueListenerBody>) request).getSubTypes().removeFirst();
                switch (subType) {
                    case CMHK_NOTIFY -> notifyCmhk(request, builder);
                    case AS_NOTIFY -> notifyAsfe(request, builder);
                    case AS_NOTIFICATION_QUEUE -> updateAsNotificationQueue(request, builder);
                    default -> {
                        // do nothing
                    }
                }
            } else {
                this.conditionalCheckFailed(request, builder);
            }
        }
    }

    private void executeCleanForOutageStart(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder) throws CmhkTokenException, GraphQLMutationException {
        if (request instanceof BasicQueueListenerRequest<? extends QueueListenerBody>) {
            if (((AsfeAsyncStateResponse) builder.getStateData()).getRemainingSubTypes().equals(getSubTypeAsList(((BasicQueueListenerRequest<? extends QueueListenerBody>) request).getSubTypes()))) {
                var subType = ((BasicQueueListenerRequest<? extends QueueListenerBody>) request).getSubTypes().removeFirst();
                switch (subType) {
                    case CMHK_NOTIFY -> notifyCmhk(request, builder);
                    case AS_NOTIFY -> notifyAsfe(request, builder);
                    case AS_NOTIFICATION_QUEUE -> updateAsNotificationQueue(request, builder);
                    default -> {
                        // do nothing
                    }
                }
            } else {
                this.conditionalCheckFailed(request, builder);
            }
        }
    }

    private void executeCleanForScheduledMaintenance(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder) throws CmhkTokenException, GraphQLMutationException {
        if (request instanceof BasicQueueListenerRequest<? extends QueueListenerBody>) {
            if (((AsfeAsyncStateResponse) builder.getStateData()).getRemainingSubTypes().equals(getSubTypeAsList(((BasicQueueListenerRequest<? extends QueueListenerBody>) request).getSubTypes()))) {
                var subType = ((BasicQueueListenerRequest<? extends QueueListenerBody>) request).getSubTypes().removeFirst();
                switch (subType) {
                    case CMHK_NOTIFY -> notifyCmhk(request, builder);
                    case AS_NOTIFY -> notifyAsfe(request, builder);
                    case AS_NOTIFICATION_QUEUE -> updateAsNotificationQueue(request, builder);
                    default -> {
                        // do nothing
                    }
                }
            } else {
                this.conditionalCheckFailed(request, builder);
            }
        }
    }

    private void notifyCmhk(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder) {
        var fieldErrorMessages = new ArrayList<FieldErrorMessage>();
        var queueListenerBody = (BasicQueueListenerRequest<? extends QueueListenerBody>) request;
        var stateData = (AsfeAsyncStateResponse) builder.getStateData();
        var isPreviousSubStateSuccess = false;
        switch (action) {
            case SCHEDULED_MAINTENANCE -> {
                if (((ProcessScheduledMaintenanceRequest) request.getBody()).isSuccess()) {
                    isPreviousSubStateSuccess = true;
                    fieldErrorMessages.add(asfeService.notifyCmhk(request, builder, mapCmhkNotifyRequest((ProcessScheduledMaintenanceRequest) request.getBody())));
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(Integer.toString(HttpStatus.BAD_REQUEST.value()), ((ProcessScheduledMaintenanceRequest) request.getBody()).getErrorMessage()));
                }
            }
            case OUTAGE_START -> {
                if (((ProcessOutageStartRequest) request.getBody()).isSuccess()) {
                    isPreviousSubStateSuccess = true;
                    fieldErrorMessages.add(asfeService.notifyCmhk(request, builder, mapCmhkNotifyRequest((ProcessOutageStartRequest) request.getBody())));
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(Integer.toString(HttpStatus.BAD_REQUEST.value()), ((ProcessOutageStartRequest) request.getBody()).getErrorMessage()));
                }
            }
            case OUTAGE_END -> {
                if (((ProcessOutageEndRequest) request.getBody()).isSuccess()) {
                    isPreviousSubStateSuccess = true;
                    fieldErrorMessages.add(asfeService.notifyCmhk(request, builder, mapCmhkNotifyRequest((ProcessOutageEndRequest) request.getBody())));
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(Integer.toString(HttpStatus.BAD_REQUEST.value()), ((ProcessOutageEndRequest) request.getBody()).getErrorMessage()));
                }
            }
        }

        fieldErrorMessages.removeIf(Objects::isNull);
        stateData.setRemainingSubTypes(getSubTypeAsList(queueListenerBody.getSubTypes()));
        builder.addBinding(PROCEED_TO_CREATE, true);
        if (fieldErrorMessages.isEmpty()) {
            this.setForNextState(request, false);
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Notified CMHK for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
        } else if (isPreviousSubStateSuccess) {
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Retrying CMHK notify for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
            stateData.setRemainingSubTypes(Stream.concat(Stream.of(SubType.CMHK_NOTIFY), stateData.getRemainingSubTypes().stream()).toList());
            this.setForRetry(request, queueListenerBody, SubType.CMHK_NOTIFY, fieldErrorMessages);
        } else {
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Retrying ASFE notify expired for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
            this.setForNextState(request, true);
        }
    }

    private void notifyAsfe(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder) {
        var fieldErrorMessages = new ArrayList<FieldErrorMessage>();
        var queueListenerBody = (BasicQueueListenerRequest<? extends QueueListenerBody>) request;
        var stateData = (AsfeAsyncStateResponse) builder.getStateData();
        var isPreviousSubStateSuccess = false;

        switch (action) {
            case SCHEDULED_MAINTENANCE -> {
                if (((ProcessScheduledMaintenanceRequest) request.getBody()).isSuccess()) {
                    isPreviousSubStateSuccess = true;
                    fieldErrorMessages.add(asfeService.notifyAsfe(((ProcessScheduledMaintenanceRequest) request.getBody()).getRequest()));
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(Integer.toString(HttpStatus.BAD_REQUEST.value()), ((ProcessScheduledMaintenanceRequest) request.getBody()).getErrorMessage()));
                }
            }
            case OUTAGE_START -> {
                if (((ProcessOutageStartRequest) request.getBody()).isSuccess()) {
                    isPreviousSubStateSuccess = true;
                    fieldErrorMessages.add(asfeService.notifyAsfe(((ProcessOutageStartRequest) request.getBody()).getRequest()));
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(Integer.toString(HttpStatus.BAD_REQUEST.value()), ((ProcessOutageStartRequest) request.getBody()).getErrorMessage()));
                }
            }
            case OUTAGE_END -> {
                if (((ProcessOutageEndRequest) request.getBody()).isSuccess()) {
                    isPreviousSubStateSuccess = true;
                    fieldErrorMessages.add(asfeService.notifyAsfe(((ProcessOutageEndRequest) request.getBody()).getRequest()));
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(Integer.toString(HttpStatus.BAD_REQUEST.value()), ((ProcessOutageEndRequest) request.getBody()).getErrorMessage()));
                }
            }
        }
        fieldErrorMessages.removeIf(Objects::isNull);
        stateData.setRemainingSubTypes(getSubTypeAsList(queueListenerBody.getSubTypes()));
        builder.addBinding(PROCEED_TO_CREATE, true);
        if (fieldErrorMessages.isEmpty()) {
            this.setForNextState(request, false);
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Notified ASFE for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
        } else if (isPreviousSubStateSuccess) {
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Retrying ASFE notify for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
            stateData.setRemainingSubTypes(Stream.concat(Stream.of(SubType.AS_NOTIFY), stateData.getRemainingSubTypes().stream()).toList());
            this.setForRetry(request, queueListenerBody, SubType.AS_NOTIFY, fieldErrorMessages);
        } else {
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Retrying ASFE notify expired for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
            this.setForLastSubState(request);
        }
    }

    private void updateAsNotificationQueue(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder) {
        var fieldErrorMessages = new ArrayList<FieldErrorMessage>();
        var queueListenerBody = (BasicQueueListenerRequest<? extends QueueListenerBody>) request;
        var stateData = (AsfeAsyncStateResponse) builder.getStateData();
        var isPreviousSubStateSuccess = false;

        switch (action) {
            case SCHEDULED_MAINTENANCE -> {
                if (((ProcessScheduledMaintenanceRequest) request.getBody()).isSuccess()) {
                    fieldErrorMessages.add(asfeService.updateAsNotificationQueue(((ProcessScheduledMaintenanceRequest) request.getBody()).getRequest(), ((ProcessScheduledMaintenanceRequest) request.getBody()).getErrorMessage()));
                    if(!CollectionUtils.isEmpty(fieldErrorMessages)){
                        isPreviousSubStateSuccess = true;
                    }
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(ERROR, ((ProcessScheduledMaintenanceRequest) request.getBody()).getErrorMessage()));
                }
            }
            case OUTAGE_START -> {
                if (((ProcessOutageStartRequest) request.getBody()).isSuccess()) {
                    fieldErrorMessages.add(asfeService.updateAsNotificationQueue(((ProcessOutageStartRequest) request.getBody()).getRequest(), ((ProcessOutageStartRequest) request.getBody()).getErrorMessage()));
                    if(!CollectionUtils.isEmpty(fieldErrorMessages)){
                        isPreviousSubStateSuccess = true;
                    }
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(ERROR, ((ProcessOutageStartRequest) request.getBody()).getErrorMessage()));
                }
            }
            case OUTAGE_END -> {
                if (((ProcessOutageEndRequest) request.getBody()).isSuccess()) {
                    fieldErrorMessages.add(asfeService.updateAsNotificationQueue(((ProcessOutageEndRequest) request.getBody()).getRequest(), ((ProcessOutageEndRequest) request.getBody()).getErrorMessage()));
                    if(!CollectionUtils.isEmpty(fieldErrorMessages)){
                        isPreviousSubStateSuccess = true;
                    }
                } else {
                    fieldErrorMessages.add(new FieldErrorMessage(ERROR, ((ProcessOutageEndRequest) request.getBody()).getErrorMessage()));

                }
            }
        }

        fieldErrorMessages.removeIf(Objects::isNull);
        stateData.setRemainingSubTypes(getSubTypeAsList(queueListenerBody.getSubTypes()));
        if (fieldErrorMessages.isEmpty()) {
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "AsNotificationQueue updated for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
            builder.addBinding(PROCEED_TO_PROCESS, true);
        } else if (isPreviousSubStateSuccess) {
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "Retrying for AsNotificationQueue updated for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
            stateData.setRemainingSubTypes(List.of(SubType.AS_NOTIFICATION_QUEUE));
            builder.addBinding(PROCEED_TO_CREATE, true);
            this.setForRetry(request, queueListenerBody, SubType.AS_NOTIFICATION_QUEUE, fieldErrorMessages);
        } else {
            this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "AsNotificationQueue updated and send to rejected for {} with transaction id {} and event id {}", action, request.getTransactionId(), request.getEventId());
            this.rejectedStateData(request.getTransactionId(), request.getEventId(), action, fieldErrorMessages, builder, this.getLOGGER());
        }
    }

    private void setForNextState(final QueueListenerRequest<? extends QueueListenerBody> request, final boolean isWithError) {
        switch (action) {
            case SCHEDULED_MAINTENANCE -> {
                var requestBody = (ProcessScheduledMaintenanceRequest) request.getBody();
                requestBody.setSuccess(!isWithError);
            }
            case OUTAGE_START -> {
                var requestBody = (ProcessOutageStartRequest) request.getBody();
                requestBody.setSuccess(!isWithError);
            }
            case OUTAGE_END -> {
                var requestBody = (ProcessOutageEndRequest) request.getBody();
                requestBody.setSuccess(!isWithError);
            }
        }
    }

    private void setForLastSubState(final QueueListenerRequest<? extends QueueListenerBody> request) {
        switch (action) {
            case SCHEDULED_MAINTENANCE -> {
                var requestBody = (ProcessScheduledMaintenanceRequest) request.getBody();
                requestBody.setSuccess(true);
                requestBody.setRetryCount(0);
            }
            case OUTAGE_START -> {
                var requestBody = (ProcessOutageStartRequest) request.getBody();
                requestBody.setSuccess(true);
                requestBody.setRetryCount(0);
            }
            case OUTAGE_END -> {
                var requestBody = (ProcessOutageEndRequest) request.getBody();
                requestBody.setSuccess(true);
                requestBody.setRetryCount(0);
            }
        }
    }

    private void setForRetry(final QueueListenerRequest<? extends QueueListenerBody> request, BasicQueueListenerRequest<?> queueListenerBody, final SubType subTypeToRetry, final ArrayList<FieldErrorMessage> fieldErrorMessages) {
        switch (action) {
            case SCHEDULED_MAINTENANCE -> {
                var requestBody = (ProcessScheduledMaintenanceRequest) request.getBody();
                requestBody.setSuccess(false);
                requestBody.setErrorMessage(fieldErrorMessages.stream().map(FieldErrorMessage::getMessage).collect(Collectors.joining(",")));
                queueListenerBody.getSubTypes().addFirst(subTypeToRetry);
                if (requestBody.getRetryCount() < 5 && contains5xx(fieldErrorMessages)) {
                    requestBody.setSuccess(true);
                    requestBody.setRetryCount(requestBody.getRetryCount() + 1);
                }
            }
            case OUTAGE_START -> {
                var requestBody = (ProcessOutageStartRequest) request.getBody();
                requestBody.setSuccess(false);
                requestBody.setErrorMessage(fieldErrorMessages.stream().map(FieldErrorMessage::getMessage).collect(Collectors.joining(",")));
                queueListenerBody.getSubTypes().addFirst(subTypeToRetry);
                if (requestBody.getRetryCount() < 5 && contains5xx(fieldErrorMessages)) {
                    requestBody.setSuccess(true);
                    requestBody.setRetryCount(requestBody.getRetryCount() + 1);
                }
            }
            case OUTAGE_END -> {
                var requestBody = (ProcessOutageEndRequest) request.getBody();
                requestBody.setSuccess(false);
                requestBody.setErrorMessage(fieldErrorMessages.stream().map(FieldErrorMessage::getMessage).collect(Collectors.joining(",")));
                queueListenerBody.getSubTypes().addFirst(subTypeToRetry);
                if (requestBody.getRetryCount() < 5 && contains5xx(fieldErrorMessages)) {
                    requestBody.setSuccess(true);
                    requestBody.setRetryCount(requestBody.getRetryCount() + 1);
                }
            }
        }
    }

    @Override
    public void executeDirty(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) {

    }

    private void conditionalCheckFailed(final QueueListenerRequest<? extends QueueListenerBody> request, final QueueListenerResponse.Builder builder) {
        var node = this.getNodeByState(State.CREATED.name());
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.ERROR, "[{} Queue] cannot execute the sate again for transaction id {} and event id {}, send request to {} Queue", node.getQueueName(), request.getTransactionId(),
                request.getEventId(), node.getDeadLetterQueueName());
        this.getFSMMessagingTemplate().convertAndSend(node.getDeadLetterQueueName(), request);
        this.acknowledgeMessage();
        throw new ConditionalCheckFailedException("Possibly a duplicate message!");
    }

    private static boolean contains5xx(final ArrayList<FieldErrorMessage> fieldErrorMessages) {
        return fieldErrorMessages.stream().anyMatch(fieldErrorMessageValue -> Objects.requireNonNull(HttpStatus.resolve(Integer.parseInt(fieldErrorMessageValue.getField()))).is5xxServerError());
    }
}
