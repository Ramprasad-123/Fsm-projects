package com.hgc.apihub.fsmadapter.controller;

import com.hgc.apihub.fsmadapter.exception.AdapterExceptionHandlerType;
import com.hgc.apihub.fsmadapter.model.DynamoDBRequest;
import com.hgc.apihub.fsmadapter.service.DynamoDBService;
import com.hgc.lib.microservices.exception.SanitizedExceptionHandler;
import com.hgc.lib.microservices.model.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import software.amazon.awssdk.services.dynamodb.model.ResourceNotFoundException;

import static com.hgc.apihub.fsmadapter.AdapterTestHelper.*;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@WebMvcTest(DynamoDBController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@Import(SanitizedExceptionHandler.class)
public class DynamoDBControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DynamoDBService dynamoDBService;

    @Test
    void patchDynamoDB() throws Throwable {
        // arrange
        BDDMockito.given(dynamoDBService.patchDynamoDB(Mockito.any(DynamoDBRequest.class))).willReturn(new Response(HttpStatus.OK));
        // act
        mockMvc.perform(MockMvcRequestBuilders.patch("/v1/dynamodb")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getDynamoDBRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(200))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void patchDynamoDBTableNotFound() throws Throwable {
        // arrange
        BDDMockito.given(dynamoDBService.patchDynamoDB(Mockito.any(DynamoDBRequest.class))).willThrow(ResourceNotFoundException.builder().message("test").build());
        // act
        mockMvc.perform(MockMvcRequestBuilders.patch("/v1/dynamodb")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(OBJECT_MAPPER.writeValueAsString(getDynamoDBRequest())))
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.jsonPath("@.code").value(AdapterExceptionHandlerType.ResourceNotFoundException.getCode()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.reason").value(AdapterExceptionHandlerType.ResourceNotFoundException.getReason()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.message").value(AdapterExceptionHandlerType.ResourceNotFoundException.getMessage()))
                .andExpect(MockMvcResultMatchers.jsonPath("@.status").value(AdapterExceptionHandlerType.ResourceNotFoundException.getStatus().value()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
}
