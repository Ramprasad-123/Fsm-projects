#!/bin/bash

aws dynamodb create-table --table-name keydb-a3e-test-fsm-lock --attribute-definitions AttributeName=key,AttributeType=S --key-schema AttributeName=key,KeyType=HASH --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=5 --region ap-southeast-1

aws dynamodb create-table --table-name keydb-a3e-test-fsm --attribute-definitions AttributeName=transaction_id,AttributeType=S AttributeName=event_id,AttributeType=S --key-schema AttributeName=transaction_id,KeyType=HASH AttributeName=event_id,KeyType=RANGE --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=5 --region ap-southeast-1

aws dynamodb put-item --table-name keydb-a3e-statenode --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "ACCEPTED"}, "sqs_name": {"S": "pubsub-a3n-test-fsm-accept"}, "sqs_dlq_name": {"S": "pubsub-a3n-test-fsm-dlq"}, "entry_node": {"BOOL": true}}' --region ap-southeast-1
aws dynamodb put-item --table-name keydb-a3e-statenode --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "VALIDATED"}, "sqs_name": {"S": "pubsub-a3n-test-fsm-validate"}, "sqs_dlq_name": {"S": "pubsub-a3n-test-fsm-dlq"}}' --region ap-southeast-1
aws dynamodb put-item --table-name keydb-a3e-statenode --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "CUSTOM"}, "sqs_name": {"S": "pubsub-a3n-test-fsm-custom.fifo"}, "sqs_dlq_name": {"S": "pubsub-a3n-test-fsm-dlq.fifo"}}' --region ap-southeast-1
aws dynamodb put-item --table-name keydb-a3e-statenode --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "PROCESSED"}, "sqs_name": {"S": "pubsub-a3n-test-fsm-process"}, "sqs_dlq_name": {"S": "pubsub-a3n-test-fsm-dlq"}}' --region ap-southeast-1
aws dynamodb put-item --table-name keydb-a3e-statenode --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "DELIVERED"}, "sqs_name": {"S": "pubsub-a3n-test-fsm-deliver"}, "sqs_dlq_name": {"S": "pubsub-a3n-test-fsm-dlq"}}' --region ap-southeast-1

aws dynamodb put-item --table-name keydb-a3e-stateedge --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "ACCEPTED"}, "to_states": {"S": "VALIDATED"}}' --region ap-southeast-1
aws dynamodb put-item --table-name keydb-a3e-stateedge --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "VALIDATED"}, "to_states": {"S": "CUSTOM"}, "weights": {"S": "[{\"expression\":\"return success\",\"bindings\":{\"success\":true}}]"}}' --region ap-southeast-1
aws dynamodb put-item --table-name keydb-a3e-stateedge --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "CUSTOM"}, "to_states": {"S": "PROCESSED"}}' --region ap-southeast-1
aws dynamodb put-item --table-name keydb-a3e-stateedge --item '{"project_name": {"S": "test-fsm"}, "state": {"S": "PROCESSED"}, "to_states": {"S": "DELIVERED"}, "weights": {"S": "[{\"expression\":\"return proceed_to_delivery\",\"bindings\":{\"proceed_to_delivery\":true}}]"}}' --region ap-southeast-1