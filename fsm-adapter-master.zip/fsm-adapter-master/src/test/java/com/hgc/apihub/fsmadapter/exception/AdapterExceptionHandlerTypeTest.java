package com.hgc.apihub.fsmadapter.exception;

import com.hgc.lib.core.exception.ResourceNotFoundException;
import io.awspring.cloud.sqs.operations.MessagingOperationFailedException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpStatus;
import software.amazon.awssdk.services.sqs.model.QueueDoesNotExistException;

import java.util.stream.Stream;

class AdapterExceptionHandlerTypeTest {

    @ParameterizedTest
    @MethodSource("provideArguments")
    void exceptionHandlerType(AdapterExceptionHandlerType type, String code, String reason, String message, HttpStatus status) {
        Assertions.assertEquals(code, type.getCode());
        Assertions.assertEquals(reason, type.getReason());
        Assertions.assertEquals(message, type.getMessage());
        Assertions.assertEquals(status, type.getStatus());
    }

    private static Stream<Arguments> provideArguments() {
        return Stream.of(
                Arguments.of(AdapterExceptionHandlerType.QueueDoesNotExistException, "ADP-40401", "Message Queue Does Not Exist", "The queue you are trying to send message to does not exist. Please try again with valid message queue.", HttpStatus.NOT_FOUND),
                Arguments.of(AdapterExceptionHandlerType.ResourceNotFoundException, "ADP-40402", "Resource not found", "The resource you queried does not exist. Please try again with valid values.", HttpStatus.NOT_FOUND),
                Arguments.of(AdapterExceptionHandlerType.MessagingOperationFailedException, "ADP-50001", "Messaging Operation Failed", "The messaging operation you are trying failed. Please try again after some time.", HttpStatus.INTERNAL_SERVER_ERROR)
        );
    }

    @Test
    void fromExceptionClass() {
        // arrange
        Assertions.assertEquals(AdapterExceptionHandlerType.QueueDoesNotExistException, AdapterExceptionHandlerType.fromExceptionClass(QueueDoesNotExistException.class));
        Assertions.assertEquals(AdapterExceptionHandlerType.ResourceNotFoundException, AdapterExceptionHandlerType.fromExceptionClass(ResourceNotFoundException.class));
        Assertions.assertEquals(AdapterExceptionHandlerType.ResourceNotFoundException, AdapterExceptionHandlerType.fromExceptionClass(software.amazon.awssdk.services.dynamodb.model.ResourceNotFoundException.class));
        Assertions.assertEquals(AdapterExceptionHandlerType.MessagingOperationFailedException, AdapterExceptionHandlerType.fromExceptionClass(MessagingOperationFailedException.class));
        Assertions.assertNull(AdapterExceptionHandlerType.fromExceptionClass(IllegalArgumentException.class));
        Assertions.assertNull(AdapterExceptionHandlerType.fromExceptionClass(null));
    }
}
