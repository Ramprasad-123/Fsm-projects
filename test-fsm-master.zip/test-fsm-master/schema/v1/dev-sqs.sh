#!/bin/bash

~/.local/bin/aws sqs create-queue --queue-name test-fsm-dlq --endpoint-url http://localhost:9324
~/.local/bin/aws sqs create-queue --queue-name test-fsm-dlq.fifo --attributes '{"FifoQueue": "true", "ContentBasedDeduplication": "true"}' --endpoint-url http://localhost:9324

~/.local/bin/aws sqs create-queue --queue-name test-fsm-accept --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"test-fsm-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324
~/.local/bin/aws sqs create-queue --queue-name test-fsm-validate --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"test-fsm-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324
~/.local/bin/aws sqs create-queue --queue-name test-fsm-custom.fifo --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"test-fsm-dlq.fifo\",\"maxReceiveCount\":\"5\"}", "FifoQueue": "true", "ContentBasedDeduplication": "true"}' --endpoint-url http://localhost:9324
~/.local/bin/aws sqs create-queue --queue-name test-fsm-process --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"test-fsm-dlq\",\"maxReceiveCount\":\"5\"}"}' --endpoint-url http://localhost:9324
~/.local/bin/aws sqs create-queue --queue-name test-fsm-deliver --attributes '{"RedrivePolicy": "{\"deadLetterTargetArn\":\"test-fsm-dlq\",\"maxReceiveCount\":\"3\"}"}' --endpoint-url http://localhost:9324