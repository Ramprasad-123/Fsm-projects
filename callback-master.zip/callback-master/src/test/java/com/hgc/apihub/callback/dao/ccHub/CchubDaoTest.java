package com.hgc.apihub.callback.dao.ccHub;

import com.apollographql.apollo.api.Error;
import com.apollographql.apollo.api.Response;
import com.hgc.apihub.callback.exception.ccHub.CcHubDeleteOperationFailException;
import com.hgc.apihub.callback.exception.ccHub.CcHubNotFoundException;
import com.hgc.apihub.callback.exception.ccHub.GraphQLMutationException;
import com.hgc.apihub.graphqlcc.queries.CreateCcHubMutation;
import com.hgc.apihub.graphqlcc.queries.DeleteCcHubMutation;
import com.hgc.apihub.graphqlcc.queries.ReadCcHubsQuery;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.hgc.apihub.callback.HubTestHelper.getCcHuQueryData;
import static com.hgc.apihub.callback.HubTestHelper.getCreateCcHubMutation;
import static com.hgc.apihub.callback.HubTestHelper.getDeleteCcHubMutation;
import static com.hgc.apihub.callback.HubTestHelper.getHubRequest;

@ContextConfiguration(classes = CchubDao.class)
@SpringBootTest
@ExtendWith(SpringExtension.class)
public class CchubDaoTest {

    @MockBean
    private GraphQLTemplate graphQLTemplate;

    @MockBean
    private Response<Optional<CreateCcHubMutation.Data>> ccHubMutationData;

    @MockBean
    private Response<Optional<DeleteCcHubMutation.Data>> ccHubDeleteMutationData;

    @MockBean
    private Response<Optional<ReadCcHubsQuery.Data>> ccHubsQueryData;

    private CchubDao cchubDao;

    @BeforeEach
    void setup() {
        var serviceToSpy = new CchubDao(graphQLTemplate);
        cchubDao = Mockito.spy(serviceToSpy);
    }

    @Test
    void createHubTest() throws GraphQLMutationException {

        // arrange
        Mockito.when(ccHubMutationData.data()).thenReturn(Optional.of(getCreateCcHubMutation()));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(CreateCcHubMutation.class))).thenReturn(ccHubMutationData);

        // act
        var response = cchubDao.createHub("123", getHubRequest());

        // assert
        Assertions.assertNotNull(response);
    }

    @Test
    void createHubExceptionTest() {

        // arrange
        var errors = List.of(new Error("Test error", List.of(new Error.Location(0L, 0L)), Map.of("test", "test")));
        Mockito.when(ccHubMutationData.hasErrors()).thenReturn(true);
        Mockito.when(ccHubMutationData.errors()).thenReturn(errors);
        Mockito.when(graphQLTemplate.mutation(Mockito.any(CreateCcHubMutation.class))).thenReturn(ccHubMutationData);

        // act
        var thrown = Assertions.assertThrows(Exception.class, () ->
                cchubDao.createHub("123", getHubRequest()));

        // assert
        Assertions.assertNotNull(thrown);
    }

    @Test
    void deleteHubTest() throws CcHubNotFoundException, CcHubDeleteOperationFailException, GraphQLMutationException {

        // arrange
        Mockito.when(ccHubDeleteMutationData.data()).thenReturn(Optional.of(getDeleteCcHubMutation()));
        Mockito.when(graphQLTemplate.mutation(Mockito.any(DeleteCcHubMutation.class))).thenReturn(ccHubDeleteMutationData);

        // act
        var response = cchubDao.deleteHub("123");

        // assert
        Assertions.assertNotNull(response);

    }

    @Test
    void deleteHubCcHubNotFoundException() {

        // arrange
        var errors = List.of(new Error("No hub with id 123 exists!", List.of(new Error.Location(0L, 0L)), Map.of("test", "test")));
        Mockito.when(ccHubDeleteMutationData.hasErrors()).thenReturn(true);
        Mockito.when(ccHubDeleteMutationData.getErrors()).thenReturn(errors);
        Mockito.when(graphQLTemplate.mutation(Mockito.any(DeleteCcHubMutation.class))).thenReturn(ccHubDeleteMutationData);

        // act
        var thrown = Assertions.assertThrows(CcHubNotFoundException.class, () ->
                cchubDao.deleteHub("123"));

        // assert
        Assertions.assertNotNull(thrown);
    }

    @Test
    void deleteHubCcHubDeleteOperationFailException() {

        // arrange
        var errors = List.of(new Error("Test error", List.of(new Error.Location(0L, 0L)), Map.of("test", "test")));
        Mockito.when(ccHubDeleteMutationData.hasErrors()).thenReturn(true);
        Mockito.when(ccHubDeleteMutationData.getErrors()).thenReturn(errors);
        Mockito.when(graphQLTemplate.mutation(Mockito.any(DeleteCcHubMutation.class))).thenReturn(ccHubDeleteMutationData);

        // act
        var thrown = Assertions.assertThrows(CcHubDeleteOperationFailException.class, () ->
                cchubDao.deleteHub("123"));

        // assert
        Assertions.assertNotNull(thrown);
    }

    @Test
    void getHubListTest() throws GraphQLMutationException {

        // arrange
        var test = getCcHuQueryData();
        Mockito.when(ccHubsQueryData.getData()).thenReturn(Optional.of(getCcHuQueryData()));
        Mockito.when(graphQLTemplate.query(Mockito.any(ReadCcHubsQuery.class))).thenReturn(ccHubsQueryData);

        // act
        var response = cchubDao.getHubList(1, 10);

        // assert
        Assertions.assertNotNull(response);
    }

    @Test
    void getHubListExceptionTest() {

        // arrange
        var errors = List.of(new Error("Test error", List.of(new Error.Location(0L, 0L)), Map.of("test", "test")));
        Mockito.when(ccHubsQueryData.hasErrors()).thenReturn(true);
        Mockito.when(ccHubsQueryData.errors()).thenReturn(errors);
        Mockito.when(graphQLTemplate.query(Mockito.any(ReadCcHubsQuery.class))).thenReturn(ccHubsQueryData);

        // act
        var thrown = Assertions.assertThrows(Exception.class, () ->
                cchubDao.getHubList(1, 10));

        // assert
        Assertions.assertNotNull(thrown);
    }
}
