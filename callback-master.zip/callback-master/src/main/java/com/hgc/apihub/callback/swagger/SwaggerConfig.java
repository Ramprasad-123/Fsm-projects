package com.hgc.apihub.callback.swagger;

import com.hgc.lib.microservices.swagger.AbstractSwaggerConfig;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig extends AbstractSwaggerConfig {

    @Bean
    public GroupedOpenApi publicApi() {
        // optional if needed to group and filter by paths or package or both or none
        return GroupedOpenApi.builder()
                .group("callback")
                .packagesToScan("com.hgc.apihub.callback.controller.ccHub", "com.hgc.apihub.callback.controller.asfe")
                .addOpenApiCustomiser(this.openApiCustomiser())
                .build();
    }

    @Override
    public final String apiInfoDescription() {
        return "Callback service build on spring boot for HGC";
    }
}


