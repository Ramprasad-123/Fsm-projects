package com.hgc.apihub.fsmadapter.configuration;

import io.lettuce.core.ClientOptions;
import io.lettuce.core.SocketOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.util.StringUtils;

import java.time.Duration;

/**
 * Redis async configuration.
 *
 * @author soorajm
 */
@Configuration
@EnableRedisRepositories
public class RedisAsyncConfiguration {

    @Value("${spring.redis.host}")
    private String redisHost;

    @Value("${spring.redis.port}")
    private Integer redisPort;

    @Value("${spring.redis.password:#{null}}")
    private String password;

    @Value("${spring.redis.ssl:false}")
    private boolean useSsl;

    @Value("${spring.redis.connectTimeout:10}")
    private int connectTimeout;

    /**
     * Get lettuce connection factory.
     *
     * @return lettuce connection factory
     */
    @Bean
    public LettuceConnectionFactory redisConnectionFactory() {
        var config = new RedisStandaloneConfiguration(redisHost, redisPort);
        if (StringUtils.hasText(password)) {
            config.setPassword(RedisPassword.of(password));
        }
        var clientConfig = LettuceClientConfiguration.builder().clientOptions(ClientOptions.builder().socketOptions(SocketOptions.builder().connectTimeout(Duration.ofSeconds(connectTimeout)).build()).build());
        if (useSsl) {
            clientConfig.useSsl();
        }
        return new LettuceConnectionFactory(config, clientConfig.build());
    }

    /**
     * Get cached redis template
     *
     * @param lettuceConnectionFactory the lettuce connection factory
     * @return cached redis template
     */
    @Bean
    public StringRedisTemplate redisTemplate(final LettuceConnectionFactory lettuceConnectionFactory) {
        var redisTemplate = new StringRedisTemplate();
        redisTemplate.setConnectionFactory(lettuceConnectionFactory);
        return redisTemplate;
    }
}
