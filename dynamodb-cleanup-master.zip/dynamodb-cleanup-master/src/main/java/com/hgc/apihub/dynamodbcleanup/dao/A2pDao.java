package com.hgc.apihub.dynamodbcleanup.dao;

import com.hgc.apihub.dynamodbcleanup.model.MessageResult;
import com.hgc.lib.graphql.client.GraphQLTemplate;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.exception.GraphQLQueryException;
import com.hgc.queries.ReadSmsMessageResultsQuery;
import com.hgc.type.Criteria;
import com.hgc.type.FilterParameter;
import com.hgc.type.Operator;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor
public class A2pDao {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(A2pDao.class);

    private final GraphQLTemplate a2pGraphQLTemplate;

    private static final String CREATE_DATE = "createDate";

    public ArrayList<MessageResult> getRecords(String startDate, String endDate) throws GraphQLQueryException {
        ArrayList<MessageResult> resultList = new ArrayList<>();
        ArrayList<FilterParameter> filterParamList = new ArrayList<>();

        filterParamList.add(FilterParameter.builder()
                .field(CREATE_DATE)
                .criteria(Criteria.GREATER_THAN_OR_EQUAL_TO)
                .values(List.of(startDate))
                .operator(Operator.AND)
                .build());
        filterParamList.add(FilterParameter.builder()
                .field(CREATE_DATE)
                .criteria(Criteria.LESS_THAN_OR_EQUAL_TO)
                .values(List.of(endDate))
                .operator(Operator.AND)
                .build());
        var query = ReadSmsMessageResultsQuery.builder()
                .filters(filterParamList)
                .withTransactionId(true)
                .withCreateDate(true)
                .build();
        var queryResponse = a2pGraphQLTemplate.query(query);
        if (queryResponse.hasErrors()) {
            LOGGER.unify(Level.ERROR, "ReadSmsMessageResultsQuery GraphQL receives error response: " + queryResponse.getErrors());
            throw new GraphQLQueryException("An error occurred while querying to GraphQL Server. Please try again after some time.");
        }
        var queryResult = Optional.ofNullable(queryResponse.getData()).stream()
                .flatMap(Optional::stream)
                .map(ReadSmsMessageResultsQuery.Data::getReadSmsMessageResults)
                .flatMap(Optional::stream)
                .map(ReadSmsMessageResultsQuery.ReadSmsMessageResults::getFragments)
                .findFirst()
                .stream()
                .map(ReadSmsMessageResultsQuery.ReadSmsMessageResults.Fragments::getSmsMessageResultsFields)
                .findAny();
        if (queryResult.isPresent() && queryResult.get().getSmsMessageResults().isPresent() && !CollectionUtils.isEmpty(queryResult.get().getSmsMessageResults().get())) {
            for (var a : queryResult.get().getSmsMessageResults().get()) {
                var messageResult = new MessageResult();
                var fragments = a.getFragments().getSmsMessageResultFields();
                messageResult.setTransactionId(fragments.getTransactionId().orElse(null));
                messageResult.setCreateDate(fragments.getCreateDate().orElse(null));
                resultList.add(messageResult);
            }
        }
        return resultList;
    }
}
