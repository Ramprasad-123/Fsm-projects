package com.hgc.apihub.fsmadapter.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.lib.microservices.model.AuthType;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import org.hibernate.validator.constraints.URL;

import java.util.Objects;

import static com.hgc.apihub.fsmadapter.AdapterHelper.RETRY_AFTER;
import static com.hgc.apihub.fsmadapter.AdapterHelper.RETRY_AFTER_SWAGGER_EXAMPLE;

@Getter
@Schema(description = "Initiate message request body")
public class InitiateMessageRequest extends MessageRequest {

    @NotBlank
    @JsonProperty("table_name")
    @Schema(description = "Table name", requiredMode = Schema.RequiredMode.REQUIRED, example = "test_fsm")
    private final String tableName;

    @URL
    @JsonProperty("callback_url")
    @Schema(description = "Callback URL", example = "http://test.com/notification")
    private final String callbackUrl;

    @JsonProperty("callback_auth_type")
    @Schema(description = "Callback Auth Type", example = "BASIC")
    private final AuthType callbackAuthType;

    @JsonProperty("callback_auth_secret")
    @Schema(description = "Callback Auth Secret", example = "test")
    private final String callbackAuthSecret;

    @JsonProperty("retry_after")
    @Schema(description = "Retry polling after stated duration. Defaults to " + RETRY_AFTER + " seconds", example = RETRY_AFTER_SWAGGER_EXAMPLE)
    private final Integer retryAfter;

    @URL
    @JsonProperty("self_link")
    @Schema(description = "FSM self link", example = "http://test.com")
    private final String selfLink;

    public InitiateMessageRequest(@JsonProperty("body") final String body, @JsonProperty("queue_name") final String queueName, @JsonProperty("table_name") final String tableNameValue,
                                  @JsonProperty("callback_url") final String callbackUrlValue, @JsonProperty("callback_auth_type") final AuthType callbackAuthTypeEnum,
                                  @JsonProperty("callback_auth_secret") final String callbackAuthSecretValue, @JsonProperty("retry_after") final Integer retryAfterValue,
                                  @JsonProperty("self_link") final String selfLinkValue) {
        super(body, queueName);
        this.tableName = tableNameValue;
        this.callbackUrl = callbackUrlValue;
        this.callbackAuthType = callbackAuthTypeEnum;
        this.callbackAuthSecret = callbackAuthSecretValue;
        this.retryAfter = Objects.requireNonNullElse(retryAfterValue, RETRY_AFTER);
        this.selfLink = selfLinkValue;
    }
}
