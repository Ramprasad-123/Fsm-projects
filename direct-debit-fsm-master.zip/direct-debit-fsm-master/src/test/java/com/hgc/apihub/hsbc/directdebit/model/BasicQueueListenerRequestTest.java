package com.hgc.apihub.hsbc.directdebit.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class BasicQueueListenerRequestTest {

    @Test
    void mapping() {
        // arrange
        var request = new BasicQueueListenerRequest<>("ID0000021", "ID0000022", "ID0000023", "TEST", "test-queue", null, "123");
        // assert
        Assertions.assertNotNull(request);
        // act
        request = new BasicQueueListenerRequest<>(request, null);
        // assert
        Assertions.assertNotNull(request);
        Assertions.assertEquals("ID0000021", request.getTransactionId());
        Assertions.assertEquals("ID0000022", request.getEventId());
        Assertions.assertEquals("123", request.getProfileId());
        // arrange
        request = new BasicQueueListenerRequest<>("ID0000021", null, DirectDebitType.AUTHORIZATION_INITIATE, "123");
        // assert
        Assertions.assertNotNull(request);
        Assertions.assertEquals(DirectDebitType.AUTHORIZATION_INITIATE, request.getType());
    }
}
