package com.hgc.apihub.callback;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import lombok.Builder;
import lombok.Generated;

@Generated
@Builder
public class TestQueueListener implements QueueListenerBody {
    @JsonProperty("action")
    private final String action;
}
