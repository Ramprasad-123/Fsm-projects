package com.hgc.apihub.callback.model.ccHub;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author Wai Yan Oo on 5/11/20
 */

@RequiredArgsConstructor
@Getter
@Schema(description = "Hub creation request body")
@AllArgsConstructor
public class HubRequest implements Serializable {

//    @NotNull
//    @JsonProperty(value = "apim_x_user_id")
//    @ApiModelProperty(notes = "Apim X User Id", position = 1, example = "")
//    private String apimXUserId;

    @NotNull
    @JsonProperty(value = "query")
    @Schema(description = "This attribute is used to define notification type. Example: \",\"query\":”eventType = QuoteStateChangeNotification”}", example = "")
    private String query;

    @NotNull
    @JsonProperty(value = "callback")
    @Schema(description = "This attribute is the callback url where event will be sent when occurs, for instance an url http://yourdomain/listener/api/v1/event", example = "")
    private String callback;

    @NotNull
    @JsonProperty(value = "create_by")
    @Schema(description = "User Who create this entity.", example = "")
    private String createBy;
}
