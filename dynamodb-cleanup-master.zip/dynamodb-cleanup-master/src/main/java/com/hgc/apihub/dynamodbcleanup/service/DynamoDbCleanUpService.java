package com.hgc.apihub.dynamodbcleanup.service;

import com.hgc.apihub.dynamodbcleanup.dao.A2pDao;
import com.hgc.apihub.dynamodbcleanup.dao.TnssFbiDao;
import com.hgc.apihub.dynamodbcleanup.dao.dynamoDb.DynamoDbA2pSmsDao;
import com.hgc.apihub.dynamodbcleanup.dao.dynamoDb.DynamoDbTnssIntegrationDao;
import com.hgc.apihub.dynamodbcleanup.model.DynamoDbOperationResponse;
import com.hgc.apihub.dynamodbcleanup.model.MessageResult;
import com.hgc.apihub.dynamodbcleanup.model.TableName;
import com.hgc.apihub.dynamodbcleanup.model.ZuoraApiLog;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.exception.GraphQLQueryException;
import com.hgc.lib.microservices.model.Response;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;

@Service
@RequiredArgsConstructor
public class DynamoDbCleanUpService {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(DynamoDbCleanUpService.class);

    private final DynamoDbA2pSmsDao dynamoDbA2pSmsDao;
    private final DynamoDbTnssIntegrationDao dynamoDbTnssIntegrationDao;
    private final TnssFbiDao tnssFbiDao;
    private final A2pDao a2pDao;

    public final Response deleteRecords(final String startDate, final String endDate, final String tableName) throws GraphQLQueryException {
        var response = new DynamoDbOperationResponse(200, "");
        ArrayList<ZuoraApiLog> tnssRecordsToDelete = new ArrayList<>();
        ArrayList<MessageResult> a2pRecordsToDelete = new ArrayList<>();

        var transactionIdsToDelete = new ArrayList<String>();

        LOGGER.unify(Level.INFO, "Cleaning up data ...");

        if (TableName.tnssintegration.name().equalsIgnoreCase(tableName)) {
            LOGGER.unify(Level.INFO, "Getting data from zuora_api_logs(tnss-integration) from {} to {}", startDate, endDate);
            tnssRecordsToDelete = tnssFbiDao.getRecords(startDate, endDate);
        } else {
            LOGGER.unify(Level.INFO, "Getting data from message_result(a2p) from {} to {}", startDate, endDate);
            a2pRecordsToDelete = a2pDao.getRecords(startDate, endDate);
        }

        if (!CollectionUtils.isEmpty(tnssRecordsToDelete) || (!CollectionUtils.isEmpty(a2pRecordsToDelete))) {

            if (TableName.tnssintegration.name().equalsIgnoreCase(tableName)) {
                LOGGER.unify(Level.INFO, "Data found, proceeding to delete data from {} to {}, item count={}", startDate, endDate, tnssRecordsToDelete.size());
                // Get transaction ids
                for (ZuoraApiLog l : tnssRecordsToDelete) {
                    transactionIdsToDelete.add(l.getApiTransactionId());
                }
                // Pass to dao to fetch eventIds and do batch delete.
                response = dynamoDbTnssIntegrationDao.deleteRecords(transactionIdsToDelete);
            } else {
                LOGGER.unify(Level.INFO, "Data found, proceeding to delete data from {} to {}, item count={}", startDate, endDate, a2pRecordsToDelete.size());
                // Get transaction ids
                for (MessageResult l : a2pRecordsToDelete) {
                    if (StringUtils.isNotEmpty(l.getTransactionId())) {
                        transactionIdsToDelete.add(l.getTransactionId());
                    }
                }

                // Pass to dao to fetch eventIds and do batch delete.
                response = dynamoDbA2pSmsDao.deleteRecords(transactionIdsToDelete);
            }
        } else {
            var message = "No data to delete from for this range";
            LOGGER.unify(Level.INFO, message);
            response.setMessage(message);
        }
        return response;
    }
}
