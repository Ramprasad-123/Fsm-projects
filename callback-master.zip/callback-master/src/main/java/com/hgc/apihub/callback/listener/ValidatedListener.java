package com.hgc.apihub.callback.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.hgc.apihub.callback.model.asfe.AsfeAsyncStateResponse;
import com.hgc.apihub.callback.model.asfe.BasicQueueListenerRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageEndRequest;
import com.hgc.apihub.callback.model.asfe.ProcessOutageStartRequest;
import com.hgc.apihub.callback.model.asfe.ProcessScheduledMaintenanceRequest;
import com.hgc.apihub.callback.model.asfe.enums.AsFeAction;
import com.hgc.lib.logging.LoggerWrapper;
import com.hgc.lib.microservices.aws.fsm.service.BasicAWSValidatedListener;
import com.hgc.lib.microservices.statemachine.model.FSMEntity;
import com.hgc.lib.microservices.statemachine.model.QueueListenerBody;
import com.hgc.lib.microservices.statemachine.model.QueueListenerRequest;
import com.hgc.lib.microservices.statemachine.model.StateData;
import com.hgc.lib.microservices.statemachine.service.QueueListenerResponse;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.hgc.apihub.callback.helper.asfe.AsfeHelper.PROCEED;
import static com.hgc.lib.microservices.MicroservicesHelper.OBJECT_MAPPER;

@Service
@RequiredArgsConstructor
public class ValidatedListener extends BasicAWSValidatedListener implements AsfeListener {

    private static final LoggerWrapper LOGGER = LoggerWrapper.create(ValidatedListener.class);

    private AsFeAction action;

    @Override
    public final void defaultBindings(final FSMEntity item, final QueueListenerResponse.Builder builder) {
        builder.addBinding(PROCEED, false);
    }

    @Override
    public final StateData deserializeData(final FSMEntity item) throws Exception {
        return OBJECT_MAPPER.readValue(item.getData(), AsfeAsyncStateResponse.class);
    }

    @Override
    public final QueueListenerRequest<? extends QueueListenerBody> deserializeBody(final String body) throws JsonProcessingException {
        action = AsFeAction.fromValue(JsonPath.parse(body).read("@.body.action"));
        this.messageSupportedCheck(action, List.of(AsFeAction.SCHEDULED_MAINTENANCE, AsFeAction.OUTAGE_START, AsFeAction.OUTAGE_END));
        if (AsFeAction.SCHEDULED_MAINTENANCE == action) {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessScheduledMaintenanceRequest>>() {
            });
        } else if (AsFeAction.OUTAGE_START == action) {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessOutageStartRequest>>() {
            });
        } else {
            return OBJECT_MAPPER.readValue(body, new TypeReference<BasicQueueListenerRequest<ProcessOutageEndRequest>>() {
            });
        }
    }

    @Override
    public final void executeClean(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) {
        this.getLOGGER().unify(builder.getLogBuilderId(), Level.INFO, "inside validated execute clean...action:{}", action);
        builder.addBinding(PROCEED, true);
    }

    @Override
    public final void executeDirty(final QueueListenerRequest<? extends QueueListenerBody> request, final FSMEntity item, final QueueListenerResponse.Builder builder) {
        // do nothing
    }

    @Override
    public final String getMessageGroupId() {
        return "callback-validated";
    }

    @Override
    public final LoggerWrapper getLOGGER() {
        return LOGGER;
    }
}
