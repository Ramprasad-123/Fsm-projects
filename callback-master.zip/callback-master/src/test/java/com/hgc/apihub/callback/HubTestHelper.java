package com.hgc.apihub.callback;

import com.hgc.apihub.callback.model.ccHub.Hub;
import com.hgc.apihub.callback.model.ccHub.HubRequest;
import com.hgc.apihub.callback.model.ccHub.HubResponse;
import com.hgc.apihub.graphqlcc.fragment.CcHubFields;
import com.hgc.apihub.graphqlcc.fragment.CcHubsFields;
import com.hgc.apihub.graphqlcc.queries.CreateCcHubMutation;
import com.hgc.apihub.graphqlcc.queries.DeleteCcHubMutation;
import com.hgc.apihub.graphqlcc.queries.ReadCcHubsQuery;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Wai Yan Oo on 5/12/20
 */
public class HubTestHelper implements Serializable {


    public HubTestHelper() {
    }

    public static ResponseEntity getCreatedHubResponse() {
        return new ResponseEntity<>(
                new Hub(1, "testUser", "test", "test@test.com", "1993-01-01 12:14:12", "testUser", "", ""),
                HttpStatus.CREATED);
    }

    public static ResponseEntity getHubListResponse() {
        List<Hub> hubs = new ArrayList<>();
        hubs.add(new Hub(1, "testUser", "test", "test@test.com", "1993-01-01 12:14:12", "testUser", "", ""));
        hubs.add(new Hub(2, "testUser", "test", "test@test.com", "1993-01-01 12:14:12", "testUser", "", ""));
        return new ResponseEntity<>(new HubResponse(hubs, HttpStatus.OK), HttpStatus.OK);
    }

    public static ResponseEntity getDeleteHubResponse() {
        return new ResponseEntity<>(true, HttpStatus.NO_CONTENT);
    }

    public static CcHubFields getCcHubFields() {

        return CcHubFields.builder().__typename("test")
                .apimXUserId("12345")
                .id(12)
                .callback("callback")
                .query("query")
                .createBy("system")
                .updateBy("system")
                .build();
    }

    private Integer id;
    private String apimXUserId;
    private String query;
    private String callback;
    private String createDate;
    private String createBy;
    private String updateDate;
    private String updateBy;

    public static HubResponse getHubResponse() {
        List<Hub> hubs = new ArrayList<>();
        Hub hub = new Hub();
        hub.setId(1);
        hub.setApimXUserId("12345");
        hub.setQuery("query");
        hub.setCallback("callback");
        hub.setCreateBy("system");
        hub.setUpdateBy("system");
        hub.setCreateDate("2022-02-02 02:02:02");
        hub.setUpdateDate("2022-02-02 02:02:02");
        hubs.add(hub);
        return new HubResponse(hubs, HttpStatus.OK);
    }

    public static HubRequest getHubRequest() {
        return new HubRequest("query", "callback", "system");
    }

    public static CreateCcHubMutation.Data getCreateCcHubMutation() {

        return CreateCcHubMutation.Data.builder()
                .createCcHub(CreateCcHubMutation.CreateCcHub.builder()
                        .__typename("test")
                        .fragments(CreateCcHubMutation.CreateCcHub.Fragments.builder()
                                .ccHubFields(CcHubFields.builder()
                                        .__typename("test")
                                        .updateBy("system")
                                        .createBy("system")
                                        .callback("callback")
                                        .query("query")
                                        .id(1)
                                        .apimXUserId("1234")
                                        .build()).build()).build()).build();

    }

    public static DeleteCcHubMutation.Data getDeleteCcHubMutation() {

        return DeleteCcHubMutation.Data.builder()
                .deleteCcHub(true).build();

    }

    public static ReadCcHubsQuery.Data getCcHuQueryData() {

        var response = ReadCcHubsQuery.
                ReadCcHubs.builder().__typename("").fragments(ReadCcHubsQuery.ReadCcHubs.
                Fragments.builder().ccHubsFields(CcHubsFields.builder()
                .__typename("test").ccHubs(List.of(CcHubsFields.CcHub.builder().__typename("test")
                        .fragments(CcHubsFields.CcHub.Fragments.builder().
                                ccHubFields(CcHubFields.builder().__typename("test").build()).build())
                        .build()))
                .build()).build()).build();

        return ReadCcHubsQuery.
                Data.builder().readCcHubs(response).build();


    }
}



