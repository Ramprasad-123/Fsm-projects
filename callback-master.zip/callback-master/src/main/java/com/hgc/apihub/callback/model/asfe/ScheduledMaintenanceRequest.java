package com.hgc.apihub.callback.model.asfe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hgc.apihub.callback.model.asfe.enums.CallbackType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Generated;
import lombok.Getter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Schema(description = "Create scheduled maintenance request body")
@Generated
@Getter
public class ScheduledMaintenanceRequest extends BasicAsFeRequest {

    @NotNull
    @JsonProperty(value = "sch_maint")
    @Schema(description = "Scheduled Maintenance", requiredMode = Schema.RequiredMode.REQUIRED)
    public SchMaint schMaint;

    public ScheduledMaintenanceRequest(@JsonProperty(value = "unique_id") final String uniqueIdValue, @JsonProperty(value = "callback_type") final CallbackType callbackTypeValue, @JsonProperty(value = "channel") final String channelValue,
                                       @JsonProperty(value = "store") final Store storeValue, @JsonProperty(value = "affect_cust_lnoc") final List<AffectCustLnoc> affectCustLnocValue, @JsonProperty(value = "sch_maint") final SchMaint schMaintValue) {
        super(uniqueIdValue, callbackTypeValue, channelValue, storeValue, affectCustLnocValue);
        this.schMaint = schMaintValue;
    }

    @Getter
    public static class SchMaint implements Serializable {

        @NotBlank
        @JsonProperty(value = "start_date")
        @Schema(description = "Start date", requiredMode = Schema.RequiredMode.REQUIRED, example = "2022-12-14 00:00:00")
        public String startDate;

        @NotBlank
        @JsonProperty(value = "end_date")
        @Schema(description = "End date", requiredMode = Schema.RequiredMode.REQUIRED, example = "2021-12-15 15:00:00")
        public String endDate;

        public SchMaint(@JsonProperty(value = "start_date") final String startDateValue, @JsonProperty(value = "end_date") final String endDateValue) {
            startDate = startDateValue;
            endDate = endDateValue;
        }
    }
}
